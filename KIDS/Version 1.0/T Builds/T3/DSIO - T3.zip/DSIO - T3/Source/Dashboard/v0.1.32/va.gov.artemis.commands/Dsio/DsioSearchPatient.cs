﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VA.Gov.Artemis.Commands.Dsio
{
    public class DsioSearchPatient: DsioPatient
    {
        public string Gender { get; set; }

        public string Veteran { get; set; }

        public string Location { get; set; }

        public string RoomBed { get; set; }

        public string ServiceConnected { get; set; }

        public string TrackingStatus { get; set; }

    }
}
