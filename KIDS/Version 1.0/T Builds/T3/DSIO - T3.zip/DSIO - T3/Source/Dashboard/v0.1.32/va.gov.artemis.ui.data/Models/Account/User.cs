﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace VA.Gov.Artemis.UI.Data.Models.Account
{
    public class User
    {
        public string Duz { get; set; }
        public string UserName { get; set; }        
    }
}