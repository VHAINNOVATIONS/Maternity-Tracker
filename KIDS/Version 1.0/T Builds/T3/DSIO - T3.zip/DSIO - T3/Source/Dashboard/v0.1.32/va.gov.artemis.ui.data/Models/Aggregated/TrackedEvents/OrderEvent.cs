﻿//using VA.Gov.Artemis.UI.Data.Models.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using VA.Gov.Artemis.UI.Data.Models.Aggregated.Common;

namespace VA.Gov.Artemis.UI.Data.Models.Aggregated.TrackedEvents
{
    public class OrderEvent : TrackedEvent
    {
        public string OrderId { get; set; }
        public DateTime EntryDate { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime StopDate { get; set; }

        public OrderStatus OrderStatus { get; set; }
        public string OrderText { get; set; }

        public override string EventName
        {
            get { return string.Format("Order Placed on {0}", this.EntryDate.ToShortDateString()); }
        }

        public override string Details
        {
            get { return this.OrderText; }
        }

        public override TrackedEventType EventType
        {
            get { return TrackedEventType.Order; }
        }
    }
}