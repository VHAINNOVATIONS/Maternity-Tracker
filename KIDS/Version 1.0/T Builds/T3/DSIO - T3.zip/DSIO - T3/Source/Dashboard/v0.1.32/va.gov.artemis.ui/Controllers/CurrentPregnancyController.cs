﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using VA.Gov.Artemis.UI.Data.Brokers.Results;
using VA.Gov.Artemis.UI.Data.Models.Patient;
using VA.Gov.Artemis.UI.Filters;

namespace VA.Gov.Artemis.UI.Controllers
{
    [DisableLocalCache]
    [VerifySession]
    [Authorize]
    public class CurrentPregnancyController : DashboardController
    {
        [HttpGet]
        public ActionResult Details(string dfn)
        {
            CurrentPregnancyDetails model = new CurrentPregnancyDetails();

            model.Patient = this.CurrentPatient;

            if (!model.Patient.NotFound)
            {
                model.CurrentPregnancy = new CurrentPregnancy();
                model.CurrentPregnancy.EDD = new DateTime(2014, 3, 12);
                model.CurrentPregnancy.FetusCount = 2;
                model.CurrentPregnancy.Pregnant = true;
            }

            return View(model);
        }

        [HttpGet]
        public ActionResult ChangeStatus(string dfn)
        {
            // *** Show form to update current preganancy details ***

            // TODO ...

            return View();
        }

        [HttpPost]
        public ActionResult ChangeStatus()
        {
            // *** Post data ***

            // TODO ...

            return View();
        }
    }
}
