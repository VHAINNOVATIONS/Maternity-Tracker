﻿//using VA.Gov.Artemis.UI.Data.Models.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using VA.Gov.Artemis.UI.Data.Models.Aggregated.Common;

namespace VA.Gov.Artemis.UI.Data.Models.Aggregated.TrackedEvents
{
    public class ConsultEvent : TrackedEvent
    {
        public string ConsultId { get; set; }
        public string Description { get; set; }

        public override string EventName
        {
            get { return "Consult"; }
        }

        // TODO: Add date to details?

        public override string Details
        {
            get { return this.Description; }
        }

        public override TrackedEventType EventType
        {
            get { return TrackedEventType.Consult; }
        }
    }
}