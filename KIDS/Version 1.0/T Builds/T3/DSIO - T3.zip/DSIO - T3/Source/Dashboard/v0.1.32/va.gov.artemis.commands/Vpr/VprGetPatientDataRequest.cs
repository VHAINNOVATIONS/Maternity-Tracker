﻿//using VA.Gov.Artemis.Vista.Common;
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace VA.Gov.Artemis.Commands.Vpr
//{


//    public class VprGetPatientDataRequest: Request
//    {
//        // TODO: ...
//        public string[] VprDataTypeDescriptions = {"accession", "", "", "", ""}; 

//        // *** Unique patient identifier ***
//        public string  Dfn { get; set; }
        

//        public VprDataType  VprDataType { get; set; }
//        public DateTime StartDate { get; set; }
//        public DateTime EndDate { get; set; }

//        // *** Total records for each section ***
//        public int MaxRecords { get; set; }

//        // *** Id of the item to retrieve (retrieving a single item) *** 
//        // *** Must set Type also ***
//        public string ItemId { get; set; }

//        // TODO: How to use this...?
//        public string Filter { get; set; }

//        //public VprGetPatientDataRequest (string dfn, string type, DateTime start, DateTime stop, string max, string item)
//        //{
//        //    string startDateParam = "";
//        //    string stopDateParam = ""; 

//        //    if (start != DateTime.MinValue)
//        //        startDateParam = this.GetFileManDate(start);

//        //    if (stop != DateTime.MinValue)
//        //        stopDateParam = this.GetFileManDate(stop); 

//        //    this.Args = new object[] 
//        //    { 
//        //        dfn, 
//        //        type, 
//        //        startDateParam, 
//        //        stopDateParam, 
//        //        max, 
//        //        item
//        //    };
//        //}


//    }
//}
