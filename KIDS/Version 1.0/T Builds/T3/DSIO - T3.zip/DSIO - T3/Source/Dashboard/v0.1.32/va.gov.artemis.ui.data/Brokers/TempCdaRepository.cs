﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VA.Gov.Artemis.UI.Data.Brokers
{
    //public interface ITempCdaRepository
    //{
    //    //string SaveOutgoing(string xml);

    //    string TrackFileName(string fileName); 

    //    void Purge(); 
    //}

    //public class TempCdaRepository: ITempCdaRepository
    //{
    //    public static string SaveOutgoing(string xml)
    //    {
    //        string returnVal = ""; 

    //        // *** Make sure proper folder is in place ***
    //        // *** Get the physical path ***
    //        string path = this.HttpContext.Server.MapPath("/Cda");

    //        // *** Make sure our directory exists ***
    //        if (!Directory.Exists(path))
    //            Directory.CreateDirectory(path);

    //        // *** Make sure xsl is in place ***

    //        // *** Create a file name to work with ***

    //        // *** Write xml to file ***

    //        // *** Save file name in session data ***

    //        // *** Return file name ***
    //        return returnVal; 
    //    }

    //    public static void Purge()
    //    {
    //        // *** Remove files created for this session ***
    //    }
    //}
}
