﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VA.Gov.Artemis.UI.Data.Models
{
    public class PatientSummary
    {
        public BasePatient Patient { get; set; }

        public string Pregnant { get; set; }
        public DateTime EDD { get; set; }
        public string GestationalAge { get; set; }
        public string Multiple { get; set; }
        public int Trimester { get; set; }

        public string Lactating { get; set; }
        public DateTime LastContact { get; set; }
        public DateTime NextContact { get; set; }
        public string PrenatalCareProvider { get; set; }
        public string PlannedDeliveryLocation { get; set; }

        public string ReturnUrl { get; set; }
    }
}
