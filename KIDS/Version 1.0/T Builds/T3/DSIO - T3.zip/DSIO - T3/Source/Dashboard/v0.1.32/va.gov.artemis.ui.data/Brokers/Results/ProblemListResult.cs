﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VA.Gov.Artemis.UI.Data.Models.Patient;

namespace VA.Gov.Artemis.UI.Data.Brokers.Results
{
    public class ProblemListResult: BrokerOperationResult
    {
        public List<Problem> Problems { get; set; }

        public ProblemListResult()
        {
            this.Problems = new List<Problem>(); 
        }
    }
}
