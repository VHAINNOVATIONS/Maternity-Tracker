﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VA.Gov.Artemis.UI.Data.Models.Patient
{
    public class EstimatedDeliveryDate
    {
        public string Id { get; set; }
        public string Dfn { get; set; }

        [Display(Name="User")]
        public string UserName { get; set; }

        [Display(Name="Entry Date")]
        public DateTime EntryDateTime { get; set; }

        public DateTime EDD { get; set; }
        public EddBasis Basis { get; set; }
        public UltrasoundTiming UltrasoundTiming { get; set; }
        public bool Final { get; set; }
    }

    public enum EddBasis { Unknown = -1, ActualConceptionDate = 0, LMP = 1, Ultrasound = 2, InitialExam = 3, Other = 4 }

    public enum UltrasoundTiming { NotApplicable = -1, Early = 0, FirstTri = 1, SecondTri = 2, ThirdTri = 3 }

}
