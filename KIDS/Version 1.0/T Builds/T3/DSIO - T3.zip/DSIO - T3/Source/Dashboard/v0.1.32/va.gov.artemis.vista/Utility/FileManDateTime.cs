﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
//using System.Xml.Serialization;
//using VA.Gov.Artemis.Core;

//namespace VA.Gov.Artemis.Vista.Utility
//{
//    [Serializable]
//    public static class FileManDateTime
//    {

//        public static string GetFileManDate(DateTime originalDate)
//        {
//            // FileMan date format= yyymmdd.hhmms# 

//            string returnVal = "";

//            if (originalDate != DateTime.MinValue)
//            {
//                int year = originalDate.Year - 1700;

//                returnVal = string.Format("{0}{0:1}{2}", year, originalDate.Month, originalDate.Day);

//            }
//            return returnVal;
//        }

//        public static DateTime GetDateTime(string fileManDateTime)
//        {
//            DateTime returnVal = DateTime.MinValue;

//            int[] dateVals = new int[6];

//            string year = fileManDateTime.Substring(0, 3);
//            string month = fileManDateTime.Substring(3, 2);
//            string day = fileManDateTime.Substring(5, 2);

//            string[] time = fileManDateTime.Split(".".ToCharArray());

//            string hour = time[1].Substring(0, 2);
//            string minute = time[1].Substring(2, 2);
//            string second = time[1].Substring(4);

//            if (string.IsNullOrWhiteSpace(second))
//                second = "0";
                    
//            if (int.TryParse(year, out dateVals[0]))
//                if (int.TryParse(month, out dateVals[1]))
//                    if (int.TryParse(day, out dateVals[2]))
//                        if (int.TryParse(hour, out dateVals[3]))
//                            if (int.TryParse(minute, out dateVals[4]))
//                                if (int.TryParse(second, out dateVals[5]))
//                                    returnVal = new DateTime(dateVals[0] + 1700, dateVals[1], dateVals[2], dateVals[3], dateVals[4], dateVals[5]);
            
//            return returnVal;
//        }
//    }
//}
