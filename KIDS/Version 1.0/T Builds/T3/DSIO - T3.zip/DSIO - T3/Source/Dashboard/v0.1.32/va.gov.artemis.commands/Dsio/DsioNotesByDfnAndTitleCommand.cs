﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VA.Gov.Artemis.Commands.Tiu;
using VA.Gov.Artemis.Vista.Broker;
using VA.Gov.Artemis.Vista.Utility;

namespace VA.Gov.Artemis.Commands.Dsio
{
    public class DsioNotesByDfnAndTitleCommand: DsioCommand
    {
        public DsioNotesByDfnAndTitleCommand(IRpcBroker newBroker): base(newBroker)
        {
            this.Notes = new List<TiuDocument>();
        }

        public int TotalResults { get; set; }

        public List<TiuDocument> Notes { get; set; }

        public override string RpcName
        {
            get { return "DSIO NOTES BY DFN AND TITLE"; }
        }

        protected override void ProcessResponse()
        {
            if (string.IsNullOrWhiteSpace(this.Response.Data))
            {
                this.Response.Status = RpcResponseStatus.Fail;
                this.Response.InformationalMessage = "No return value";
            }
            else
            {
                string piece1 = Util.Piece(this.Response.Lines[0], Caret, 1);
                string piece2 = Util.Piece(this.Response.Lines[0], Caret, 2);

                if (piece1.Contains("M  ERROR"))
                {
                    this.Response.Status = RpcResponseStatus.Fail;
                    this.Response.InformationalMessage = "M Error retrieving list of notes";
                }
                else
                    switch (piece1)
                    {
                        case "-1":
                            this.Response.Status = RpcResponseStatus.Fail;
                            this.Response.InformationalMessage = piece2;
                            break;                    
                        case "0":
                            this.Response.Status = RpcResponseStatus.Success;
                            this.Response.InformationalMessage = piece2; 
                            break; 
                        default:

                            string[] lines = this.Response.Lines;

                            bool first = true; 

                            foreach (string line in lines)
                            {
                                // *** First line is total result ***
                                if (first)
                                {
                                    int total = -1;
                                    if (int.TryParse(line, out total))
                                        this.TotalResults = total;
                                    first = false;
                                }
                                else
                                {
                                    TiuDocument doc = new TiuDocument();

                                    //doc.DoINeedThis = Util.Piece(line, Caret, 1); 

                                    piece2 = Util.Piece(line, Caret, 2);

                                    if (piece2.Contains("to"))
                                        doc.Ien = Util.Piece(piece2, " to ", 1);
                                    else
                                        doc.Ien = piece2; 
                                    
                                    doc.Title = Util.Piece(line, Caret, 3);
                                    doc.SignatureStatus = Util.Piece(line, Caret, 4);
                                    doc.DocumentDateTime = Util.Piece(line, Caret, 5);
                                    doc.Author = Util.Piece(line, Caret, 6);
                                    doc.Location = Util.Piece(line, Caret, 7);

                                    string piece8 = Util.Piece(line, Caret, 8);

                                    if (piece8.StartsWith("A"))
                                        doc.HasChildren = true.ToString();
                                    else
                                        doc.HasChildren = false.ToString();

                                    if (piece8.StartsWith("O"))
                                        doc.ParentIen = Util.Piece(piece8, ":", 2);

                                    if (this.Notes == null)
                                        this.Notes = new List<TiuDocument>();

                                    this.Notes.Add(doc);
                                }
                            }

                            this.Response.Status = RpcResponseStatus.Success;
                            break;
                    }
            }
        }

        public void AddCommandArguments(string dfn, string noteTitle, int page, int itemsPerPage) 
        {
            this.CommandArgs = new object[] {
                dfn, 
                noteTitle,
                string.Format("{0},{1}", page, itemsPerPage)
            };
        }

    }
}
