﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VA.Gov.Artemis.Vista.Broker;
using VA.Gov.Artemis.Vista.Utility;

namespace VA.Gov.Artemis.Commands.Dsio
{
    public class DsioIhePatientListCommand: DsioCommand
    {
        public int TotalResults { get; set; }

        public List<DsioCdaDocument> DocumentList { get; set; }

        public DsioIhePatientListCommand(IRpcBroker newBroker): base(newBroker)
        {
            
        }

        public override string RpcName
        {
            get { return "DSIO IHE PATIENT LIST"; }
        }

        public void AddCommandArguments(string patientDfn, int page, int itemsPerPage)
        {            
            this.CommandArgs = new object[] { 
                patientDfn, 
                string.Format("{0},{1}", page, itemsPerPage)
            };
        }

        protected override void ProcessResponse()
        {
            if (string.IsNullOrWhiteSpace(this.Response.Data))
            {
                this.Response.Status = RpcResponseStatus.Fail;
                this.Response.InformationalMessage = "No return value";
            }
            else
            {
                string piece1 = Util.Piece(this.Response.Lines[0], Caret, 1);
                string piece2 = Util.Piece(this.Response.Lines[0], Caret, 2);

                int returnCode = -1;

                int.TryParse(piece1, out returnCode);

                if (returnCode < 1)
                {
                    this.Response.Status = RpcResponseStatus.Fail;
                    this.Response.InformationalMessage = piece2;
                }
                else
                {
                    string[] lines = this.Response.Lines;

                    bool first = true; 

                    foreach (string line in lines)
                    {
                        if (first)
                        {
                            this.TotalResults = returnCode;
                            first = false;
                        }
                        else
                        {
                            if (this.DocumentList == null)
                                this.DocumentList = new List<DsioCdaDocument>();

                            DsioCdaDocument tempDoc = new DsioCdaDocument();

                            tempDoc.Ien = Util.Piece(line, Caret, 1);
                            tempDoc.Id = Util.Piece(line, Caret, 2);
                            //tempDoc.PatientDfn = Util.Piece(line, Caret, 3);
                            tempDoc.CreatedOn = Util.Piece(line, Caret, 4);
                            tempDoc.ImportExportDate = Util.Piece(line, Caret, 5);
                            tempDoc.DocumentType = Util.Piece(line, Caret, 6);
                            tempDoc.Direction = Util.Piece(line, Caret, 7);
                            tempDoc.Title = Util.Piece(line, Caret, 8);
                            tempDoc.Sender = Util.Piece(line, Caret, 9);
                            tempDoc.IntendedRecipient = Util.Piece(line, Caret, 10);

                            this.DocumentList.Add(tempDoc);
                        }
                    }

                    this.Response.Status = RpcResponseStatus.Success;
                }
            }
        }
    }
}
