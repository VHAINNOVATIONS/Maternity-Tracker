﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VA.Gov.Artemis.UI.Data.Brokers.Results;
using VA.Gov.Artemis.UI.Data.Models.Cda;

namespace VA.Gov.Artemis.UI.Data.Brokers
{
    public interface ICdaRepository
    {
        BrokerOperationResult SaveDocument(CdaDocumentData documentData);

        CdaDocumentResult Generate(CdaOptions options);

        string GetDocumentAbbreviation(IheDocumentType iheDocumentType);

        CdaDocumentListResult GetExchangeHistory(string patientDfn, int page, int itemsPerPage);

        CdaDocumentResult GetDocumentData(string ien);

        BrokerOperationResult DocumentIsSupported(string documentContent);

        PatientDemographicsResult GetDocumentPatient(string documentContent);

        CdaDocumentResult ExtractDocumentData(string documentContent);
    }
}
