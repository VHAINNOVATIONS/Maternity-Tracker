﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using VA.Gov.Artemis.UI.Controllers;
using System.Web.Mvc;
using System.Web;
using VA.Gov.Artemis.UI.Data.Models;
using VA.Gov.Artemis.UI.Data.Brokers;
using VA.Gov.Artemis.Vista.Broker;
using VA.Gov.Artemis.Commands.Xus;
using System.Collections.Generic;
using VA.Gov.Artemis.UI.Mock;
using VA.Gov.Artemis.UI.Data.Models.Account;

namespace VA.Gov.Artemis.UI.Tests
{
    [TestClass]
    public class TestAccountController
    {
        [TestMethod]
        public void TestLoginGetAuthenticated()
        {
            MockRpcBroker broker = new MockRpcBroker(); 

            AccountController controller = new AccountController(broker);

            int timeout; 
            ActionResult result = controller.ProcessLoginGet(true, "", out timeout);

            // *** Acceptible results ***
            Assert.IsNotNull(result);
            Assert.IsInstanceOfType(result, typeof(ViewResult));
            ViewResult viewResult = (ViewResult)result;
            Assert.AreEqual("LoggedIn", viewResult.ViewName); 

        }

        [TestMethod]
        public void TestLoginGetNotAuthenticated()
        {
            IRpcBroker broker = MockRpcBrokerFactory.GetLoginSuccessBroker();

            AccountController controller = new AccountController(broker);

            int timeout;
            string returnUrl = "something"; 
            ActionResult result = controller.ProcessLoginGet(false, returnUrl, out timeout);

            // *** Acceptible results ***
            Assert.IsNotNull(result);
            Assert.IsInstanceOfType(result, typeof(ViewResult));
            ViewResult viewResult = (ViewResult)result;
            Assert.IsInstanceOfType(viewResult.Model, typeof(Login));
            Login login = (Login) viewResult.Model;
            Assert.AreEqual(returnUrl, login.RequestedUrl); ;
            Assert.IsFalse(string.IsNullOrWhiteSpace(login.IntroMessage));
            Assert.IsFalse(string.IsNullOrWhiteSpace(login.Port));
            Assert.IsFalse(string.IsNullOrWhiteSpace(login.Server));
            Assert.IsFalse(string.IsNullOrWhiteSpace(login.UCI));
            Assert.IsFalse(string.IsNullOrWhiteSpace(login.Volume));

            // TODO: If testing with broker...
            //Assert.IsTrue(BrokerStore.Count > 0);
        }

        [TestMethod]
        public void TestLoginGetNotAuthenticatedNoResult()
        {
            IRpcBroker broker = MockRpcBrokerFactory.GetDisconnectedBroker();

            AccountController controller = new AccountController(broker);

            int timeout;
            string returnUrl = "something";
            ActionResult result = controller.ProcessLoginGet(false, returnUrl, out timeout);

            // *** Acceptible results ***
            Assert.IsNotNull(result);
            Assert.IsInstanceOfType(result, typeof(RedirectToRouteResult));

            RedirectToRouteResult redirectResult = (RedirectToRouteResult)result;

            Assert.AreEqual("Home", redirectResult.RouteValues["controller"], "wrong controller");
            Assert.AreEqual("Index", redirectResult.RouteValues["action"], "wrong action");

        }

        [TestMethod]
        public void TestLoginPost()
        {
            IRpcBroker broker = MockRpcBrokerFactory.GetLoginPostBroker(true);
            
            AccountController controller = new AccountController(broker);

            bool modelStateValid = true;
            int timeout = 0;
            string authorizedUser = "";
            Login loginModel = new Login()
            {
                 UserName = "PROG999-",
                 VerifyCode = "PROG123."
            }; 

            List<XusDivision> divisions;
                        
            ActionResult returnResult = controller.ProcessLoginPost(modelStateValid, loginModel, out timeout, out authorizedUser, out divisions);

            Assert.IsInstanceOfType(returnResult, typeof(RedirectToRouteResult));
            Assert.IsTrue(timeout > 0); 
            Assert.IsFalse(string.IsNullOrWhiteSpace(authorizedUser));

        }

        [TestMethod]
        public void TestLoginPostInvalidModelState()
        {
            IRpcBroker broker = MockRpcBrokerFactory.GetLoginPostBroker(true);

            AccountController controller = new AccountController(broker);

            bool modelStateValid = false ;
            int timeout = 0;
            string authorizedUser = "";
            Login loginModel = new Login()
            {
                UserName = "PROG999-",
                VerifyCode = "PROG!!!999"
            };

            List<XusDivision> divisions;

            ActionResult returnResult = controller.ProcessLoginPost(modelStateValid, loginModel, out timeout, out authorizedUser, out divisions);

            Assert.IsInstanceOfType(returnResult, typeof(ViewResult));
            ViewResult viewResult = (ViewResult)returnResult;
            Assert.IsInstanceOfType(viewResult.Model, typeof(Login)); 
        }

        [TestMethod]
        public void TestLoginPostInvalidVerify()
        {
            IRpcBroker broker = MockRpcBrokerFactory.GetLoginPostBroker(false);

            AccountController controller = new AccountController(broker);

            bool modelStateValid = true;
            int timeout = 0;
            string authorizedUser = "";
            Login loginModel = new Login()
            {
                UserName = "PROG999-",
                VerifyCode = ""
            };

            List<XusDivision> divisions;

            ActionResult returnResult = controller.ProcessLoginPost(modelStateValid, loginModel, out timeout, out authorizedUser, out divisions);

            Assert.IsInstanceOfType(returnResult, typeof(ViewResult));
            ViewResult viewResult = (ViewResult)returnResult;
            Assert.IsInstanceOfType(viewResult.Model, typeof(Login)); 

        }

        [TestMethod]
        public void TestChangeVerifyCodeGet()
        {
            AccountController controller = new AccountController();

            string expectedLink = "anything"; 

            ActionResult result = controller.ChangeVerifyCode(expectedLink);

            Assert.IsNotNull(result);
            Assert.IsInstanceOfType(result, typeof(ViewResult));
            ViewResult viewResult = (ViewResult)result;
            Assert.IsInstanceOfType(viewResult.Model, typeof(ChangeVerifyCode));
            ChangeVerifyCode cvc = (ChangeVerifyCode)viewResult.Model;
            Assert.AreEqual(cvc.RequestedUrl, expectedLink);

        }

        [TestMethod]
        public void TestChangeVerifyCodePost_SuccessUnauthorized()
        {
            string testUrl = "/lskfj"; 

            IRpcBroker broker = MockRpcBrokerFactory.GetChangeVerifyCodePostBroker(true);

            AccountController controller = new AccountController(broker);

            ChangeVerifyCode cvc = new ChangeVerifyCode()
            {
                OriginalVerifyCode = "",
                NewVerifyCode = "",
                ConfirmVerifyCode = "", 
                RequestedUrl = testUrl
            };

            int timeout = 0;
            string authorizedUser = ""; 

            ActionResult result = controller.ProcessChangeVerifyCodePost(cvc, true, false, out timeout, out authorizedUser);

            Assert.IsNotNull(result);
            Assert.IsInstanceOfType(result, typeof(RedirectResult));
            RedirectResult redirResult = (RedirectResult)result;
            Assert.AreEqual("~" + testUrl, redirResult.Url);
            Assert.IsTrue(timeout > 0);
            Assert.IsFalse(string.IsNullOrWhiteSpace(authorizedUser));

        }

        [TestMethod]
        public void TestChangeVerifyCodePost_InvalidModelState()
        {
            string testUrl = "/lskfj";

            IRpcBroker broker = MockRpcBrokerFactory.GetChangeVerifyCodePostBroker(true);

            AccountController controller = new AccountController(broker);

            ChangeVerifyCode cvc = new ChangeVerifyCode()
            {
                OriginalVerifyCode = "",
                NewVerifyCode = "",
                ConfirmVerifyCode = "",
                RequestedUrl = testUrl
            };

            int timeout = 0;
            string authorizedUser = "";

            ActionResult result = controller.ProcessChangeVerifyCodePost(cvc, false, false, out timeout, out authorizedUser);

            Assert.IsNotNull(result);
            Assert.IsInstanceOfType(result, typeof(ViewResult));
            ViewResult viewResult = (ViewResult)result;
            Assert.IsInstanceOfType(viewResult.Model, typeof(ChangeVerifyCode));
        }

        [TestMethod]
        public void TestChangeVerifyCodePost_SuccessAuthorized()
        {
            string testUrl = "/lskfj"; 

            IRpcBroker broker = MockRpcBrokerFactory.GetChangeVerifyCodePostBroker(true);

            AccountController controller = new AccountController(broker);

            ChangeVerifyCode cvc = new ChangeVerifyCode()
            {
                OriginalVerifyCode = "",
                NewVerifyCode = "",
                ConfirmVerifyCode = "", 
                RequestedUrl = testUrl
            };

            int timeout = 0;
            string authorizedUser = ""; 

            ActionResult result = controller.ProcessChangeVerifyCodePost(cvc, true, true, out timeout, out authorizedUser);

            Assert.IsNotNull(result);
            Assert.IsInstanceOfType(result, typeof(RedirectToRouteResult));
            RedirectToRouteResult routeResult = (RedirectToRouteResult)result;
            Assert.AreEqual("Home", routeResult.RouteValues["controller"]);
            Assert.AreEqual("Index", routeResult.RouteValues["action"]);
            Assert.IsTrue(timeout > 0);
            Assert.IsTrue(string.IsNullOrWhiteSpace(authorizedUser));

        }

        [TestMethod]
        public void TestChangeVerifyCodePost_FailedChange()
        {
            string testUrl = "/lskfj";

            IRpcBroker broker = MockRpcBrokerFactory.GetChangeVerifyCodePostBroker(false);

            AccountController controller = new AccountController(broker);

            ChangeVerifyCode cvc = new ChangeVerifyCode()
            {
                OriginalVerifyCode = "",
                NewVerifyCode = "",
                ConfirmVerifyCode = "",
                RequestedUrl = testUrl
            };

            int timeout = 0;
            string authorizedUser = "";

            ActionResult result = controller.ProcessChangeVerifyCodePost(cvc, true, false, out timeout, out authorizedUser);

            Assert.IsNotNull(result);
            Assert.IsInstanceOfType(result, typeof(ViewResult));
            ViewResult viewResult = (ViewResult)result;
            Assert.IsInstanceOfType(viewResult.Model, typeof(ChangeVerifyCode));
        }

        [TestMethod]
        public void TestChangeVerifyCodePost_NoUser()
        {
            string testUrl = "/lskfj";

            IRpcBroker broker = MockRpcBrokerFactory.GetChangeVerifyCodePostBroker(true, false);

            AccountController controller = new AccountController(broker);

            ChangeVerifyCode cvc = new ChangeVerifyCode()
            {
                OriginalVerifyCode = "",
                NewVerifyCode = "",
                ConfirmVerifyCode = "",
                RequestedUrl = testUrl
            };

            int timeout = 0;
            string authorizedUser = "";

            ActionResult result = controller.ProcessChangeVerifyCodePost(cvc, true, true, out timeout, out authorizedUser);

            Assert.IsNotNull(result);
            Assert.IsInstanceOfType(result, typeof(RedirectToRouteResult));
            RedirectToRouteResult routeResult = (RedirectToRouteResult)result;
            Assert.AreEqual("Home", routeResult.RouteValues["controller"]);
            Assert.AreEqual("Index", routeResult.RouteValues["action"]);
            Assert.IsTrue(timeout > 0);
            Assert.IsTrue(string.IsNullOrWhiteSpace(authorizedUser));

        }

        [TestCleanup]
        public void Cleanup()
        {
            BrokerStore.Cleanup();
        }
    }


}
