﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using VA.Gov.Artemis.UI.Data.Brokers.Results;
using VA.Gov.Artemis.UI.Data.Models;
using VA.Gov.Artemis.UI.Data.Models.Aggregated;
using VA.Gov.Artemis.UI.Filters;

namespace VA.Gov.Artemis.UI.Controllers
{    
    [Authorize]
    [VerifySession]
    [DisableLocalCache]
    public class TrackController : DashboardController
    {
        [HttpGet]
        public ActionResult Start(string dfn)
        {
            // *** Show start tracking page ***

            ActionResult returnResult;

            CreateTrackingEntry model = GetNewModel(TrackingEntryType.Start, dfn);

            returnResult = View("~/Views/Track/Create.cshtml", model);

            return returnResult;
        }

        [HttpGet]
        public ActionResult Stop(string dfn) 
        {
            // *** Show stop tracking page ***

            ActionResult returnResult;

            CreateTrackingEntry model = GetNewModel(TrackingEntryType.Stop, dfn);

            returnResult = View("~/Views/Track/Create.cshtml", model);

            return returnResult;
        }

        [HttpGet]
        public ActionResult Accept(string dfn) 
        {
            // *** Show accept tracking page ***

            ActionResult returnResult;

            CreateTrackingEntry model = GetNewModel(TrackingEntryType.Accept, dfn);

           returnResult = View("~/Views/Track/Create.cshtml", model);

            return returnResult;
        }

        [HttpGet]
        public ActionResult Reject(string dfn) 
        {
            // *** Show reject tracking page ***

            ActionResult returnResult;

            CreateTrackingEntry model = GetNewModel(TrackingEntryType.Reject, dfn);

            returnResult = View("~/Views/Track/Create.cshtml", model);
 
            return returnResult;
        }

        [HttpPost]
        public ActionResult Create(CreateTrackingEntry newTrackingEntry)
        {
            // *** Post new tracking entry data ***

            ActionResult returnResult;

            Nullable<bool> success = null;

            try
            {
                // *** Get entry type **
                TrackingEntryType eventType = newTrackingEntry.TrackingEntry.EntryType;

                // *** If start, make sure there's a reason ***
                if (eventType == TrackingEntryType.Start)
                    if (string.IsNullOrWhiteSpace(newTrackingEntry.TrackingEntry.Reason))
                    {
                        success = false;
                        this.Error("Please select a reason");
                    }
                
                // *** Check if a determination's been made yet ***
                if (!success.HasValue)
                {
                    // *** Set values for repository ***
                    string dfn = newTrackingEntry.TrackingEntry.PatientDfn;
                    string reason = newTrackingEntry.TrackingEntry.Reason;
                    string comment = newTrackingEntry.TrackingEntry.Comment;

                    // *** Add tracking history entry ***
                    BrokerOperationResult result = this.DashboardRepository.TrackingHistory.Add(dfn, eventType, reason, comment);

                    // *** Set return success ***
                    success = result.Success;

                    // *** Show a message ***
                    if (result.Success)
                        this.Information("Tracking History Entry Created Successfully");
                    else
                        if (string.IsNullOrWhiteSpace(result.Message))
                            this.Error("Could not add tracking history entry");
                        else
                            this.Error(result.Message);
                }
            }
            catch (Exception genericException)
            {
                this.Error(genericException.Message);
                success = false;
            }

            if (success.Value)
                returnResult = RedirectToAction("Overview", "PatientList");
            else
            {                
                // *** Repopulate model for error or problem
                CreateTrackingEntry model = GetNewModel(newTrackingEntry.TrackingEntry.EntryType, newTrackingEntry.TrackingEntry.PatientDfn);
                model.TrackingEntry.Comment = newTrackingEntry.TrackingEntry.Comment;
                returnResult = View("~/Views/Track/Create.cshtml", model);
            }

            return returnResult;
        }

        private CreateTrackingEntry GetNewModel(TrackingEntryType entryType, string dfn)
        {
            // *** Gets appropriate model based on entry type and dfn ***

            CreateTrackingEntry returnModel = new CreateTrackingEntry();

            // *** Set up button text, title, other ui elements ***
            switch (entryType)
            {
                case TrackingEntryType.Start:
                    returnModel.ButtonText = "Start Tracking";
                    returnModel.PageTitle = "Start Tracking a Patient";
                    returnModel.PageMessage = "The following patient will appear as a tracked patient in the dashboard";
                    SelectListResult selectListResult = this.DashboardRepository.SelectLists.GetReasonList();
                    if (selectListResult.Success)
                        returnModel.Reasons = selectListResult.SelectList;
                    returnModel.ReasonText = "Reason for Tracking";
                    break;
                case TrackingEntryType.Stop:
                    returnModel.ButtonText = "Stop Tracking";
                    returnModel.PageTitle = "Stop Tracking a Patient";
                    returnModel.PageMessage = "The following patient will no longer appear as a tracked patient in the dashboard";
                    break;
                case TrackingEntryType.Accept:
                    returnModel.ButtonText = "Accept Tracking";
                    returnModel.PageTitle = "Accept Flagged Patient";
                    returnModel.PageMessage = "The following patient will appear as a tracked patient in the dashboard";
                    break;
                case TrackingEntryType.Reject:
                    returnModel.ButtonText = "Reject Tracking";
                    returnModel.PageTitle = "Reject Flagged Patient";
                    returnModel.PageMessage = "The following patient will not appear as a tracked or flagged patient in the dashboard";
                    break;
            }

            // *** Set return url ***
            if (TempData.ContainsKey(ReturnUrl))
            {
                returnModel.ReturnUrl = TempData[ReturnUrl].ToString();
                TempData[ReturnUrl] = TempData[ReturnUrl];
            }

            // *** Get patient demographics ***
            BasePatient currentPatient = this.CurrentPatient; 

            if (!currentPatient.NotFound)
            {
                // *** Populate model with data ***
                returnModel.TrackingEntry = new TrackingEntry()
                {
                    PatientDfn = dfn,
                    EntryType = entryType,
                    PatientName = currentPatient.Name
                };

                returnModel.Patient = currentPatient;
            }

            return returnModel; 
        }        
    }
}
