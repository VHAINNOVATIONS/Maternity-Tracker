﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace VA.Gov.Artemis.UI.Data.Models.Aggregated.Common
{
    public enum TrackedEventCompletionStatus { Pending, Due, Overdue, Completed } // *** Pending means not due yet ***
}