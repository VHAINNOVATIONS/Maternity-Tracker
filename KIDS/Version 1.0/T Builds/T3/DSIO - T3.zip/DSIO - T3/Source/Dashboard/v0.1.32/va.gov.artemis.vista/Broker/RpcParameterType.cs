﻿namespace VA.Gov.Artemis.Vista.Broker
{
    internal enum RpcParameterType { Literal, Reference, List, Global, Empty, Stream, Undefined };
}
