﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VA.Gov.Artemis.Commands.Orwpt
{
    public class OrwptSelectPatient
    {
        public string Dfn { get; set; }
        public string PatientName { get; set; }
        public string Gender { get; set; }
        public string DOB { get; set; }
        public string SSN { get; set; }
        public string LocationIen { get; set; }
        public string LocationName { get; set; }
        public string RoomBed { get; set; }
        public string Cwad { get; set; }
        public string Sensitive { get; set; }
        public string Admitted { get; set; }
        public string Conv { get; set; }
        public string ServiceConnected { get; set; }
        public string ServiceConnectedPercent { get; set; }
        public string Icn { get; set; }
    }
}
