﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VA.Gov.Artemis.UI.Data.Models.Patient
{
    public class LabsIndex
    {
        public BasePatient Patient { get; set; }

        public List<LabTest> Labs { get; set; }

        public LabsIndex()
        {
            this.Labs = new List<LabTest>(); 
        }
    }
}
