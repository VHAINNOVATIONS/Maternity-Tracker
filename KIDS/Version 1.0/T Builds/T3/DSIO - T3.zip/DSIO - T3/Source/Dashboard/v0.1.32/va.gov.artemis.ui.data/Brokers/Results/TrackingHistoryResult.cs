﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VA.Gov.Artemis.UI.Data.Models.Aggregated;

namespace VA.Gov.Artemis.UI.Data.Brokers.Results
{
    public class TrackingHistoryResult: BrokerOperationResult
    {
        public List<TrackingEntry> TrackingEntries { get; set; }
        public int TotalEntries { get; set; }
    }
}
