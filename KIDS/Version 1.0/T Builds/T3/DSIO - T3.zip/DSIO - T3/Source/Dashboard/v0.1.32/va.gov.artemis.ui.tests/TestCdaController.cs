﻿//using System;
//using Microsoft.VisualStudio.TestTools.UnitTesting;
//using VA.Gov.Artemis.Vista.Broker;
//using VA.Gov.Artemis.UI.Mock;
//using VA.Gov.Artemis.UI.Controllers;
//using System.Web.Mvc;
//using VA.Gov.Artemis.UI.Data.Models.Cda;
//using VA.Gov.Artemis.Mock;
//using System.Web;

//namespace VA.Gov.Artemis.UI.Tests
//{
//    [TestClass]
//    public class TestCdaController
//    {
//        private string localPath = "C:\\Projects\\VA\\Artemis\\va.gov.artemis.ui";

//        [TestMethod]
//        public void TestIndexSuccess()
//        {
//            TestIndex(true); 
//        }

//        [TestMethod]
//        public void TestIndexFail()
//        {
//            TestIndex(false);
//        }

//        //private void TestIndex(bool success)
//        //{
//        //    IRpcBroker broker;

//        //    if (success)
//        //        broker = MockRpcBrokerFactory.GetCdaIndexSuccessBroker();
//        //    else
//        //        broker = MockRpcBrokerFactory.GetCdaIndexFailBroker();

//        //    IServerPaths serverPaths = new MockServerPaths(localPath);


//        //    CdaController controller = new CdaController(broker, serverPaths);

//        //    ActionResult result = controller.Index("");

//        //    Assert.IsNotNull(result);
//        //    Assert.IsInstanceOfType(result, typeof(ViewResult));

//        //    ViewResult viewResult = (ViewResult)result;
//        //    Assert.IsNotNull(viewResult); 
//        //    Assert.IsInstanceOfType(viewResult.Model, typeof(CdaIndex));

//        //    CdaIndex model = (CdaIndex)viewResult.Model;
//        //    Assert.IsNotNull(model.Patient);
//        //    Assert.AreNotEqual(success, model.Patient.NotFound);

//        //    // TODO: Add tests for exchange history data...

//        //}

//        [TestMethod]
//        public void TestOptionsSuccess()
//        {
//            TestOptions(true);
//        }

//        [TestMethod]
//        public void TestOptionsFail()
//        {
//            TestOptions(false);
//        }

//        //private void TestOptions(bool success)
//        //{
//        //    IRpcBroker broker;

//        //    if (success)
//        //        broker = MockRpcBrokerFactory.GetCdaOptionsSuccessBroker();
//        //    else
//        //        broker = MockRpcBrokerFactory.GetCdaOptionsFailBroker();

//        //    IServerPaths serverPaths = new MockServerPaths(localPath);

//        //    CdaController controller = new CdaController(broker, serverPaths);

//        //    ActionResult result = controller.Options("");

//        //    Assert.IsNotNull(result);
//        //    Assert.IsInstanceOfType(result, typeof(ViewResult));

//        //    ViewResult viewResult = (ViewResult)result;
//        //    Assert.IsNotNull(viewResult);
//        //    Assert.IsInstanceOfType(viewResult.Model, typeof(CdaOptions));

//        //    CdaOptions model = (CdaOptions)viewResult.Model;
//        //    Assert.IsNotNull(model.Patient);
//        //    Assert.AreNotEqual(success, model.Patient.NotFound);

//        //    // TODO: Add tests for options data...

//        //}

//        //[TestMethod]
//        //public void TestGenerateSuccess()
//        //{
//        //    TestGenerate(true);
//        //}

//        //[TestMethod]
//        //public void TestGenerateFail()
//        //{
//        //    TestGenerate(false);
//        //}

//        //private void TestGenerate(bool success)
//        //{
//        //    IRpcBroker broker;

//        //    if (success)
//        //        broker = MockRpcBrokerFactory.GetCdaGenerateSuccessBroker();
//        //    else
//        //        broker = MockRpcBrokerFactory.GetCdaGenerateFailBroker();

//        //    IServerPaths serverPaths = new MockServerPaths(localPath);

//        //    CdaController controller = new CdaController(broker, serverPaths);


//        //    ActionResult result = controller.Generate(
//        //        new CdaOptions() { Patient = new Data.Models.BasePatient() { Dfn = "123", FirstName="Test", LastName="Last" } });

//        //    Assert.IsNotNull(result);
//        //    Assert.IsInstanceOfType(result, typeof(ViewResult));

//        //    ViewResult viewResult = (ViewResult)result;
//        //    Assert.IsNotNull(viewResult);
//        //    Assert.IsInstanceOfType(viewResult.Model, typeof(CdaDocument));

//        //    CdaDocument model = (CdaDocument)viewResult.Model;
//        //    Assert.IsNotNull(model.Patient);
//        //    Assert.AreNotEqual(success, model.Patient.NotFound);

//        //    // TODO: Add tests for document data...
//        //    Assert.IsFalse(string.IsNullOrWhiteSpace(model.FileName));

//        //}

        
//    }
//}
