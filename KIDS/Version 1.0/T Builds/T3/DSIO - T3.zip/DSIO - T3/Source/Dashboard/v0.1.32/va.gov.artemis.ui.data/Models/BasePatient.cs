﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VA.Gov.Artemis.Vista.Utility;

namespace VA.Gov.Artemis.UI.Data.Models
{
    public class BasePatient
    {
        public string Dfn { get; set; }

        [Display(Name = "Last")]
        public string LastName { get; set; }

        [Display(Name = "First")]
        public string FirstName { get; set; }

        [Display(Name = "Last 4")]
        public string Last4 { get; set; }

        [Display(Name = "SSN")]
        public string FullSSN { get; set; }

        public DateTime DateOfBirth { get; set; }
        
        //public string DateOfBirthInexact { get; set; }
        public InexactDate DateOfBirthInexact { get; set; }

        // *** True if no patient or not found ***
        public bool NotFound { get; set; }

        [Display(Name = "DOB")]
        public string FormattedDob
        {
            get
            {
                string returnVal;

                if ((this.DateOfBirth == DateTime.MinValue) && (this.DateOfBirthInexact != null))
                    returnVal = this.DateOfBirthInexact.ToString(); 
                else 
                    returnVal = this.DateOfBirth.ToShortDateString();

                return returnVal;
            }
        }

        public string Age
        {
            get
            {
                // *** Calculate age based on dob or dob inexact ***

                string returnVal = "";

                DateTime dobToUse = DateTime.MinValue; 
                int tempAge = 0;

                // *** Determine which date to use for calculation ***
                if (this.DateOfBirth != DateTime.MinValue)
                    dobToUse = this.DateOfBirth;
                else if (this.DateOfBirthInexact != null)
                    if (this.DateOfBirthInexact.Approximation != DateTime.MinValue)
                        dobToUse = this.DateOfBirthInexact.Approximation;

                // *** If we have something to use, do calculation ***
                if (dobToUse != DateTime.MinValue)
                {
                    tempAge = DateTime.Now.Year - dobToUse.Year;
                    if (DateTime.Now.DayOfYear < dobToUse.DayOfYear)
                        tempAge -= 1;

                    returnVal = tempAge.ToString();
                }

                return returnVal; 
            }
        }

        public string Name
        {
            get
            {
                return string.Format("{0}, {1}", this.LastName, this.FirstName);
            }
        }

        public string FormattedSSN
        {
            get
            {
                string returnVal = "";

                if (!string.IsNullOrWhiteSpace(this.FullSSN))
                    if (this.FullSSN.Length == 9)
                        returnVal = this.FullSSN.Insert(5, "-").Insert(3, "-");
                    
                if (string.IsNullOrWhiteSpace(returnVal))
                    returnVal = this.FullSSN; 

                return returnVal; 
            }
        }
    }
}
