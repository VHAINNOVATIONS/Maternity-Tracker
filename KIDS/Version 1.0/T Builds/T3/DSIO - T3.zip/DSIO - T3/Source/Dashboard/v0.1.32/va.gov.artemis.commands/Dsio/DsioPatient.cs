﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VA.Gov.Artemis.Commands.Dsio
{
    public class DsioPatient
    {
        public string Dfn { get; set; }

        public string LastName { get; set; }

        public string FirstName { get; set; }

        public string Last4 { get; set; }

        public string DateOfBirth { get; set; }

    }
}
