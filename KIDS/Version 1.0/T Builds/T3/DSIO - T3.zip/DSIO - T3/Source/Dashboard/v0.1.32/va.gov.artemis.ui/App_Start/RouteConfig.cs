﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using NavigationRoutes;
using VA.Gov.Artemis.UI.Controllers; 

namespace VA.Gov.Artemis.UI
{
    public class RouteConfig
    {
        public static void RegisterRoutes(RouteCollection routes)
        {
            routes.IgnoreRoute("{resource}.axd/{*pathInfo}");

            routes.MapRoute(
                name: "NonVACareListIndex",
                url: "NonVACareList/Index/{page}",
                defaults: new { controller = "NonVACareList", action = "Index", page = UrlParameter.Optional }
                );

            routes.MapRoute(
                name: "NonVACareList",
                url: "NonVACareList/{action}/{ien}",
                defaults: new { controller = "NonVACareList", action = "Index", ien = UrlParameter.Optional }
                );


            routes.MapRoute(
                name: "PatientListOverview",
                url: "PatientList/Overview/{page}",
                defaults: new { controller = "PatientList", action = "Overview", page = UrlParameter.Optional }
                );

            routes.MapRoute(
                name: "NonVACareDetails",
                url: "NonVACare/Details/{dfn}",
                defaults: new { controller = "NonVACare", action = "Details"}
                );

            routes.MapRoute(
                name: "NonVACareEdit",
                url: "NonVACare/Edit/{itemType}/{dfn}",
                defaults: new { controller = "NonVACare", action = "Edit" }
                );

            routes.MapRoute(
                name: "PatientSearch",
                url: "PatientSearch/Search/{criteria}/{page}",
                defaults: new { controller = "PatientSearch", action = "Search", criteria = UrlParameter.Optional, page = UrlParameter.Optional }
                );

            routes.MapRoute(
                name: "TrackingHistory",
                url: "TrackingHistory/ByPatient/{dfn}/{page}",
                defaults: new { controller = "TrackingHistory", action = "ByPatient", dfn = UrlParameter.Optional, page = UrlParameter.Optional }
                );

            routes.MapRoute(
                name: "AllTrackingHistory",
                url: "TrackingHistory/All/{page}",
                defaults: new { controller = "TrackingHistory", action = "All", page = UrlParameter.Optional }
                );
            
            routes. MapRoute(
                name: "FlaggedPatientIndex", 
                url: "FlaggedPatients/Index/{page}", 
                defaults: new { controller = "FlaggedPatients", action="Index", page = UrlParameter.Optional}
                );

            routes.MapRoute(
                name: "FlaggedPatientDetails",
                url: "FlaggedPatients/Details/{dfn}/{page}",
                defaults: new { controller = "FlaggedPatients", action = "Details", dfn = UrlParameter.Optional, page= UrlParameter.Optional }
                );

            routes.MapRoute(
                name: "FlaggedPatientProgNote",
                url: "FlaggedPatients/ProgressNote/{dfn}/{ien}",
                defaults: new { controller = "FlaggedPatients", action = "ProgressNote", dfn = UrlParameter.Optional, ien = UrlParameter.Optional }
                );

            routes.MapRoute(
                name: "TrackRoute",
                url: "Track/{action}/{dfn}",
                defaults: new { controller = "Track", action = "Start"}
                );

            routes.MapRoute(
                name: "PatientSummary",
                url: "Patient/Summary/{dfn}",
                defaults: new { controller = "Patient", action = "Summary", dfn = UrlParameter.Optional }
                );

            routes.MapRoute(
                name: "PatientContactCreate",
                url: "PatientContact/Create/{noteType}/{dfn}",
                defaults: new { controller = "PatientContact", action = "Create" }
                );

            routes.MapRoute(
                name: "PatientContactNote",
                url: "PatientContact/ContactNote/{dfn}/{ien}",
                defaults: new { controller = "PatientContact", action = "Create" }
                );

            routes.MapRoute(
                name: "DashboardNoteIndex",
                url: "DashboardNote/Index/{dfn}/{page}",
                defaults: new { controller = "DashboardNote", action = "Index", page = UrlParameter.Optional }
                ); 

            routes.MapRoute(
                name: "DashboardNotes",
                url: "DashboardNote/{action}/{dfn}/{ien}",
                defaults: new { controller = "DashboardNote", action = "Index", ien = UrlParameter.Optional}
                );

            routes.MapRoute(
                name: "CdaDocView",
                url: "Cda/DocumentView/{dfn}/{ien}",
                defaults: new { controller = "Cda", action = "DocumentView" }
                );

            routes.MapRoute(
                name: "CdaPatientMatch",
                url: "Cda/PatientMatch/{dfn}/{page}",
                defaults: new { controller = "Cda", action = "PatientMatch", page=UrlParameter.Optional }
                );

            routes.MapRoute(
                name: "CdaRoute",
                url: "Cda/{action}/{dfn}/{page}",
                defaults: new { controller = "Cda", action = "Index", page = UrlParameter.Optional }
                );

            routes.MapRoute(
                name: "Default",
                url: "{controller}/{action}/{dfn}",
                defaults: new { controller = "Home", action = "Index", dfn = UrlParameter.Optional }
            );
        }
    }
}