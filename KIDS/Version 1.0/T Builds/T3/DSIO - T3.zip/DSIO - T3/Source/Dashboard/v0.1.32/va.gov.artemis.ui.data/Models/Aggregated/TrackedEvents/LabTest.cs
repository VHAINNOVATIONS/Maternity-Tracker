﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace VA.Gov.Artemis.UI.Data.Models.Aggregated.TrackedEvents
{
    public class LabTest
    {
        public string TestId { get; set; }
        public string TestName { get; set; }
        public string ResultOrStatus { get; set; }
        public string Flag { get; set; }
        public string Units { get; set; }
        public string RefRange { get; set; }
    }
}