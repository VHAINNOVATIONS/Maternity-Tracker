﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VA.Gov.Artemis.UI.Data.Brokers.Results;
using VA.Gov.Artemis.UI.Data.Models;

namespace VA.Gov.Artemis.UI.Data.Brokers
{
    public interface ISettingsRepository
    {
        ServerConfigResult GetServerData();

        BrokerOperationResult SetServerData(ServerConfig serverConfig);

        BrokerOperationResult TestServerConnection(string serverName, string serverPort);
    }
}
