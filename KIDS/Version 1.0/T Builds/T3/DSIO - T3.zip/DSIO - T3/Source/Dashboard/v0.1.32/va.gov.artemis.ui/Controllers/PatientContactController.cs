﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using VA.Gov.Artemis.UI.Data.Brokers.Results;
using VA.Gov.Artemis.UI.Data.Models;
using VA.Gov.Artemis.UI.Filters;

namespace VA.Gov.Artemis.UI.Controllers
{
    [Authorize]
    [VerifySession]
    [DisableLocalCache]
    public class PatientContactController :DashboardController
    {
        [HttpGet]
        public ActionResult Index(string dfn)
        {
            PatientContactIndexModel model = new PatientContactIndexModel();

            // *** Get patient demographics ***
            model.Patient = this.CurrentPatient;

            // *** Check for success ***
            if (!model.Patient.NotFound)
            {                
                // TODO: Use real data here...
                model.LastContactDate = DateTime.Now.Subtract(new TimeSpan(30, 0, 0, 0));
                model.NextContact = DateTime.Now.Add(new TimeSpan(5, 0, 0, 0)).ToShortDateString();

                model.ContactItems.Add(new PatientContactItem() { ItemDateTime = new DateTime(2013, 9, 24), UserName = "MccCoord, Test", Details = "First trimester call" });
                model.ContactItems.Add(new PatientContactItem() { ItemDateTime = new DateTime(2013, 10, 10), UserName = "MccCoord, Test", Details = "First trimester follow-up" });
                model.ContactItems.Add(new PatientContactItem() { ItemDateTime = model.LastContactDate, UserName = "MccCoord, Test", Details = "Second trimester call" });
            }

            model.ReturnUrl = Url.Action("Summary", "Patient", new { dfn = dfn });

            return View(model);
        }

        [HttpGet]
        public ActionResult Create(string noteType, string dfn)
        {
            PatientContactCreateModel model = new PatientContactCreateModel();

            model.NoteType = noteType; 
            
            // *** Get patient demographics ***
            model.Patient = this.CurrentPatient;

            model.ReturnUrl = Url.Action("Index", "PatientContact", new { id = dfn });

            return View(model);
        }

        [HttpPost]
        public ActionResult Create(PatientContactCreateModel model)
        {
            return RedirectToAction("Preview", new {id=model.Patient.Dfn });
        }

        [HttpGet]
        public ActionResult Preview(string id)
        {
            PatientContactCreateModel model = new PatientContactCreateModel();

            PatientDemographicsResult result = this.DashboardRepository.Patients.GetPatientDemographics(id);

            if (result.Success)
                model.Patient = result.Patient;
            else
                model.Patient = new BasePatient() { FirstName = "Unknown", LastName = "Test", Last4 = "1234", DateOfBirth = DateTime.Now.AddYears(-25) };

            return View(model); 
        }

        [HttpGet]
        public ActionResult ContactNote(string dfn, string ien)
        {
            PatientContactNoteModel model = new PatientContactNoteModel();

            // *** Get patient demographics ***
            model.Patient = this.CurrentPatient;

            // *** Check for success ***
            if (!model.Patient.NotFound)
            {                
                TiuNoteResult noteResult = this.DashboardRepository.Notes.GetProgressNote(ien);

                if (noteResult.Success)
                {
                    model.ContactItem = new PatientContactItem();
                    model.ContactItem.ProgressNoteText = noteResult.Note.NoteText;
                }
            }

            model.ReturnUrl = Url.Action("Index",new {id=dfn});

            return View(model);
        }

    }
}
