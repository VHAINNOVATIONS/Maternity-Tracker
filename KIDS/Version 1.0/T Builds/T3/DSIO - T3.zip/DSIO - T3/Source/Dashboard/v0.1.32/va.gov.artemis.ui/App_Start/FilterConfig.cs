﻿using System.Web;
using System.Web.Mvc;

namespace VA.Gov.Artemis.UI
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new HandleErrorAttribute());

            // TODO: Add for https...
            //filters.Add(new RequireHttpsAttribute());
        }
    }
}