﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Composition.Hosting;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.ComponentModel.Composition;

namespace va.gov.artemis.ui.Controllers
{
    //public class MefControllerFactory: IControllerFactory
    //{
    //    [Export]
    //    private string pluginPath;

    //    private DirectoryCatalog catalog;
    //    private CompositionContainer container;

    //    private DefaultControllerFactory defaultControllerFactory;

    //    public MefControllerFactory(string pluginPath)
    //    {
    //        this.pluginPath = pluginPath;
    //        this.catalog = new DirectoryCatalog(pluginPath);
    //        this.container = new CompositionContainer(catalog);

    //        this.defaultControllerFactory = new DefaultControllerFactory();
    //    }


    //    public IController CreateController(System.Web.Routing.RequestContext requestContext, string controllerName)
    //    {
    //        IController controller = null;

    //        if (controllerName != null)
    //        {
    //            string controllerClassName = controllerName + "Controller";

    //            Export<IController> export = this.container.GetExports<IController>()
    //                .Where(c => c.Metadata.ContainsKey("controllerName")
    //                    && c.Metadata["controllerName"].ToString() == controllerName)
    //                    .FirstOrDefault(); 
    //        }
            
    //    }

    //    public System.Web.SessionState.SessionStateBehavior GetControllerSessionBehavior(System.Web.Routing.RequestContext requestContext, string controllerName)
    //    {
    //        throw new NotImplementedException();
    //    }

    //    public void ReleaseController(IController controller)
    //    {
    //        throw new NotImplementedException();
    //    }
    //}

    public class MefControllerFactor : DefaultControllerFactory
    {
        private readonly CompositionContainer _compositionContainer;

        public MefControllerFactor(CompositionContainer compositionContainer)
        {
            this._compositionContainer = compositionContainer; 
        }

        protected override IController GetControllerInstance(System.Web.Routing.RequestContext requestContext, Type controllerType)
        {
            //return base.GetControllerInstance(requestContext, controllerType);

            var export = _compositionContainer.GetExports(controllerType, null, null).SingleOrDefault();

            IController result;

            if (null != export)
                result = export.Value as IController;
            else
            {
                result = base.GetControllerInstance(requestContext, controllerType);
                _compositionContainer.ComposeParts(result);
            }

            return result; 
        }

    }

}