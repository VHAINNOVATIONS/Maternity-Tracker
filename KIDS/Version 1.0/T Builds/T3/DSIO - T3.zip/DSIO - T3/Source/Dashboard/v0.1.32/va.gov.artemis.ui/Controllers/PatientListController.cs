﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using VA.Gov.Artemis.UI.Data.Brokers.Results;
using VA.Gov.Artemis.UI.Data.Models.Aggregated;
using VA.Gov.Artemis.UI.Filters;

namespace VA.Gov.Artemis.UI.Controllers
{
    [Authorize]
    [VerifySession]
    [DisableLocalCache]
    public class PatientListController : DashboardController
    {
        private const int ItemsPerPage = 10;

        [HttpGet]
        public ActionResult Overview(string page)
        {
            // *** Basic list of tracked patients ***

            ActionResult returnValue;
            TrackedPatients model = new TrackedPatients();

            int pageNum = GetPage(page);

            // *** Get the patients from the repository ***
            TrackedPatientsResult result = this.DashboardRepository.Patients.GetTrackedPatients(pageNum, ItemsPerPage);

            // *** Assign model based on result ***
            if (result.Success)
            {
                model.List.AddRange(result.Patients);

                model.Paging.SetPagingData(ItemsPerPage, pageNum, result.TotalResults);
                model.Paging.BaseUrl = Url.Action("Overview", "PatientList", new { page = "" });

                TempData[LastPatientListUrl] = Url.Action("Overview", "PatientList", new { page = pageNum });
            }
            else
                this.Error(result.Message);

            // *** Set the return value ***
            returnValue = View(model);

            return returnValue;
        }
    }
}
