﻿using VA.Gov.Artemis.Vista.Broker;
using VA.Gov.Artemis.UI.Data.Brokers.Results;
using VA.Gov.Artemis.UI.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace VA.Gov.Artemis.UI.Data.Brokers
{
    public class DashboardRepository: IDashboardRepository
    {
        private IRpcBroker rpcBroker { get; set; }

        public IAccountRepository Accounts { get; set; }

        public IDivisionRepository Divisions { get; set; }

        public ISettingsRepository Settings { get; set; }

        public IPatientRepository Patients { get; set; }

        public ISelectListRepository SelectLists { get; set; }

        public ITrackingHistoryRepository TrackingHistory { get; set; }

        public INoteRepository Notes { get; set; }

        public INonVACareRepository NonVACare { get; set; }

        public ICdaRepository CdaDocuments { get; set; }

        public DashboardRepository()
        {
            this.Settings = new SettingsRepository(); 
        }

        public void SetRpcBroker(IRpcBroker broker)
        {
            this.rpcBroker = broker;

            this.Accounts = new AccountRepository(rpcBroker);
            this.Divisions = new DivisionRepository(rpcBroker);
            this.Patients = new PatientRepository(rpcBroker);
            this.SelectLists = new SelectListRepository(rpcBroker);
            this.TrackingHistory = new TrackingHistoryRepository(rpcBroker);
            this.Notes = new NoteRepository(rpcBroker);
            this.NonVACare = new NonVACareRepository(rpcBroker);
            this.CdaDocuments = new CdaRepository(rpcBroker);
        }

    }
}