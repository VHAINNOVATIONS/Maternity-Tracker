﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//using VA.Gov.Artemis.Commands.Orqqpl;
using VA.Gov.Artemis.UI.Data.Brokers.Results;
using VA.Gov.Artemis.UI.Data.Models.Patient;
using VA.Gov.Artemis.Vista.Broker;
using VA.Gov.Artemis.Vista.Utility;

namespace VA.Gov.Artemis.UI.Data.Brokers
{
    public class ProblemRepository : RepositoryBase, IProblemRepository 
    {
        public ProblemRepository(IRpcBroker newBroker): base(newBroker){}

        public ProblemListResult GetList(string dfn)
        {
            ProblemListResult returnResult = new ProblemListResult();

            OrqqplProblemListCommand command = new OrqqplProblemListCommand(this.broker);

            command.AddCommandParameters(dfn); 

            RpcResponse response = command.Execute();

            returnResult.Success = (response.Status == RpcResponseStatus.Success);

            if (!returnResult.Success)
                returnResult.Message = response.InformationalMessage;
            else
            {
                foreach (OrqqplProblem orqqplProblem in command.Problems)
                {
                    Problem problem = new Problem()
                    {
                        Description = orqqplProblem.Problem, 
                        DxCode = orqqplProblem.DxCode, 
                        ProblemDateTime = Util.GetDateTime(orqqplProblem.ProblemDateTime)

                    };

                    returnResult.Problems.Add(problem); 
                }
            }

            return returnResult; 
        }
    }
}
