﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using VA.Gov.Artemis.UI.Data.Brokers.Results;
using VA.Gov.Artemis.UI.Data.Models.Patient;
using VA.Gov.Artemis.UI.Filters;

namespace VA.Gov.Artemis.UI.Controllers
{
    [Authorize]
    [VerifySession]
    [DisableLocalCache]
    public class ProblemController : DashboardController
    {

        [HttpGet]
        public ActionResult Index(string dfn)
        {
            ProblemListModel model = new ProblemListModel();

            ProblemListResult result = this.DashboardRepository.Problems.GetList(dfn);

            if (!result.Success)
                this.Error(result.Message);
            else
            {
                model.Problems = result.Problems; 

                // *** Get patient demographics ***
                model.Patient = this.CurrentPatient;

            }

            return View(model);
        }

    }
}
