﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VA.Gov.Artemis.Vista.Broker;
using VA.Gov.Artemis.Vista.Utility;

namespace VA.Gov.Artemis.Commands.Dsio
{
    public class DsioIheSaveCommand: DsioCommand
    {
        public DsioIheSaveCommand(IRpcBroker newBroker): base(newBroker)
        {

        }

        public override string RpcName
        {
            get { return "DSIO IHE SAVE"; }
        }


        public void AddCommandArguments(string id, string dfn, string direction, 
            string createDateTime, string importExportDateTime, 
            string docType, string docTitle, string sendingEntity, 
            string intendedRecipient, string content )
        {
            string[] contentArray = (string.IsNullOrWhiteSpace(content)) ? null : Util.Split(content);

            this.CommandArgs = new object[] { id, dfn, direction, createDateTime, importExportDateTime, docType, docTitle, sendingEntity, intendedRecipient, contentArray };
        }

        protected override void ProcessResponse()
        {
            if (string.IsNullOrWhiteSpace(this.Response.Data))
            {
                this.Response.Status = RpcResponseStatus.Fail;
                this.Response.InformationalMessage = "No return value";
            }
            else
            {
                string piece1 = Util.Piece(this.Response.Lines[0], Caret, 1);
                string piece2 = Util.Piece(this.Response.Lines[0], Caret, 2);

                int returnCode = -1; 

                int.TryParse(piece1, out returnCode); 

                if (returnCode < 1)
                {
                    this.Response.Status = RpcResponseStatus.Fail;
                    this.Response.InformationalMessage = piece2;
                }
                else 
                    this.Response.Status = RpcResponseStatus.Success;
    
            }
        }

    }
}
