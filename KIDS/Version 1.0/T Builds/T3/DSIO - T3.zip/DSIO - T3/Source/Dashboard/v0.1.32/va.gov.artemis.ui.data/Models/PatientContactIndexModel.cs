﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VA.Gov.Artemis.UI.Data.Models
{
    public class PatientContactIndexModel
    {
        public BasePatient Patient { get; set; }

        public DateTime LastContactDate { get; set; }

        public DateTime NextContactDate { get; set; }

        // TODO: Have next contact be derived from date...
        public string NextContact { get; set; }

        public string ReturnUrl { get; set; }

        public List<PatientContactItem> ContactItems { get; set; }

        public PatientContactIndexModel()
        {
            this.ContactItems = new List<PatientContactItem>();
        }
    }
}
