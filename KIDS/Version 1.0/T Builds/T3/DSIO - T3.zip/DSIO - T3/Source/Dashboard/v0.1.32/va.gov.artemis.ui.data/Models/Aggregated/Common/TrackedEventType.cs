﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace VA.Gov.Artemis.UI.Data.Models.Aggregated.Common
{
    public enum TrackedEventType { MccContact, Lab, Ultrasound, Consult, EducationalMaterials, 
        Order, ClinicalReminder, Appointment, RecordTransfer, OutsideCareInfo, ProgramEnrollment, 
        LastMenstrualPeriod, EstimatedDeliveryDate, DeliveryDate, DischargeDate, Other }
}