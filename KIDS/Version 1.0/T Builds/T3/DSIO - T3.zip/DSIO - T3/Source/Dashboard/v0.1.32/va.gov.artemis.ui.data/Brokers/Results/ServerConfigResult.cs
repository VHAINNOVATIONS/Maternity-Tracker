﻿using VA.Gov.Artemis.UI.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace VA.Gov.Artemis.UI.Data.Brokers.Results
{
    public class ServerConfigResult: BrokerOperationResult
    {
        public ServerConfig ServerConfig { get; set; }

        public ServerConfigResult()
        {
            this.ServerConfig = new ServerConfig(); 
        }
    }
}