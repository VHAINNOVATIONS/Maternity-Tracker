﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using VA.Gov.Artemis.UI.Data.Brokers.Results;
using VA.Gov.Artemis.UI.Data.Models;
using VA.Gov.Artemis.UI.Data.Models.Aggregated;
using VA.Gov.Artemis.UI.Filters;

namespace VA.Gov.Artemis.UI.Controllers
{
    [DisableLocalCache]
    [VerifySession]
    [Authorize]
    public class PatientController : DashboardController
    {
        [HttpGet]
        public ActionResult Summary(string dfn)
        {
            // TODO: Use real data for patient summary...

            // *** Create new model ***
            PatientSummary model = new PatientSummary();

            // *** Get patient demographics ***
            model.Patient = this.CurrentPatient;

            // *** Check for success ***
            if (!model.Patient.NotFound)
            {                
                model.Pregnant = "Yes";
                model.EDD = new DateTime(2014, 3, 3);
                model.GestationalAge = "24 weeks 2 days";
                model.Trimester = 2;
                model.Multiple = "No";

                model.Lactating = "No";
                model.LastContact = new DateTime(2013, 12, 12);
                model.NextContact = new DateTime(2014, 2, 12);
                model.PrenatalCareProvider = "Dr. Outside Care OB/GYN";
                model.PlannedDeliveryLocation = "University Hospital"; 
                
            }

            // *** Set return url ***
            if (TempData.ContainsKey(LastPatientListUrl))
            {
                model.ReturnUrl = TempData[LastPatientListUrl].ToString();

                TempData.Keep(LastPatientListUrl);

                // *** Indicate how to get back here ***
                TempData[ReturnUrl] = Url.Action("Summary", "Patient", new { dfn = dfn });
            }

            return View(model);
        }

        //[HttpGet]
        //public ActionResult Timeline(string patientId)
        //{
        //    TrackedPatient model = this.DashboardRepository.Patients.Get("1234");

        //    return View(model);

        //}
    }
}
