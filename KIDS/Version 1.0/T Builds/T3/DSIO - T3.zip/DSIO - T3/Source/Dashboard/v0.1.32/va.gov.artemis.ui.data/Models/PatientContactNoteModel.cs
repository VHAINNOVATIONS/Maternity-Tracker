﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VA.Gov.Artemis.UI.Data.Models
{
    public class PatientContactNoteModel
    {
        public BasePatient Patient { get; set; }
        public PatientContactItem ContactItem { get; set; }
        public string ReturnUrl { get; set; }
    }
}
