﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VA.Gov.Artemis.UI.Data.Models.Aggregated
{
    public class CreateTrackingEntry
    {
        public string PageTitle { get; set; }

        public string PageMessage { get; set; }

        public TrackingEntry TrackingEntry { get; set; }

        public string ButtonText { get; set; }

        public List<string> Reasons { get; set; }

        public string ReasonText { get; set; }

        public BasePatient Patient { get; set; }

        public string ReturnUrl { get; set; }
    }
}
