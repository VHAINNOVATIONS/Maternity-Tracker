﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;
using VA.Gov.Artemis.Cda;
using VA.Gov.Artemis.Commands.Dsio;
using VA.Gov.Artemis.Commands.Vpr;
using VA.Gov.Artemis.Commands.Vpr.Data;
using VA.Gov.Artemis.UI.Data.Brokers.Results;
using VA.Gov.Artemis.UI.Data.Models.Cda;
using VA.Gov.Artemis.Vista.Broker;
using VA.Gov.Artemis.Vista.Utility;

namespace VA.Gov.Artemis.UI.Data.Brokers
{
    public class CdaRepository: RepositoryBase, ICdaRepository
    {
        // *** Names and abbreviations for the document types - index is DocumentType enum ***
        private string[] DocumentTypeName = {"Antepartum History & Physical", "Antepartum Summary", "Antepartum Laboratory", "Antepartum Education", "Maternal Discharge Summary", "Newborn Discharge Summary", "Postpartum Visit Summary", "Imaging Report"};
        private string[] DocumentTypeAbbreviation = { "APHP", "APS", "APL", "APE", "MDS", "NDS", "PPVS", "XDR-I" };

        public CdaRepository(IRpcBroker tempBroker): base(tempBroker)
        { }
        
        public BrokerOperationResult SaveDocument(CdaDocumentData documentData)
        {
            // *** Save a document to vista ***

            BrokerOperationResult result = new BrokerOperationResult();

            // *** Strings for direction to be stored in VistA ***
            string[] ExchangeDirectionDescription = {"IN", "OUT"}; 
 
            if (this.broker != null)
            {
                // *** Create the command ***
                DsioIheSaveCommand command = new DsioIheSaveCommand(broker);

                // *** Add the arguments ***
                command.AddCommandArguments(
                    documentData.Id, 
                    documentData.PatientDfn,
                    ExchangeDirectionDescription[(int)documentData.ExchangeDirection],
                    documentData.CreationDateTime.ToString(),
                    documentData.ImportDateTime.ToString(),
                    DocumentTypeAbbreviation[(int)documentData.DocumentType],
                    documentData.Title,
                    documentData.Sender,
                    documentData.IntendedRecipient,
                    documentData.DocumentContent);

                // *** Execute and get response ***
                RpcResponse response = command.Execute();

                // *** Add command response to result ***
                result.Success = (response.Status == RpcResponseStatus.Success);
                result.Message = response.InformationalMessage; 
            }

            return result; 
        }

        public CdaDocumentResult Generate(CdaOptions options)
        {
            // *** Generate a document based on options ***

            CdaDocumentResult result = new CdaDocumentResult();

            // *** Create an id for the document ***
            result.DocumentData.Id = Guid.NewGuid().ToString();

            // *** Call cda generation ***
            result.DocumentData.DocumentContent = GetDocumentContent(result.DocumentData.Id, options);

            if (!string.IsNullOrWhiteSpace(result.DocumentData.DocumentContent))
            {
                // *** Prepare header ***                
                result.DocumentData.PatientDfn = options.Patient.Dfn;
                result.DocumentData.CreationDateTime = DateTime.Now;
                result.DocumentData.DocumentType = options.DocumentType;
                result.DocumentData.ExchangeDirection = ExchangeDirection.Outbound;
                result.DocumentData.IntendedRecipient = options.IntendedRecipient;

                // *** TODO: Sender will be based on author ***
                result.DocumentData.Sender = "VA Salt Lake City";

                // *** Document Names ****
                string docName = DocumentTypeName[(int)options.DocumentType];

                // *** Title is based on sender and name ***
                result.DocumentData.Title = string.Format("{0} {1}", result.DocumentData.Sender, docName);

                result.Success = true;
            }
            else
                result.Message = "Could not generate document"; 

            return result; 
        }

        public string GetDocumentAbbreviation(IheDocumentType iheDocumentType)
        {
            return DocumentTypeAbbreviation[(int)iheDocumentType];
        }

        public CdaDocumentListResult GetExchangeHistory(string patientDfn, int page, int itemsPerPage)
        {
            // *** Get list of exchanged documents for a patient ***
            // *** Supports paging ***

            CdaDocumentListResult result = new CdaDocumentListResult();

            // *** Check broker ***
            if (this.broker != null)
            {
                // *** Create the command ***
                DsioIhePatientListCommand command = new DsioIhePatientListCommand(this.broker);

                // *** Add the arguments, patient, paging ***
                command.AddCommandArguments(patientDfn, page, itemsPerPage);

                // *** Execute the command ***
                RpcResponse response = command.Execute();

                // *** Add results to return ***
                result.Success = (response.Status == RpcResponseStatus.Success);
                result.Message = response.InformationalMessage;

                // *** If successful, continue ***
                if (result.Success)
                {
                    // *** Add total results to return ***
                    result.TotalResults = command.TotalResults; 

                    // *** Check if we have something and loop ***
                    if (command.DocumentList != null) 
                        if (command.DocumentList.Count > 0)
                            foreach (DsioCdaDocument dsioDoc in command.DocumentList)
                            {
                                // *** Create strongly typed object from string-based Dsio object ***
                                CdaDocumentData docData = GetDocumentData(dsioDoc);

                                // *** If we have something to work with... ***
                                if (docData != null)
                                {
                                    // *** Add patient dfn ***
                                    docData.PatientDfn = patientDfn;

                                    // *** Add to return list ***
                                    result.DocumentList.Add(docData);
                                }
                            }
                }
            }

            return result; 
        }

        public CdaDocumentResult GetDocumentData(string ien)
        {
            // *** Get data for a single document (Header and Content) ***

            CdaDocumentResult result = new CdaDocumentResult();

            // *** Check broker ***
            if (this.broker != null)
            {
                // *** Create the command ***
                DsioIheGetDocCommand command = new DsioIheGetDocCommand(this.broker);

                // *** Add arguments for content only ***
                command.AddCommandArguments(ien, false);

                // *** Execute ***
                RpcResponse response = command.Execute();

                // *** Record success/message ***
                result.Success = (response.Status == RpcResponseStatus.Success);
                result.Message = response.InformationalMessage;

                // *** If successful continue ***
                if (result.Success)
                {
                    // *** Hold the content ***
                    string tempContent = command.Document.Content;

                    // *** Reuse same command, add new arguments, header info this time ***
                    command.AddCommandArguments(ien, true);

                    // *** Execute the command ***
                    response = command.Execute();
                    
                    // *** Add results to return ***
                    result.Success = (response.Status == RpcResponseStatus.Success);
                    result.Message = response.InformationalMessage;

                    // *** If successful continue ***
                    if (result.Success)
                    {
                        // *** Get the document (header) data ***
                        result.DocumentData = GetDocumentData(command.Document);

                        // *** Add the content from previous call ***
                        result.DocumentData.DocumentContent = tempContent;

                        // *** Repopulate ien ***
                        result.DocumentData.Ien = ien; 
                    }
                }
            }

            return result; 
        }

        public BrokerOperationResult DocumentIsSupported(string documentContent)
        {
            // *** Check if the xml for the passed-in content is supported ***

            BrokerOperationResult result = new BrokerOperationResult();

            POCD_MT000040ClinicalDocument clinicalDocument = this.DeserializeContent(documentContent);

            if (clinicalDocument != null)
            {
                // TODO: Support proper document type

                // *** Look for document template id matching supported ***
                // *** For now only APHP, but could be CCD or other IHE template ***

                if (clinicalDocument.templateId != null)
                    if (clinicalDocument.templateId.Length > 0)
                        foreach (II templateId in clinicalDocument.templateId)
                            if (templateId.root == AphpDocument.AphpTemplateId)
                                result.Success = true;

            }

            if (!result.Success)
                result.Message = "This is not a supported document format";

            return result;
        }

        private CdaDocumentData GetDocumentData(DsioCdaDocument dsioDoc)
        {
            // *** Gets strongly typed Cda data from Dsio data ***
            CdaDocumentData returnDocument = new CdaDocumentData();

            // *** Convert Create Date to DateTime ***
            CultureInfo enUS = new CultureInfo("en-US");
            DateTime tempDateTime;
            if (DateTime.TryParseExact(dsioDoc.CreatedOn, RepositoryDates.VistADateFormatOne, enUS, DateTimeStyles.None, out tempDateTime))
                returnDocument.CreationDateTime = tempDateTime;

            // *** Convert Import/Export to DateTime ***
            if (DateTime.TryParseExact(dsioDoc.ImportExportDate, RepositoryDates.VistADateFormatOne, enUS, DateTimeStyles.None, out tempDateTime))
                returnDocument.ImportDateTime = tempDateTime;

            // *** Get index of value which will match enum ***
            int idx = Array.IndexOf(this.DocumentTypeAbbreviation, dsioDoc.DocumentType);

            // *** Convert to enum ***
            if (idx > -1)
                returnDocument.DocumentType = (IheDocumentType)idx;

            // *** Determine if in/out ***
            returnDocument.ExchangeDirection = (dsioDoc.Direction == "IN") ? ExchangeDirection.Inbound : ExchangeDirection.Outbound;

            // *** Populate id's as is ***
            returnDocument.Id = dsioDoc.Id;
            returnDocument.Ien = dsioDoc.Ien;

            // *** Populate as is ***
            returnDocument.IntendedRecipient = dsioDoc.IntendedRecipient;
            returnDocument.Sender = dsioDoc.Sender;
            returnDocument.Title = dsioDoc.Title;

            return returnDocument; 
        }

        public PatientDemographicsResult GetDocumentPatient(string documentContent)
        {
            PatientDemographicsResult result = new PatientDemographicsResult();

            POCD_MT000040ClinicalDocument doc = DeserializeContent(documentContent);

            if (doc != null)
            {
                if (doc.recordTarget != null)
                    if (doc.recordTarget.Length > 0)
                    {
                        POCD_MT000040RecordTarget recTarget = doc.recordTarget[0];
                        if (recTarget.patientRole != null)
                        {
                            if (result.Patient == null)
                                result.Patient = new Models.BasePatient();

                            // *** SSN ***
                            if (recTarget.patientRole.id != null)
                                foreach (II tempII in recTarget.patientRole.id) 
                                    if (tempII.root == "2.16.840.1.113883.4.1")
                                        if (!string.IsNullOrWhiteSpace(tempII.extension))
                                        {
                                            result.Patient.FullSSN = tempII.extension;
                                            result.Patient.Last4 = result.Patient.FullSSN.Substring(5, 4);
                                        }

                            if (recTarget.patientRole.patient != null)
                            {
                                POCD_MT000040Patient pat = recTarget.patientRole.patient;

                                DateTime dob;
                                CultureInfo enUS = new CultureInfo("en-US");

                                // *** DOB ***
                                if (pat.birthTime != null)
                                    if (!string.IsNullOrWhiteSpace(pat.birthTime.value))
                                        if (DateTime.TryParseExact(pat.birthTime.value, "yyyyMMdd", enUS, DateTimeStyles.None, out dob))
                                            result.Patient.DateOfBirth = dob;

                                // *** Name ***
                                if (pat.name != null)
                                    if (pat.name.Length > 0)
                                    {
                                        PN name = pat.name[0];
                                        if (name.Items != null)
                                            if (name.Items.Length > 0)
                                                foreach (ENXP enxp in name.Items)
                                                    if (enxp.Text != null)
                                                        if (enxp.Text.Length > 0)
                                                        {
                                                            if (enxp is engiven)
                                                                result.Patient.FirstName = enxp.Text[0];
                                                            else if (enxp is enfamily)
                                                                result.Patient.LastName = enxp.Text[0];
                                                        }
                                    }
                            }
                        }
                    }
            }

            // *** Success if we found a first and last name ***
            if (result.Patient != null)
                if (!string.IsNullOrWhiteSpace(result.Patient.LastName))
                    if (!string.IsNullOrWhiteSpace(result.Patient.FirstName))
                        result.Success = true;

            if (!result.Success)
                result.Message = "Patient information could not be retrieved from this document"; 

            return result; 
        }

        public CdaDocumentResult ExtractDocumentData(string documentContent)
        {
            CdaDocumentResult result = new CdaDocumentResult();

            POCD_MT000040ClinicalDocument doc = DeserializeContent(documentContent);

            if (doc != null)
            {
                DateTime effectiveTime;
                CultureInfo enUS = new CultureInfo("en-US");

                // *** Document Date/Time ***
                if (doc.effectiveTime != null)
                    if (!string.IsNullOrWhiteSpace(doc.effectiveTime.value))
                        if (DateTime.TryParseExact(doc.effectiveTime.value, CdaDocument.CdaDateFormat, enUS, DateTimeStyles.None, out effectiveTime))
                            result.DocumentData.CreationDateTime = effectiveTime;

                // *** TODO: Check all document types ***
                if (doc.templateId != null)
                    if (doc.templateId.Length > 0)
                        foreach (II templateId in doc.templateId)
                            if (templateId.root == AphpDocument.AphpTemplateId)
                                result.DocumentData.DocumentType = IheDocumentType.APHP;

                // *** Get document id ***
                if (doc.id != null)
                    result.DocumentData.Id = doc.id.root;

                // *** Sender ***
                if (doc.recordTarget != null)
                    if (doc.recordTarget.Length > 0)
                        if (doc.recordTarget[0].patientRole != null)
                            if (doc.recordTarget[0].patientRole.providerOrganization != null)
                                if (doc.recordTarget[0].patientRole.providerOrganization.name != null)
                                    if (doc.recordTarget[0].patientRole.providerOrganization.name[0].Text != null)
                                        result.DocumentData.Sender = doc.recordTarget[0].patientRole.providerOrganization.name[0].Text[0];

                // *** Title ***
                if (doc.title != null)
                    if (doc.title.Text != null)
                        if (doc.title.Text.Length > 0)
                            result.DocumentData.Title = doc.title.Text[0];

                // TODO: Get information recipient for header 

                result.Success = true;
            }
            else
                result.Message = "Could not extract data from the document"; 

            return result; 
        }

        private POCD_MT000040ClinicalDocument DeserializeContent(string content)
        {
            POCD_MT000040ClinicalDocument returnDocument = null; 

            // *** Create a generic CDA serializer ***
            XmlSerializer serializer = new XmlSerializer(typeof(POCD_MT000040ClinicalDocument));

            // *** Create an xml reader ***
            using (XmlReader xmlReader = XmlReader.Create(new StringReader(content)))
            {
                // *** Check if it can deserialize ***
                if (serializer.CanDeserialize(xmlReader))
                {
                    // *** Deserialize ***
                    returnDocument = (POCD_MT000040ClinicalDocument)serializer.Deserialize(xmlReader);
                }
            }

            return returnDocument;
        }

        // TODO: Code cleanup and comments for below code...

        private string GetDocumentContent(string docId, CdaOptions options)
        {
            string returnVal = "";

            // *** Get data from vista ***
            VprPatientResult vprData = GetVprData(options);

            if (vprData != null)
            {
                // *** Transform to Cda ***
                //AphpDocument aphpDoc = new AphpDocument();

                IheDocument iheDoc;

                switch (options.DocumentType) 
                {
                    case IheDocumentType.APHP:
                        iheDoc = new AphpDocument(); 
                        break;
                    default:
                        iheDoc = new AphpDocument(); 
                        break;
                        }
                        

                // *** Set id ***
                iheDoc.id = new II() { root = docId };

                // *** Create Record Target Section ***
                iheDoc.recordTarget = new POCD_MT000040RecordTarget[1];
                iheDoc.recordTarget[0] = CreateRecordTargetSection(vprData.Demographics);

                // *** Create Author Section ***
                iheDoc.author = CreateAuthorSection(); 

                // *** Create serializer for specific document ***
                XmlSerializer serializer = new XmlSerializer(typeof(AphpDocument));

                // *** Add some xml settings ***
                XmlWriterSettings settings = new XmlWriterSettings();
                settings.Encoding = Encoding.UTF8;
                settings.Indent = true;
                settings.NewLineHandling = NewLineHandling.Replace;

                // *** Get a temp file name ***
                string tempFile = Path.GetTempFileName();

                // *** Create a file stream writer ****
                using (StreamWriter output = new StreamWriter(new FileStream(tempFile, FileMode.Create), Encoding.UTF8))
                {
                    // *** Create xml writer ***
                    using (XmlWriter xmlWriter = XmlWriter.Create(output, settings))
                    {
                        // *** Add the style sheet processing instruction ***
                        xmlWriter.WriteProcessingInstruction("xml-stylesheet", "type=\"text/xsl\" href=\"CDA.xsl\"");

                        // *** Perform serialization ***
                        serializer.Serialize(xmlWriter, iheDoc);
                    }
                }

                // *** Grab the text as it is in the file ***
                returnVal = File.ReadAllText(tempFile);

                // **** Delete the temporary file ***
                File.Delete(tempFile);
            }

            return returnVal; 
        }

        private VprPatientResult GetVprData(CdaOptions options)
        {
            VprPatientResult returnVal = null; 

            if (this.broker != null)
            {
                VprGetPatientDataCommand command = new VprGetPatientDataCommand(this.broker);

                command.AddCommandArguments(options.Patient.Dfn);

                RpcResponse response = command.Execute();

                if (response.Status == RpcResponseStatus.Success)
                {
                    returnVal = command.PatientResult; 
                }
            }

            return returnVal;
        }

        private POCD_MT000040RecordTarget CreateRecordTargetSection(PatientDemographics demo)
        {
            // *** Creates a record target section based on vpr demographics section ***

            POCD_MT000040RecordTarget returnVal = new POCD_MT000040RecordTarget();

            // ***  Create a patient role ***
            returnVal.patientRole = new POCD_MT000040PatientRole();

            List<II> idList = new List<II>(); 

            // *** Use lrdfn if present ***
            // *** TODO: Find appropriate OID for internal record number...
            //if (demo.Patient.Lrdfn != null)
            //{
            //    II tempII = new II() { root = demo.Patient.Lrdfn.Value };
            //    idList.Add(tempII);
            //}

            // *** Add SSN ***
            if (demo.Patient.SocialSecurityNumber != null) 
                if (!string.IsNullOrWhiteSpace(demo.Patient.SocialSecurityNumber.Value))
                {
                    II ssnII = new II() { extension = demo.Patient.SocialSecurityNumber.Value, root = "2.16.840.1.113883.4.1" };
                    idList.Add(ssnII); 
                }

            if (idList.Count > 0)
                returnVal.patientRole.id = idList.ToArray(); 

            // *** Populate address if present ***
            if (demo.Patient.Address != null)
            {
                returnVal.patientRole.addr = new AD[1];

                returnVal.patientRole.addr[0] = new AD();

                CdaAddress address = new CdaAddress();
                address.StreetAddress1 = demo.Patient.Address.StreetLine1;
                address.StreetAddress2 = demo.Patient.Address.StreetLine2;
                address.City = demo.Patient.Address.City;
                address.State = demo.Patient.Address.State;
                address.ZipCode = demo.Patient.Address.ZipCode; 

                returnVal.patientRole.addr[0] = GetAddress(address);
            }

            // *** Populate telephone number ***
            List<TEL> telList = new List<TEL>();

            foreach (PhoneNumber number in demo.Patient.PhoneNumbers)
            {
                TEL tempTel = new TEL();
                tempTel.value = number.Value;
                tempTel.use = new string[] { number.UsageType };
                telList.Add(tempTel);
            }

            if (telList.Count > 0)
                returnVal.patientRole.telecom = telList.ToArray();

            returnVal.patientRole.patient = new POCD_MT000040Patient();
            returnVal.patientRole.patient.name = new PN[1];

            // *** Add name ***
            List<ENXP> namelist = new List<ENXP>();
            namelist.Add(new engiven() { Text = new string[] { demo.Patient.FirstName.Value } });
            namelist.Add(new enfamily() { Text = new string[] { demo.Patient.LastName.Value } });

            returnVal.patientRole.patient.name[0] = new PN();
            returnVal.patientRole.patient.name[0].Items = namelist.ToArray();

            // *** Gender ***
            returnVal.patientRole.patient.administrativeGenderCode = new CE();
            returnVal.patientRole.patient.administrativeGenderCode.code = demo.Patient.Gender.Value;
            returnVal.patientRole.patient.administrativeGenderCode.codeSystem = "2.16.840.1.113883.5.1";

            // *** DOB ***
            returnVal.patientRole.patient.birthTime = new TS();
            DateTime dob = Util.GetDateTime(demo.Patient.DateOfBirth.Value);
            if (dob != DateTime.MinValue)
                returnVal.patientRole.patient.birthTime.value = dob.ToString("yyyyMMdd");

            //if (demo.Patient.Facilities != null) 
            //    if (demo.Patient.Facilities.Count > 0) 
            //    {
            //        returnVal.patientRole.providerOrganization = new POCD_MT000040Organization(); 

            //        Facility fac = demo.Patient.Facilities[0]; 

            //        returnVal.patientRole.providerOrganization.id = new II[]{ new II { root = fac.Code }}; 
                    
            //        ON orgName = new ON(); 
            //        orgName.Items = new ENXP[1];
            //        orgName.Items[0] = new ENXP() { Text = new string[] { fac.Name } };

            //        returnVal.patientRole.providerOrganization.name = new ON []{orgName};
            //    }

            return returnVal;
        }

        private POCD_MT000040Author[] CreateAuthorSection()
        {
            // *** Creates an author section ***

            List<POCD_MT000040Author> authorList = new List<POCD_MT000040Author>();

            // *** Get device/system author ***
            POCD_MT000040Author systemAuthor = GetSystemAuthor();

            // *** Add it to return ***
            if (systemAuthor != null)
                authorList.Add(systemAuthor); 

            // *** Get provider authors ***
            POCD_MT000040Author[] providerAuthors = GetProviderAuthors();

            // *** Add to return ***
            if (providerAuthors != null)
                if (providerAuthors.Length > 0)
                    authorList.AddRange(providerAuthors);

            return authorList.ToArray(); 
        }

        private POCD_MT000040Author GetSystemAuthor()
        {
            POCD_MT000040Author returnVal = new POCD_MT000040Author();

            // *** Get device author data ***

            // TODO: Replace with real data (from config?)
            CdaDeviceAuthor deviceAuthor = GetTestDeviceAuthor(); 

            // *** Convert to pocd ***
            returnVal = ConvertToSystemAuthor(deviceAuthor); 

            return returnVal; 
        }

        private CdaDeviceAuthor GetTestDeviceAuthor()
        {
            // *** Source data for a system author ***
            CdaDeviceAuthor deviceAuthor = new CdaDeviceAuthor();

            // TODO: Populate device author with real data...
            deviceAuthor.Time = DateTime.Now;
            deviceAuthor.AssignedAuthoringDevice.Address = new CdaAddress()
            {
                StreetAddress1 = "810 Vermont Avenue",
                City = "NW Washington ",
                State = "DC",
                ZipCode = "20420"
            };
            deviceAuthor.AssignedAuthoringDevice.WorkTelephone = "800-900-9000";
            deviceAuthor.AssignedAuthoringDevice.ManufacturerModelName = "U.S. Department of Veterans Affairs";
            deviceAuthor.AssignedAuthoringDevice.SoftwareName = "Maternity Care Coordinator Dashboard";

            return deviceAuthor; 
        }

        private POCD_MT000040Author ConvertToSystemAuthor(CdaDeviceAuthor author)
        {
            POCD_MT000040Author returnVal = new POCD_MT000040Author();

            //<time value='20000407130000+0500'/>
            returnVal.time = new TS() { value = author.Time.ToString(CdaDocument.CdaDateFormat) };

            returnVal.assignedAuthor = new POCD_MT000040AssignedAuthor();

            returnVal.assignedAuthor.id = new II[] { new II() { nullFlavor = "UNK" } };

            returnVal.assignedAuthor.addr = new AD[1];
            returnVal.assignedAuthor.addr[0] = GetAddress(author.AssignedAuthoringDevice.Address);

            returnVal.assignedAuthor.telecom = new TEL[1];
            returnVal.assignedAuthor.telecom[0] = new TEL() { use = new string[] { "WP" }, value = author.AssignedAuthoringDevice.WorkTelephone };

            POCD_MT000040AuthoringDevice authoringDevice = new POCD_MT000040AuthoringDevice();
            authoringDevice.manufacturerModelName = new SC() { Text = new string[] { author.AssignedAuthoringDevice.ManufacturerModelName } };
            authoringDevice.softwareName = new SC() { Text = new string[] { author.AssignedAuthoringDevice.SoftwareName } };
            returnVal.assignedAuthor.Item = authoringDevice;

            return returnVal;
        }

        private POCD_MT000040Author ConvertToProviderAuthor(CdaProviderAuthor author)
        {
            POCD_MT000040Author returnVal = new POCD_MT000040Author();

            //<time value='20000407130000+0500'/>
            returnVal.time = new TS() { value = author.Time.ToString(CdaDocument.CdaDateFormat) };

            returnVal.assignedAuthor = new POCD_MT000040AssignedAuthor();

            returnVal.assignedAuthor.id = new II[] { new II() { root=author.AssignedPerson.NPI } };

            returnVal.assignedAuthor.addr = new AD[1];
            returnVal.assignedAuthor.addr[0] = GetAddress(author.AssignedPerson.Address);

            returnVal.assignedAuthor.telecom = new TEL[1];
            returnVal.assignedAuthor.telecom[0] = new TEL() { use = new string[] { "WP" }, value = author.AssignedPerson.WorkTelephone };

            //POCD_MT000040AuthoringDevice authoringDevice = new POCD_MT000040AuthoringDevice();
            //authoringDevice.manufacturerModelName = new SC() { Text = new string[] { author.AssignedPerson.ManufacturerModelName } };
            //authoringDevice.softwareName = new SC() { Text = new string[] { author.AssignedAuthoringDevice.SoftwareName } };
            //returnVal.assignedAuthor.Item = authoringDevice;

            POCD_MT000040Person personAuthor = new POCD_MT000040Person(); 
            personAuthor.name = GetPN(author.AssignedPerson.LastName, author.AssignedPerson.FirstName);
           
            returnVal.assignedAuthor.Item = personAuthor;  
            
            return returnVal;
        }
 
        private POCD_MT000040Author[] GetProviderAuthors()
        {
            List<POCD_MT000040Author> returnList = new List<POCD_MT000040Author>();

            // *** Source data for provider authors ***

            // *** TODO: Get real data 
            // TODO: Get list of providers found in the vpr xml
            List<CdaProviderAuthor> provAuthors = GetTestProviderAuthors(); 
            
            // *** Convert to pocd ***
            if (provAuthors != null)
                foreach (CdaProviderAuthor provAuth in provAuthors)
                {
                    POCD_MT000040Author tempAuthor = ConvertToProviderAuthor(provAuth);

                    if (tempAuthor != null)
                        returnList.Add(tempAuthor);
                }

            return returnList.ToArray();
        }

        private List<CdaProviderAuthor> GetTestProviderAuthors()
        {
            List<CdaProviderAuthor> returnList = new List<CdaProviderAuthor>();

            // TODO: Populate provier author with real data...
            CdaProviderAuthor provAuthor; 

            for (int i = 0; i < 4; i++)
            {
                provAuthor = new CdaProviderAuthor();

                provAuthor.Time = DateTime.Now;

                provAuthor.AssignedPerson.Address = new CdaAddress()
                {
                    StreetAddress1 = "810 Vermont Avenue",
                    City = "NW Washington ",
                    State = "DC",
                    ZipCode = "20420"
                };

                provAuthor.AssignedPerson.FirstName = "Doc";
                provAuthor.AssignedPerson.LastName = "Test";
                provAuthor.AssignedPerson.NPI = "12345";
                provAuthor.AssignedPerson.WorkTelephone = "800-900-9000";

                returnList.Add(provAuthor);
            }

            return returnList; 
        }

        private AD GetAddress(CdaAddress address)
        {
            AD returnVal = new AD();

            List<ADXP> addressItemList = new List<ADXP>();
            addressItemList.Add(new adxpstreetAddressLine() { Text = new string[] { address.StreetAddress1 } });
            addressItemList.Add(new adxpstreetAddressLine() { Text = new string[] { address.StreetAddress2 } });
            addressItemList.Add(new adxpcity() { Text = new string[] { address.City } });
            addressItemList.Add(new adxpstate() { Text = new string[] { address.State } });
            addressItemList.Add(new adxppostalCode() { Text = new string[] { address.ZipCode } });
            addressItemList.Add(new adxpcountry() { Text = new string[] { "US" } });

            returnVal.Items = addressItemList.ToArray();

            return returnVal;
        }

        public class CdaAddress
        {
            public string StreetAddress1 { get; set; }
            public string StreetAddress2 { get; set; }
            public string City { get; set; }
            public string State { get; set; }
            public string ZipCode { get; set; }
        }

        //public class CdaAuthorX
        //{
        //    //            string time = DateTime.Now.ToString(CdaDocument.CdaDateFormat);
        //    ////string authorId = "12345";
        //    //string address1 = "810 Vermont Avenue";
        //    ////string address2 = "Suite #23";
        //    //string city = "NW Washington ";
        //    //string state = "DC";
        //    //string zip = "20420";
        //    //string authorPhone = "800-900-9000";
        //    //string manufacturerModelName = "U.S. Department of Veterans Affairs";
        //    //string softwareName = "Maternity Care Coordinator Dashboard"; 

        //    public DateTime AuthorTime { get; set; }
        //    public CdaAddress Address { get; set; }
        //    public string PhoneNumber { get; set; }
        //    public string Manufacturer { get; set; }
        //    public string SoftwareName { get; set; }
        //}

        public abstract class CdaAssignedAuthor
        {
            public CdaAddress Address { get; set; }
            public string WorkTelephone { get; set; }

            public CdaAssignedAuthor()
            {
                this.Address = new CdaAddress(); 
            }
        }

        public class CdaAssignedPerson : CdaAssignedAuthor
        {
            public string NPI { get; set; }
            public string TaxonomyCode { get; set; }
            public string FirstName { get; set; }
            public string LastName { get; set; }
        }

        public class CdaAssignedAuthoringDevice : CdaAssignedAuthor
        {
            public string ManufacturerModelName { get; set; }
            public string SoftwareName { get; set; }
        }

        public abstract class CdaAuthor
        {
            public DateTime Time { get; set; }

        }

        public class CdaDeviceAuthor : CdaAuthor
        {
            public CdaAssignedAuthoringDevice AssignedAuthoringDevice { get; set; }

            public CdaDeviceAuthor()
            {
                this.AssignedAuthoringDevice = new CdaAssignedAuthoringDevice(); 
            }
        }

        public class CdaProviderAuthor : CdaAuthor
        {
            public CdaAssignedPerson AssignedPerson { get; set; }

            public CdaProviderAuthor()
            {
                this.AssignedPerson = new CdaAssignedPerson(); 
            }
        }

        private PN[] GetPN(string lastName, string firstName)
        {
            List<PN> returnPN = new List<PN>(); 

            // *** Add name ***
            List<ENXP> namelist = new List<ENXP>();
            namelist.Add(new engiven() { Text = new string[] { firstName } });
            namelist.Add(new enfamily() { Text = new string[] { lastName } });

            PN newPN = new PN();
            newPN.Items = namelist.ToArray();

            returnPN.Add(newPN); 

            return returnPN.ToArray();
        }

    }
}
