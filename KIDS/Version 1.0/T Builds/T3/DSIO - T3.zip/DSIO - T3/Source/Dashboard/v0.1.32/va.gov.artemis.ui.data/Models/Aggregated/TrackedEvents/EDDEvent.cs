﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VA.Gov.Artemis.UI.Data.Models.Aggregated.Common;

namespace VA.Gov.Artemis.UI.Data.Models.Aggregated.TrackedEvents
{
    public class EDDEvent: TrackedEvent
    {
        public override string EventName
        {
            get { return "EDD"; }
        }

        public override string Details
        {
            get { throw new NotImplementedException(); }
        }

        public override TrackedEventType EventType
        {
            get { return TrackedEventType.EstimatedDeliveryDate; }
        }
    }
}
