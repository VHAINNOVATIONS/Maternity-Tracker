﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VA.Gov.Artemis.UI.Data.Models.Aggregated;
using VA.Gov.Artemis.UI.Data.Models.Notes;
using VA.Gov.Artemis.UI.Data.Models.Patient;

namespace VA.Gov.Artemis.UI.Data.Models
{
    public class FlaggedPatientDetail: NoteListModel
    {
        public List<TrackingEntry> TrackingEntries { get; set; }

        public FlaggedPatientDetail()
        {
            this.TrackingEntries = new List<TrackingEntry>();
            this.Patient = new BasePatient();
            this.ProgressNotes = new List<TiuNote>();
            this.ProgressNotePaging = new Paging(); 
        }

        public string ReturnUrl { get; set; }
    }
}
