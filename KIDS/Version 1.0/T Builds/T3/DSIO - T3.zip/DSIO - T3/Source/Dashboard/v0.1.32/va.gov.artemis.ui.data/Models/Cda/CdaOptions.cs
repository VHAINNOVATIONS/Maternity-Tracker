﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VA.Gov.Artemis.UI.Data.Models.Cda
{
    public class CdaOptions
    {
        public BasePatient Patient { get; set; }

        // TODO: Add data to represent options (maybe?) 
        public IheDocumentType DocumentType { get; set; }
        public string IntendedRecipient { get; set; }
    }
}
