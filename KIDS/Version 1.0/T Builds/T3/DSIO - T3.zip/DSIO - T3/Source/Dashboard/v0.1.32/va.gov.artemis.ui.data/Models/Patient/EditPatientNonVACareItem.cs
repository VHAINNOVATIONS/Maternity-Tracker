﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VA.Gov.Artemis.UI.Data.Models.Administration;

namespace VA.Gov.Artemis.UI.Data.Models.Patient
{
    public class EditPatientNonVACareItem
    {
        public BasePatient Patient { get; set; }
        public PatientNonVACareItem Item { get; set; }
        public List<NonVACareItem> ItemList { get; set; }

        public string ListLabel { get; set; }

        public string ContactLabel { get; set; }
    }
}
