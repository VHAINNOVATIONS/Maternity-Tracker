﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VA.Gov.Artemis.UI.Data.Models.Aggregated.Common;

namespace VA.Gov.Artemis.UI.Data.Models.Aggregated.TrackedEvents
{
    public class AppointmentEvent: TrackedEvent
    {
        // TODO: Does this include visits, encounters, admissions ?

        public override string EventName
        {
            get { return "Appointment"; }
        }

        public override string Details
        {
            get { // TODO
                return "This is a test appointment"; 
            }
        }

        public override TrackedEventType EventType
        {
            get { return TrackedEventType.Appointment; }
        }
    }
}
