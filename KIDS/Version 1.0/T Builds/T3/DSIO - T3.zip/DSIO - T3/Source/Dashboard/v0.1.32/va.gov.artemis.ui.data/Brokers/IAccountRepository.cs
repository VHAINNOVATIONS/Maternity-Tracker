﻿using VA.Gov.Artemis.UI.Data.Brokers.Results;
using VA.Gov.Artemis.UI.Data.Models;
using VA.Gov.Artemis.UI.Data.Models.Account;

namespace VA.Gov.Artemis.UI.Data.Brokers
{
    public interface IAccountRepository
    {
        LoginResult GetLoginData();

        LoginResult PerformLogin(Login loginData);

        UserResult GetUserData();

        BrokerOperationResult ChangeVerifyCode(ChangeVerifyCode changeVerifyCodeData);

        int GetUserTimeout();

        BrokerOperationResult CreateContext();
    }
}
