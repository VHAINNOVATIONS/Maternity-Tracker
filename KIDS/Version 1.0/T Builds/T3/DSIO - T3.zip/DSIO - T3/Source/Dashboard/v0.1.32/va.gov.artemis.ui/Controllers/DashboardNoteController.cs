﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using VA.Gov.Artemis.UI.Data.Brokers.Results;
using VA.Gov.Artemis.UI.Data.Models;
using VA.Gov.Artemis.UI.Data.Models.Aggregated;
using VA.Gov.Artemis.UI.Data.Models.Notes;
using VA.Gov.Artemis.UI.Data.Models.Patient;
using VA.Gov.Artemis.UI.Filters;

namespace VA.Gov.Artemis.UI.Controllers
{
    [DisableLocalCache]
    [VerifySession]
    [Authorize]
    public class DashboardNoteController : DashboardController
    {
        private const int ItemsPerPage = 5; 

        [HttpGet]
        public ActionResult Index(string dfn, string page)
        {
            // *** Show list of dashboard notes by patient

            NoteListModel model = new NoteListModel();

            model.Patient = this.CurrentPatient;

            int pageVal = this.GetPage(page); 

            if (!model.Patient.NotFound)
            {
                NoteListResult notesResult = this.DashboardRepository.Notes.GetDashboardNotes(dfn, pageVal, ItemsPerPage);

                if (!notesResult.Success)
                    this.Error(notesResult.Message);
                else
                {
                    model.ProgressNotes = notesResult.Notes; 

                    model.ProgressNotePaging.SetPagingData(ItemsPerPage, pageVal, notesResult.TotalResults); 

                    model.ProgressNotePaging.BaseUrl = Url.Action("Index", new { dfn = dfn, page = "" });

                    TempData[ReturnUrl] = Url.Action("Index", new { dfn = dfn, page = pageVal });
                }

                model.DetailAction = "Details"; 
            }                   

            return View(model);
        }

        [HttpGet]
        public ActionResult Details(string dfn, string ien)
        {
            // *** Show details of a dashboard note ***
                        
            TiuNoteModel model = new TiuNoteModel();

            model.Patient = this.CurrentPatient;

            if (!model.Patient.NotFound)
            {
                TiuNoteResult noteResult = this.DashboardRepository.Notes.GetDashboardNote(ien);

                if (!noteResult.Success)
                    this.Error(noteResult.Message);
                else
                    model.Detail = noteResult.Note.NoteText; 
            }

            // *** Set return url ***
            if (TempData.ContainsKey(ReturnUrl))
            {
                model.ReturnUrl = TempData[ReturnUrl].ToString();
                TempData[ReturnUrl] = TempData[ReturnUrl];
            }

            return View(model);
        }

        [HttpGet]
        public ActionResult CreateNote(string dfn)
        {
            // *** Create a new dashboard note ***

            TiuNoteModel model = new TiuNoteModel();

            model.Patient = this.CurrentPatient;

            // *** Set return url ***
            if (TempData.ContainsKey(ReturnUrl))
            {
                model.ReturnUrl = TempData[ReturnUrl].ToString();
                TempData[ReturnUrl] = TempData[ReturnUrl];
            }

            return View(model);
        }

        [HttpPost]
        public ActionResult CreateNote(TiuNoteModel model)
        {
            // *** Post data ***

            ActionResult returnResult;

            bool needPatDemo = false; 

            if (ModelState.IsValid)
            {
                BrokerOperationResult result = this.DashboardRepository.Notes.CreateDashboardNote(model.Patient.Dfn, model.Detail);

                if (!result.Success)
                {
                    this.Error(result.Message);

                    returnResult = View(model);

                    needPatDemo = true; 
                }
                else
                {
                    this.Information("Dashboard Note Created");
                    returnResult = RedirectToAction("Index", new { dfn = model.Patient.Dfn });
                    needPatDemo = false; 
                }
            }
            else
            {
                this.Error("Please enter note details"); 
                returnResult = View(model);
                needPatDemo = true; 
            }

            // *** Get patient demographics ***
            if (needPatDemo)
            {
                this.CurrentPatientDfn = model.Patient.Dfn;
                model.Patient = this.CurrentPatient;
            }

            // *** Set return url ***
            if (TempData.ContainsKey(ReturnUrl))
            {
                model.ReturnUrl = TempData[ReturnUrl].ToString();
                TempData[ReturnUrl] = TempData[ReturnUrl];
            }

            return returnResult;
        }

        [HttpGet]
        public ActionResult Edit(string dfn, string ien)
        {
            // *** Create a new dashboard note ***

            TiuNoteModel model = new TiuNoteModel();

            model.Patient = this.CurrentPatient;

            if (!model.Patient.NotFound)
            {
                TiuNoteResult noteResult = this.DashboardRepository.Notes.GetDashboardNote(ien);

                if (!noteResult.Success)
                    this.Error(noteResult.Message);
                else
                {
                    model.Detail = noteResult.Note.NoteText;
                    model.Ien = ien;
                }
            }

            // *** Set return url ***
            if (TempData.ContainsKey(ReturnUrl))
            {
                model.ReturnUrl = TempData[ReturnUrl].ToString();
                TempData[ReturnUrl] = TempData[ReturnUrl];
            }

            return View("CreateNote", model);
        }

        [HttpPost]
        public ActionResult Edit(TiuNoteModel model)
        {
            // *** Post data ***

            ActionResult returnResult;

            bool needPatDemo = false;

            if (ModelState.IsValid)
            {
                BrokerOperationResult result = this.DashboardRepository.Notes.UpdateDashboardNote(model.Ien, model.Detail);

                if (!result.Success)
                {
                    this.Error(result.Message);

                    returnResult = View("CreateNote", model);

                    needPatDemo = true;
                }
                else
                {
                    this.Information("Dashboard Note Updated");
                    returnResult = RedirectToAction("Index", new { dfn = model.Patient.Dfn });
                    needPatDemo = false;
                }
            }
            else
            {
                this.Error("Please enter note details");
                returnResult = View("CreateNote", model);
                needPatDemo = true;
            }

            if (needPatDemo)
            {
                this.CurrentPatientDfn = model.Patient.Dfn; 
                model.Patient = this.CurrentPatient;
            }

            // *** Set return url ***
            if (TempData.ContainsKey(ReturnUrl))
            {
                model.ReturnUrl = TempData[ReturnUrl].ToString();
                TempData[ReturnUrl] = TempData[ReturnUrl];
            }

            return returnResult;
        }

        [HttpGet]
        public ActionResult Delete(string dfn, string ien)
        {
            DeleteNoteModel model = new DeleteNoteModel();

            model.Patient = this.CurrentPatient;

            if (!model.Patient.NotFound)
                model.NoteIen = ien;

            // *** Set return url ***
            if (TempData.ContainsKey(ReturnUrl))
            {
                model.ReturnUrl = TempData[ReturnUrl].ToString();
                TempData[ReturnUrl] = TempData[ReturnUrl];
            }

            return View(model); 
        }

        [HttpPost]
        public ActionResult Delete(DeleteNoteModel model)
        {
            ActionResult returnResult;

            bool needPatDemo = false; 

            if (ModelState.IsValid)
            {
                BrokerOperationResult result = this.DashboardRepository.Notes.DeleteDashboardNote(model.NoteIen, model.DeleteReason);

                if (!result.Success)
                {
                    this.Error(result.Message);
                    returnResult = View(model);
                    needPatDemo = true; 
                }
                else
                {
                    this.Information("The note has beed deleted.");
                    returnResult = RedirectToAction("Index", new { dfn = model.Patient.Dfn });
                }
            }
            else
            {
                needPatDemo = true; 
                model.NoteIen = model.NoteIen;

                this.Error("Please enter a reason for the deletion");
                returnResult = View(model);
            }

            if (needPatDemo)
            {
                this.CurrentPatientDfn = model.Patient.Dfn;
                model.Patient = this.CurrentPatient;
            }

            // *** Set return url ***
            if (TempData.ContainsKey(ReturnUrl))
            {
                model.ReturnUrl = TempData[ReturnUrl].ToString();
                TempData[ReturnUrl] = TempData[ReturnUrl];
            }

            return returnResult; 
        }

        [HttpGet]
        public ActionResult Sign(string dfn, string ien)
        {
            SignNoteModel model = new SignNoteModel();

            model.Patient = this.CurrentPatient;

            if (!model.Patient.NotFound)
                model.NoteIen = ien;

            // *** Set return url ***
            if (TempData.ContainsKey(ReturnUrl))
            {
                model.ReturnUrl = TempData[ReturnUrl].ToString();
                TempData[ReturnUrl] = TempData[ReturnUrl];
            }

            return View(model);
        }

        [HttpPost]
        public ActionResult Sign(SignNoteModel model)
        {
            ActionResult returnResult;

            bool needDemo = false; 

            if (ModelState.IsValid)
            {
                BrokerOperationResult result = this.DashboardRepository.Notes.SignDashboardNote(model.NoteIen, model.Esig);

                if (!result.Success)
                {
                    this.Error(result.Message);
                    returnResult = View(model);
                    needDemo = true; 
                }
                else
                {
                    this.Information("The note has beed signed.");
                    returnResult = RedirectToAction("Index", new { dfn = model.Patient.Dfn });
                }
            }
            else
            {
                needDemo = true; 
                
                model.NoteIen = model.NoteIen;

                this.Error("Please enter signature code");

                returnResult = View(model);
            }

            if (needDemo)
            {
                this.CurrentPatientDfn = model.Patient.Dfn;
                model.Patient = this.CurrentPatient;
            }

            // *** Set return url ***
            if (TempData.ContainsKey(ReturnUrl))
            {
                model.ReturnUrl = TempData[ReturnUrl].ToString();
                TempData[ReturnUrl] = TempData[ReturnUrl];
            }

            return returnResult;
        }

        [HttpGet]
        public ActionResult CreateAddendum(string dfn, string ien)
        {
            // *** Create addendum to existing dashboard note ***

            TiuNoteModel model = new TiuNoteModel();

            model.Patient = this.CurrentPatient;

            model.Ien = ien;

            // *** Set return url ***
            if (TempData.ContainsKey(ReturnUrl))
            {
                model.ReturnUrl = TempData[ReturnUrl].ToString();
                TempData[ReturnUrl] = TempData[ReturnUrl];
            }

            return View(model);
        }

        [HttpPost]
        public ActionResult CreateAddendum(TiuNoteModel model)
        {
            // *** Post data ***

            ActionResult returnResult;

            bool needPatDemo = false;

            if (ModelState.IsValid)
            {
                BrokerOperationResult result = this.DashboardRepository.Notes.CreateDashboardAddendum(model.Ien, model.Detail);

                if (!result.Success)
                {
                    this.Error(result.Message);

                    returnResult = View(model);

                    needPatDemo = true;
                }
                else
                {
                    this.Information("Addendum Created");
                    returnResult = RedirectToAction("Index", new { dfn = model.Patient.Dfn });
                    needPatDemo = false;
                }
            }
            else
            {
                this.Error("Please enter note details");
                returnResult = View(model);
                needPatDemo = true;
            }

            if (needPatDemo)
            {
                this.CurrentPatientDfn = model.Patient.Dfn;
                model.Patient = this.CurrentPatient;
            }

            // *** Set return url ***
            if (TempData.ContainsKey(ReturnUrl))
            {
                model.ReturnUrl = TempData[ReturnUrl].ToString();
                TempData[ReturnUrl] = TempData[ReturnUrl];
            }

            return returnResult;
        }

    }
}
