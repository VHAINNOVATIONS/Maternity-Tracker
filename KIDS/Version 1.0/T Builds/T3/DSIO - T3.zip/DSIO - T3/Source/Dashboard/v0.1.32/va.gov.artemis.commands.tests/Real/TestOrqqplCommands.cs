﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using VA.Gov.Artemis.Commands.tests.real;
using VA.Gov.Artemis.Vista.Broker;
//using VA.Gov.Artemis.Commands.Orqqpl;

namespace VA.Gov.Artemis.Commands.tests.Real
{
    [TestClass]
    public class TestOrqqplCommands: TestCommandsBase 
    {
        [TestMethod]
        public void TestGetProblemList()
        {
            //using (RpcBroker broker = GetConnectedBroker())
            //{
            //    this.SignonToBroker(broker, 0);

            //    OrqqplProblemListCommand command = new OrqqplProblemListCommand(broker); 

            //    command.AddCommandParameters("740"); 

            //    RpcResponse response = command.Execute(); 

            //    Assert.AreEqual(RpcResponseStatus.Success, response.Status); 

            //    broker.Disconnect(); 
            //}
        }
    }
}
