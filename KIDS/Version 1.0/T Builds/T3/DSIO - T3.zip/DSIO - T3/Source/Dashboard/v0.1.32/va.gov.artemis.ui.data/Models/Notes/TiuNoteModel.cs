﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VA.Gov.Artemis.UI.Data.Models.Notes
{
    public class TiuNoteModel: IPatientDetail
    {
        public TiuNote Note { get; set; }

        public string Ien { get; set; }

        [Required]
        public string Detail { get; set; }

        public BasePatient Patient { get; set; }

        public string ReturnUrl { get; set; }

    }
}
