﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace VA.Gov.Artemis.UI.Data.Models.Aggregated.Common
{
    public enum OrderStatus { Pending = 5, Active = 6, Unreleased = 11 }
}