﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VA.Gov.Artemis.Vista.Broker;
using VA.Gov.Artemis.Vista.Commands;
using VA.Gov.Artemis.Vista.Utility;

namespace VA.Gov.Artemis.Commands.Tiu
{
    public class TiuGetRecordTextCommand: CommandBase
    {
        public TiuGetRecordTextCommand(IRpcBroker newBroker): base(newBroker)
        {
            this.Context = "DSIO GUI CONTEXT";
        }
        public override string RpcName
        {
            get { return "TIU GET RECORD TEXT"; }
        }

        public override string Version
        {
            get { return "0"; }
        }

        public void AddCommandArgument(string ien)
        {
            this.CommandArgs = new object[] { ien };
        }

        public string RecordText {get; set; }

        protected override void ProcessResponse()
        {
            // *** Make sure we have something to work with ***
            if (string.IsNullOrWhiteSpace(this.Response.Data))
            {
                // *** Set response info ***
                this.Response.Status = RpcResponseStatus.Fail;
                this.Response.InformationalMessage = "No data returned";
            }
            else
            {
                // *** Check first piece for success/failure ***
                string first = Util.Piece(this.Response.Lines[0], Caret, 1);

                if (first == "-1")
                {
                    // *** -1 is fail ***
                    this.Response.Status = RpcResponseStatus.Fail;
                    this.Response.InformationalMessage = Util.Piece(this.Response.Lines[0], Caret, 2);
                }
                else
                {
                    this.RecordText = this.Response.Data;
                    this.Response.Status = RpcResponseStatus.Success;
                }
            }            
        }
    }
}
