﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VA.Gov.Artemis.UI.Data.Brokers.Results;
using VA.Gov.Artemis.UI.Data.Models.Aggregated;

namespace VA.Gov.Artemis.UI.Data.Brokers
{
    public interface INoteRepository
    {
        TiuNoteResult GetLatestProgressNote(string dfn);

        HasProgressNoteResult HasProgressNote(string dfn);

        TiuNoteResult GetProgressNote(string ien);

        NoteListResult GetList(string dfn);

        BrokerOperationResult CreateDashboardNote(string dfn, string noteText);

        NoteListResult GetDashboardNotes(string dfn, int page, int itemsPerPage);

        BrokerOperationResult UpdateDashboardNote(string ien, string noteText);

        BrokerOperationResult CreateDashboardAddendum(string ien, string noteText);

        BrokerOperationResult DeleteDashboardNote(string ien, string justification);

        BrokerOperationResult SignDashboardNote(string ien, string sig);

        TiuNoteResult GetDashboardNote(string ien);
    }
}
