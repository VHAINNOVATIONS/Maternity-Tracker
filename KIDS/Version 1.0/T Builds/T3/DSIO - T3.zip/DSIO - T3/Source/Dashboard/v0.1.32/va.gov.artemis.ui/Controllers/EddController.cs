﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using VA.Gov.Artemis.UI.Data.Brokers.Results;
using VA.Gov.Artemis.UI.Data.Models;
using VA.Gov.Artemis.UI.Data.Models.Patient;
using VA.Gov.Artemis.UI.Filters;

namespace VA.Gov.Artemis.UI.Controllers
{
    [DisableLocalCache]
    [VerifySession]
    [Authorize]
    public class EddController : DashboardController
    {
        [HttpGet]
        public ActionResult Index(string dfn)
        {
            // *** Show current EDD and list of historical entries ***

            PatientDemographicsResult result = this.DashboardRepository.Patients.GetPatientDemographics(dfn);

            BasePatient model = this.CurrentPatient;

            return View(model);
        }

        [HttpGet]
        public ActionResult Update(string dfn)
        {
            // *** Show form and calculator to update edd ***

            // TODO...

            return View();
        }

        [HttpPost]
        public ActionResult Update(EstimatedDeliveryDate model)
        {
            // *** Post data ***

            // TODO...

            return View();
        }            

    }
}
