﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VA.Gov.Artemis.UI.Data.Models.Patient
{
    public class LabTest
    {
        public DateTime TestDateTime { get; set; }
        public string TestName { get; set; }
        public string Result { get; set; }
        public string Provider { get; set; }

        public LabTestTiming Timing {get; set; }

        public LabTest(string testName, LabTestTiming timing, DateTime testDateTime, string provider, string result)
        {
            this.TestName = testName;
            this.Timing = timing;
            this.TestDateTime = testDateTime;
            this.Provider = provider;
            this.Result = result; 
        }
    }

    public enum LabTestTiming {Initial, Week28, Week36}


}
