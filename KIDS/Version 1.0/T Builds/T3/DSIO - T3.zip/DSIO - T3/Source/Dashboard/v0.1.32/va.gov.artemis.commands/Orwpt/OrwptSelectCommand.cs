﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VA.Gov.Artemis.Vista.Broker;
using VA.Gov.Artemis.Vista.Commands;
using VA.Gov.Artemis.Vista.Utility;

namespace VA.Gov.Artemis.Commands.Orwpt
{
    public class OrwptSelectCommand: CommandBase 
    {
        private string LastDfn { get; set; }

        public OrwptSelectPatient Patient { get; private set; }

        public OrwptSelectCommand(IRpcBroker newBroker): base(newBroker)
        {
            this.Context = "DSIO GUI CONTEXT";
        }

        public void AddDfnArgument(string dfn) 
        {
            this.CommandArgs = new object[]{dfn};
            this.LastDfn = dfn; 
        }
        public override string RpcName
        {
            get { return "ORWPT SELECT"; }
        }

        public override string Version
        {
            get { return "0"; }
        }

        protected override void ProcessResponse()
        {
            // *** Check for empty results ***
            if (!string.IsNullOrWhiteSpace(this.Response.Data))
            {
                string line = this.Response.Lines[0];
                string piece1 = Util.Piece(line, Caret, 1);

                // *** Check for error ***
                if (piece1 == "-1")
                {
                    this.Response.Status = RpcResponseStatus.Fail;
                    this.Response.InformationalMessage = "Patient not found";
                }
                else
                {
                    // *** Create new patient ***
                    this.Patient = new OrwptSelectPatient();

                    // *** Add data piece by piece ***
                    this.Patient.Dfn = this.LastDfn;
                    this.Patient.PatientName = Util.Piece(line, Caret, 1);
                    this.Patient.Gender = Util.Piece(line, Caret, 2);
                    this.Patient.DOB = Util.Piece(line, Caret, 3);
                    this.Patient.SSN = Util.Piece(line, Caret, 4);
                    this.Patient.LocationIen = Util.Piece(line, Caret, 5);
                    this.Patient.LocationName = Util.Piece(line, Caret, 6);
                    this.Patient.RoomBed = Util.Piece(line, Caret, 7);
                    this.Patient.Cwad = Util.Piece(line, Caret, 8);
                    this.Patient.Sensitive = Util.Piece(line, Caret, 9);
                    this.Patient.Admitted = Util.Piece(line, Caret, 10);
                    this.Patient.Conv = Util.Piece(line, Caret, 11);
                    this.Patient.ServiceConnected = Util.Piece(line, Caret, 12);
                    this.Patient.ServiceConnectedPercent = Util.Piece(line, Caret, 13);
                    this.Patient.Icn = Util.Piece(line, Caret, 14);

                    this.Response.Status = RpcResponseStatus.Success;
                }
            }
            else
                this.Response.InformationalMessage = "No data returned"; 
        }
    }
}
