﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VA.Gov.Artemis.UI.Data.Models
{
    public class PatientContactItem
    {
        public DateTime ItemDateTime { get; set; }
        public string UserName { get; set; }
        public string Details { get; set; }
        public string ProgressNoteIen { get; set; }

        public string ProgressNoteText { get; set; }

        public string DisplayDateTime
        {
            get
            {
                return this.ItemDateTime.ToString("MM/dd/yyyy h:mm tt");
            }
        }
        
    }
}
