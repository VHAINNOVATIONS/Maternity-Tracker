﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;
using VA.Gov.Artemis.Cda;

namespace va.gov.artemis.cda.test
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Starting...");

            //TestObservation();  
            TestAPHP();
            TestCcd();

            Console.WriteLine("Completed."); 
            Console.ReadKey(); 
        }

        private static void TestDocument()
        {
            try
            {
                // *** Code to deserialize the sample ***
                XmlSerializer serializer = new XmlSerializer(typeof(POCD_MT000040ClinicalDocument));

                //using (FileStream fs = File.OpenRead(@"C:\Users\RPoynter\Desktop\HL7 CCD\SampleCCDDocument.xml"))
                //{
                //    POCD_MT000040ClinicalDocument Ccd = (POCD_MT000040ClinicalDocument)serializer.Deserialize(fs);
                //}

                POCD_MT000040ClinicalDocument newCcd = new POCD_MT000040ClinicalDocument();

                POCD_MT000040RecordTarget recordTarget = new POCD_MT000040RecordTarget();

                POCD_MT000040PatientRole patientRole = new POCD_MT000040PatientRole();

                POCD_MT000040Patient patient = new POCD_MT000040Patient();

                PN name = new PN();

                engiven given = new engiven();

                given.Text = new string[] { "Henry" };


                name.Items = new ENXP[] { given };

                patient.name = new PN[] { name };

                patientRole.patient = patient;

                recordTarget.patientRole = patientRole;

                newCcd.recordTarget = new POCD_MT000040RecordTarget[] { recordTarget };


                using (FileStream writer = File.OpenWrite(@"Z:\VMShared\Source\TestCCD\test_ccd.xml"))
                {
                    serializer.Serialize(writer, newCcd);
                }
            }
            catch (Exception genericException)
            {
                Console.WriteLine(genericException.ToString());
            }
        }

        private static void TestObservation()
        {
            // 1. Get most recent pregnancyhHistory from VistA
            //      a. Header: Patient, User, Date, Source
            //      b. Values: Loinc, Value, Description 
            // 2. Add provider to header
            // 3. Convert to CDA XML

            string id = "123"; 
            string loinc = "11449-6"; // Births Live
            string description = "#xxx"; // WHat is this...?
            string effectiveTime = "20071010"; 
            string statusCode = "completed"; 
            string value = "3"; 
            string narrative = "Enter narrative of pregnancy history"; 

            // TODO: Remove namespaces
            // TODO: Root name
            // TODO: Verify meaning of Id
            // TODO: Determine meaning of text.reference
            // TODO: How to use LOINC in system design
            // TODO: Create table formatting for values (horiz or vert?)
            // TODO: Check LOINC definitions and versions
            // TODO: Check mapping for CNT
            // TODO: Add control file for list of pregnancy history items (dashboard)
            // TODO: Implement pregnancy history organizer

            // *** So Far ***
            // *** Analysis (4)
            // *** Proof of Concept (3) 

            // *** Items to develop ***
            // *** Command (3) ***
            // *** Command Test Live (1) ***
            // *** Command Test Mock (1) ***
            // *** Repository (1) ***
            // *** Repository Test Live (1) ***
            // *** Repository Test Mock (1) ***
            // *** CDA Processing ***
            // ***      Design (2) 
            // ***      Organizer (3)
            // ***      Human Readable (2) 
            // *** Analysis 
            // ***      LOINC currency, version (2)
            // ***      LOINC architecture, design (2)
            // ***      CNT Mapping (1) 

            // *** Pregnancy History Section Template ***
            // *** 
            // *** Data Elements = 5
            // *** Value Set = 7
            // *** RPC's Needed = 1
            // *** VistA File Work Needed = Yes
            // *** 
            // *** So Far = 7 Hours 
            // *** To Do = 20 Hours
            // *** VistA = 15 Hours (check) ***
            // *** Total Analysis/Dev Hours = 42 ***
            // *** Total Calendar Days = 3

            POCD_MT000040Observation observation = new POCD_MT000040Observation();

            observation.classCode = "OBS";
            observation.moodCode = x_ActMoodDocumentObservation.EVN; 
            observation.templateId = new II[2];
            observation.templateId[0] = new II { root = "1.3.6.1.4.1.19376.1.5.3.1.4.13" };
            observation.templateId[1] = new II { root = "1.3.6.1.4.1.19376.1.5.3.1.4.13.5" };

            observation.id = new II[1];
            observation.id[0] = new II { root = id };
            observation.code = new CD() { code = loinc, codeSystem = "2.16.840.1.113883.6.1", codeSystemName = "LOINC" };
            observation.text = new ED();
            observation.text.reference = new TEL() { value = description };
            observation.statusCode = new CS(){code=statusCode};
            observation.effectiveTime = new IVL_TS() { value = effectiveTime };
            observation.value = new INT[1];
            observation.value[0] = new INT() { value = value };

            POCD_MT000040Entry entry = new POCD_MT000040Entry();

            entry.Item = observation;

            POCD_MT000040Section section = new POCD_MT000040Section();

            section.entry = new POCD_MT000040Entry[1];
            section.entry[0] = entry;

            section.templateId = new II[1];
            section.templateId[0] = new II() {root="1.3.6.1.4.1.19376.1.5.3.1.1.5.3.4" };

            section.code = new CE(){ code = "10162-6", displayName="History Of Pregnancies", codeSystem = "2.16.840.1.113883.6.1", codeSystemName = "LOINC" };
            section.text = new StrucDocText();
            section.text.Text = new string[1];
            section.text.Text[0] = narrative;

            POCD_MT000040Component3 component = new POCD_MT000040Component3();

            component.section = section; 

            XmlSerializer serializer = new XmlSerializer(typeof(POCD_MT000040Component3), null ,null, new XmlRootAttribute("component"), "" );

            using (FileStream writer = File.OpenWrite(@"Z:\VMShared\Source\TestCCD\test_observation.xml"))
            {
                serializer.Serialize(writer, component);
            }

        }

        private static void TestAPHP()
        {
            Console.WriteLine();
            Console.WriteLine("Generating APHP...");
            Console.WriteLine();

            // Patient Data 
            // Id (dfn)
            // Address 1 
            // Address 2 
            // City 
            // State
            // Zipcode
            // Country ?
            // First
            // Last 
            // Middle 
            // Gender
            // DOB

            AphpDocument aphpDoc = new AphpDocument();

            // *** TODO: Do we need to save this externally? ***
            aphpDoc.id = new II() { root = Guid.NewGuid().ToString() };

            aphpDoc.recordTarget = new POCD_MT000040RecordTarget[1];

            aphpDoc.recordTarget[0] = new POCD_MT000040RecordTarget(); 

            aphpDoc.recordTarget[0].patientRole = new POCD_MT000040PatientRole();

            aphpDoc.recordTarget[0].patientRole.id = new II[1] ;

            aphpDoc.recordTarget[0].patientRole.id[0] = new II() { root = "12345" }; // TODO: Patient Id
            aphpDoc.recordTarget[0].patientRole.addr = new AD[1];

            //CdaAddress address = new CdaAddress() 

            // TODO: Get real address data...
            List<ADXP> addressItemList = new List<ADXP>();
            addressItemList.Add(new adxpstreetAddressLine() { Text = new string[]{"123 Something"} }); 
            addressItemList.Add(new adxpcity() { Text = new string[] { "City" } });
            addressItemList.Add(new adxpstate() { Text = new string[] { "CA" } });
            addressItemList.Add(new adxppostalCode() { Text = new string[] { "91199" } });
            addressItemList.Add(new adxpcountry() { Text = new string[] { "US" } });

            aphpDoc.recordTarget[0].patientRole.addr[0] = new AD();
            aphpDoc.recordTarget[0].patientRole.addr[0].Items = addressItemList.ToArray() ;

            aphpDoc.recordTarget[0].patientRole.telecom = new TEL[1];
            aphpDoc.recordTarget[0].patientRole.telecom[0] = new TEL() { value = "800-900-9000" };

            aphpDoc.recordTarget[0].patientRole.patient = new POCD_MT000040Patient();
            aphpDoc.recordTarget[0].patientRole.patient.name = new PN[1]; 

            List<ENXP> namelist = new List<ENXP>(); 
            namelist.Add(new engiven(){ Text = new string[]{"Test"}});
            namelist.Add(new engiven() { Text = new string[] { "M." } });
            namelist.Add(new enfamily() { Text = new string[] { "Patient" } });

            aphpDoc.recordTarget[0].patientRole.patient.name[0] = new PN();
            aphpDoc.recordTarget[0].patientRole.patient.name[0].Items = namelist.ToArray();

            aphpDoc.recordTarget[0].patientRole.patient.administrativeGenderCode = new CE();
            aphpDoc.recordTarget[0].patientRole.patient.administrativeGenderCode.code = "F";
            aphpDoc.recordTarget[0].patientRole.patient.administrativeGenderCode.codeSystem = "2.16.840.1.113883.5.1";

            aphpDoc.recordTarget[0].patientRole.patient.birthTime = new TS();
            aphpDoc.recordTarget[0].patientRole.patient.birthTime.value = "19900405"; 

            XmlSerializer serializer = new XmlSerializer(typeof(AphpDocument));

            XmlWriterSettings settings = new XmlWriterSettings();
            settings.Encoding = Encoding.UTF8;
            settings.Indent = true;
            settings.NewLineHandling = NewLineHandling.Replace;

            using (StreamWriter output = new StreamWriter(new FileStream(@"Z:\VMShared\Source\TestCCD\test_aphp_header.xml", FileMode.Create), Encoding.UTF8))
            {
                using (XmlWriter xmlWriter = XmlWriter.Create(output, settings))
                {
                    xmlWriter.WriteProcessingInstruction("xml-stylesheet", "type=\"text/xsl\" href=\"CDA.xsl\"");
                    serializer.Serialize(xmlWriter, aphpDoc);
                }
            }

            Console.WriteLine(File.ReadAllText(@"Z:\VMShared\Source\TestCCD\test_aphp_header.xml"));
            Console.WriteLine();
        }

        private static void TestCcd()
        {
            Console.WriteLine();
            Console.WriteLine("Generating Ccd...");
            Console.WriteLine();

            CcdDocument ccdDoc = new CcdDocument();

            // *** TODO: Do we need to save this externally? ***
            ccdDoc.id = new II() { root = Guid.NewGuid().ToString() };

            XmlSerializer serializer = new XmlSerializer(typeof(CcdDocument));

            XmlWriterSettings settings = new XmlWriterSettings();
            settings.Encoding = Encoding.UTF8;
            settings.Indent = true;
            settings.NewLineHandling = NewLineHandling.Replace;

            using (StreamWriter output = new StreamWriter(new FileStream(@"Z:\VMShared\Source\TestCCD\test_ccd_header.xml", FileMode.Create), Encoding.UTF8))
            {
                using (XmlWriter xmlWriter = XmlWriter.Create(output, settings))
                {
                    xmlWriter.WriteProcessingInstruction("xml-stylesheet", "type=\"text/xsl\" href=\"CDA.xsl\"");
                    serializer.Serialize(xmlWriter, ccdDoc);
                }
            }

            Console.WriteLine(File.ReadAllText(@"Z:\VMShared\Source\TestCCD\test_ccd_header.xml"));
            Console.WriteLine();
        }
    }


    public class PregnancyObservation
    {
        public string Id { get; set; }
        public string Loinc { get; set; } // LOINC
        public string EffectiveTime { get; set; }
        public string Value { get; set; }
        public string Description { get; set; }

        public PregnancyObservation()
        {
            this.Id = "123";
            this.Loinc = "11449-6"; // Births Live
            this.Description = "#xxx"; // WHat is this...?
            this.EffectiveTime = "20071010";
            this.Value = "3";
        }
    }

    public class PregnancyHistory
    {
        public string Ien { get; set; }
        public DateTime Recorded { get; set; }
        public string EnteredBy { get; set; }
        public string Source { get; set; } // Dashboard, Custom Template, Patient

        public List<PregnancyHistoryValue> Values { get; set; }

    }

    public class PregnancyHistoryValue
    {
        public string Loinc { get; set; }
        public string Description { get; set; }
        public int Value { get; set; }
    }

    public class CdaAddress
    {
        //public AddressUse Use { get; set; } // Not required
        public List<string> AddressLines { get; set; } // Max 4, 1 required
        public string City { get; set; }
        public string State { get; set; }
        public string ZipCode { get; set; }
        public string Country { get; set; }

        public CdaAddress()
        {
            this.AddressLines = new List<string>(); 
        }
    }

}
