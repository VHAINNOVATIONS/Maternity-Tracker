﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VA.Gov.Artemis.UI.Data.Models.Notes
{
    public class TiuNote
    {
        public string Ien { get; set; }
        public DateTime DocumentDateTime { get; set; }
        public string Title { get; set; }
        public string Location { get; set; }
        public string Author { get; set; }
        public string PatientDfn { get; set; }
        public TiuNoteSignatureStatus SignatureStatus { get; set; }
        public string ParentIen { get; set; }

        public string NoteText { get; set; }

        public bool IsAddendum
        {
            get
            {
                return (!string.IsNullOrWhiteSpace(this.ParentIen));
            }
        }

    }
}
