﻿//using VA.Gov.Artemis.UI.Data.Models.Common;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using VA.Gov.Artemis.UI.Data.Models.Aggregated.Common;

namespace VA.Gov.Artemis.UI.Data.Models.Aggregated
{
    public class Pregnancy
    {
        public string PregnancyId { get; set; }

        [Display(Name="EDD")]
        [DisplayFormat(DataFormatString="{0:MM/dd/yyyy}")]
        public DateTime EstimatedDeliveryDate { get; set; }

        [Display(Name = "LMP")]
        public DateTime LastMenstrualPeriod { get; set; }

        [Display(Name = "GA")]
        [DisplayFormat(DataFormatString = "{0} weeks")]
        public Decimal GestationalAge { get; set; } // In Weeks //

        //public DateTime EndDate { get; set; }
        
        //public PregnancyOutcomeType Outcome { get; set; }

        public List<PregnancyOutcome> Outcomes { get; set; }

        public DateTime EndDate
        {
            get
            {
                DateTime returnVal = DateTime.MinValue;

                // *** Derived from outcomes - most recent ***
                if (this.Outcomes != null)
                    foreach (PregnancyOutcome outcome in this.Outcomes)
                        if (outcome.OutcomeDateTime > returnVal)
                            returnVal = outcome.OutcomeDateTime; 

                return returnVal;
            }
        }

        public int Trimester
        {
            get
            {
                int returnVal = 1;

                if (this.GestationalAge < 14)
                    returnVal = 1;
                else if (this.GestationalAge < 27)
                    returnVal = 2;
                else
                    returnVal = 3;

                return returnVal;
            }
        }

    }

    public class PregnancyOutcome
    {
        public DateTime OutcomeDateTime { get; set; }

        public PregnancyOutcomeType OutcomeType { get; set; }
    }
}