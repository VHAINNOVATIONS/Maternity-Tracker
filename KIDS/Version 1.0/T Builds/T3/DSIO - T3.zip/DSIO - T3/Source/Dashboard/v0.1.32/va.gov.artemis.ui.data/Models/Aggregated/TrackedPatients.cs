﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace VA.Gov.Artemis.UI.Data.Models.Aggregated
{
    public class TrackedPatients//: DashboardData 
    {
        public Paging Paging { get; set; }

        public List<TrackedPatient> List { get; set; }

        public TrackedPatients() 
        {
            this.List = new List<TrackedPatient>();
            this.Paging = new Paging();
        }
    }
}