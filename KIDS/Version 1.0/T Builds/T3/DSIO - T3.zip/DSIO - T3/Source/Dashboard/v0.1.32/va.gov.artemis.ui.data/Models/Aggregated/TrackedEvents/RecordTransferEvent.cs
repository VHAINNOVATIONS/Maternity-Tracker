﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VA.Gov.Artemis.UI.Data.Models.Aggregated.Common;

namespace VA.Gov.Artemis.UI.Data.Models.Aggregated.TrackedEvents
{
    public class RecordTransferEvent: TrackedEvent
    {
        public TransferType TransferType { get; set; }

        public override string EventName
        {
            get { return "Record Transfer"; }
        }

        public override string Details
        {
            get { throw new NotImplementedException(); }
        }

        public override TrackedEventType EventType
        {
            get { return TrackedEventType.RecordTransfer; }
        }
    }

    public enum TransferType { Uknown, Out, In }
}
