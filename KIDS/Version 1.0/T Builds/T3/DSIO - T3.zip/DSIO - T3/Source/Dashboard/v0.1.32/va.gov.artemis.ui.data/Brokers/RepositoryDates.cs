﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VA.Gov.Artemis.UI.Data.Brokers
{
    public static class RepositoryDates
    {
        public const string VistADateFormatOne = "MMM d, yyyy@HH:mm:ss";
        public const string VistADateFormatTwo = "M/d/yyyy@HH:mm:ss";
        public const string VistADateFormatThree = "MMM d, yyyy@HH:mm";
    }
}
