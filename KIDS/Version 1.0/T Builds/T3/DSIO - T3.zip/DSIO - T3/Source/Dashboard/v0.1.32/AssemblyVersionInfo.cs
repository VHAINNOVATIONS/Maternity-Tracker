﻿using System.Reflection;

[assembly: AssemblyVersion("1.0.0.0")]

// *** Summary of changes ***

// *** 09/17/2013 0.1.1 Basic deployment fixes ***
// *** 09/17/2013       Added version to footer ***
// *** 10/15/2013 0.1.2 Twitter Bootstrap v3
// ***                  UI Reorganization
// ***                  Mocked Up Views 
// *** 11/05/2013 0.1.3 Removed responsive for now
// ***                  2 Min timeout on logon
// ***                  Default to empty "All" page
// ***                  Modified division selection layout
// ***                  Added message for 99 CVC response
// ***                  Generic layout improvements
// *** 11/06/2013 0.1.4 Build process improvements
// *** 11/08/2013 0.1.5 New command for checking security key 
// ***                  New command for searching for a patient 
// ***                  Unit tests for new commands 
// ***                  Add subject to mail link on home page 
// ***                  Modify text on home page if already logged in
// *** 11/12/2013 0.1.6 Implemented Patient Search (Views, Models, Controllers, Repository, Command, Tests)
// ***                  Removed Old Patient Search Code
// ***                  Fixed Bootstrap Alert Code 
// ***                  Created ActionFilter to disable local caching
// ***                  Added Command/Repository for Admin Security Key 
// ***                  (Note still contains mocked data/functionality...Remove before production)
// *** 11/15/2013 0.1.7 Return to original page after change verify code
// ***                  Use custom route for create tracking log
// ***                  Move "List of Tracked Patients Here" text
// ***                  Make TrackingLog Controller a DashboardController
// ***                  Modified mocked-up data for tracking log
// ***                  Change "Original Verify Code" to "Current Verify Code"
// ***                  Logout on division selection cancel
// ***                  Cleanup patient search cshtml 
// ***                  Remove division selection menu item
// ***                  Disable CVC menu item when on CVC page
// ***                  Added flagged and rejected to tracking log mockup
// ***                  Changed "Tracking Log" to "Tracking History"
// ***                  Code Cleanup on Patient Repository
// *** 11/15/2013 0.1.8 Fixed a few relative links
// *** 12/02/2013 0.1.9 Added command DSIO GET TRACKING
// ***                  Changed to namespace DSIO
// ***                  Created a BasePatient for basic demo information
// ***                  Added command DSIO SELECT LIST
// ***                  Added command ORWPT SELECT
// ***                  Added routes for Tracking History, Flagged Patients, and Track
// ***                  Prevent local caching of data 
// ***                  Use real data for tracking history
// ***                  Created "track" controller for start, stop, accept, and reject 
// ***                  Added FlaggedPatient Index, Details and LastProgress Notes
// ***                  Added top menu bar for demo navigation, removed side navigation
// ***                  Added support for "sensitive" records
// ***                  Modified display parameters for search list
// ***                  Created partial view for tracking history table 
// ***                  Added SelectList respository
// ***                  Added Patient demographics repository method
// ***                  Made minor tweaks based on sprint #1 demo
// *** 12/03/2013 0.1.10 Allow empty results for flagged patients. 
// *** 12/03/2013 0.1.11 Handle invalid date formats in flagged patient list 
// *** 12/03/2013 0.1.12 Standardize all href links using @Url.Action
// ***                   Added informational message to Start, Stop, Accept, Reject page
// ***                   Standardize SSN display to XXX-XX-1234
// ***                   Added "Back to Details" button on last progress note page
// *** 12/10/2013 0.1.13 Verify that user has proper context assigned to them
// ***                   Add paging to get tracking command
// ***                   Add patient flags command parameters to command
// ***                   Add get tracked patients parameters to command
// ***                   Version is dependent on Sprint #3, Build 2 of DSIO KIDS
// ***                   Implement line type parsing
// ***                   Add context to OrwuUserInfo command
// ***                   Check broker connection and display warning if no connection 
// ***                   Check that logged in user user proper context and display message if not
// ***                   Don't crash when multiple error messages added to display
// ***                   Don't add null broker to store
// ***                   Hide division selection message
// ***                   Use real data for flagged patient detail 
// ***                   Use broker result for return on patient search
// ***                   Create partial view to show flagged action (accept/reject)
// ***                   Always show all patients when clicking Tracking History button
// ***                   Add "Back to List" button to Start Tracking dialog (unpopulated)
// ***                   Hide invalid date on tracking history 
// ***                   Add context to web config 
// ***                   Add Create Context method to account repository
// ***                   Split multi-line comments correctly for start, accept, reject tracking
// ***                   Add get tracking entries to tracking history repository
// ***                   Add get patient flagged entries to tracking history repository
// ***                   Correct entry type descriptions
// ***                   Don't process command that fails
// *** 12/16/2013 0.1.14 Show list of tracked patients based on real data
// ***                   Add error message if empty result from ORWPT SELECT
// ***                   Add route for patient summary 
// ***                   Check context after division detection/selection 
// ***                   Show real patient name on patient summary
// ***                   Show error message on create tracking page if problem loading patient 
// ***                   Add placeholder plugin for IE9
// ***                   Added mocked up columns to list of tracked patients 
// ***                   Re-Add source column to tracking history
// ***                   Move comment into tooltip on tracking history
// *** 12/16/2013 0.1.15 Remove Auto-Login
// *** 12/16/2013 0.1.16 Handle empty list of tracked patients 
// *** 12/16/2013 0.1.17 Correct razor formatting on tracked patient list 
// *** 12/19/2013 0.1.18 Use real data for patient's last progress note 
// ***                   Add "Flagged On" column data to list of flagged patients. 
// ***                   Flagged on will show the date of the most recent flagged entry. 
// ***                   Utilize new paging feature of DSIO GET TRACKING for tracking history entries
// ***                   Add proper context to ORWPT SELECT. 
// ***                   Disable last progress note button if patient does not have a progress note
// ***                   Modify patient search functionality so that populated list can be returned to from accept/reject page 
// ***                   Disable caching of search patients 
// ***                   Allow return to patient summary from stop tracking page 
// ***                   Show error detail if tracking history item creation fails
// ***                   Create reusable paging view and model
// ***                   Show release notes by clicking on version in dashboard
// ***                   Allow back button (next to Accept/Reject/Start/Stop) to return to previous page
// ***                   Check for empty results on tracking history page
// ***                   Add paging to list of flagged patients (size=10)
// ***                   Don't show age if dob is invalid
// ***                   Allow time elements (hour, minute, second) to be missing in fileman date returned by rpc's
// *** 12/19/13 0.1.19   Correct relative links on paging and "back" navigation
// *** 01/03/14 0.1.20   Correct top navigation buttons when using chrome browser
// ***                   Correct flagged on date for flagged patient list
// ***                   Show last 5 progress notes (+paged) on flagged patient detail 
// ***                   Show patient contact history and details (mock)
// ***                   Allow patient contact to be recorded (mock)
// ***                   Show patient contact progress note preview before saving (mock)
// ***                   Show pregnancy and other summary data on patient summary (mock)
// ***                   Preserve returnUrl when encountering validation error on create tracking log
// ***                   Use "Return To" instead of "Back" for navigation buttons
// ***                   Support inexact birth dates which may be returned from VistA
// *** 01/17/14 0.1.21   This release is dependent upon KIDS build S4 B3
// ***                   Implement new RPC DSIO FEMALE PATIENT FIND to find a matching patient
// ***                   Implement new RPC DSIO FEMALE PATIENT SEARCH to search for a matching patient 
// ***                   Correct date parsing for "Flagged On" date in flagged patient list 
// ***                   Implement new paging RPC parameter for retrieving tracking history
// ***                   Implement new paging RPC parameter for retrieving tracking history for a patient
// ***                   Implement new paging RPC parameter for retrieving tracked patients
// ***                   Implement new paging RPC parameter for retrieving flagged patients
// ***                   Add new routes for non-va care, db notes, and current pregnancy pages
// ***                   Add new configuration section and toolbar access
// ***                   Standardize page parsing from url in all controllers
// ***                   Allow entry of non-templated dashboard note (MOCK)
// ***                   Show list of dashboard notes (MOCK)
// ***                   Allow entry of non-VA care providers and facilities (MOCK)
// ***                   Show list of non-VA care providers and facilities (MOCK)
// ***                   Show patient's non-VA care provider and facility (MOCK)
// ***                   Allow selection of a patient's non-VA care provider and facility (MOCK)
// ***                   Add paging to list of tracked patients (10 per page)
// ***                   Use RPC filtering for patient tracking history and add paging
// ***                   Make progress notes list a partial view
// ***                   Add pregnancy history and risk factors to patient summary (MOCK)
// ***                   Add non-VA care to dashboard repository 
// ***                   Call proper RPC (SEARCH or FIND) based on criteria entered (Letter + 4 nums will use FIND)
// ***                   Change date/timer parsing to m/d/yyyy on tracking items repository
// *** 02/??/2014 0.1.22 This version is dependent upon Sprint 5 Build 2 KID build
// ***                   Allow user to create a dashboard note
// ***                   Show a list of the patient's dashboard notes
// ***                   Allow user to view a dashboard note 
// ***                   Allow user to delete a dashboard note 
// ***                   Allow user to sign a dashboard note 
// ***                   Allow user to append to a dashboard note 
// ***                   Allow user to edit a dashboard note 
// ***                   Implement paging on search result 
// ***                   Create generic route for dashboard notes
// ***                   Use dfn for default route parameter instead of id 
// ***                   Enforce maximum session timeout value of 525600
// ***                   Convert timeout value from VistA to minutes for session
// ***                   Create centralized patient demographics retrieval for dashboard controller
// ***                   Return to selected page on flagged patient list
// ***                   Return to last page when returning to tracking history list 
// ***                   Display (No Patient Found) in patient block if not found 
// ***                   Use upper case for patient search parameters (I+Last4)
// ***                   Show sensitive SSN properly in patient search 
// *** 02/17/2014 0.1.23 Added DSIO context to XUS CVC so user can change verify code from menu. 
// ***                   Implement paging on dashboard notes list
// ***                   Correct namespaces for consistency
// *** 02/18/2014 0.1.24 This build is dependent upon Kids build S6 B1
// ***                   Removed Mocked up and incomplete code
// ***                   General code cleanup
// *** 02/18/2014 0.1.25 Correct links for dashboard note actions
// ***                   Remove auto-login      
// *** 02/18/2014 0.1.26 Correct dashboard note page descriptions
// ***                   Add message to click a note to select 
// ***                   Fix flagged patient progress note list
// ***                   KNOWN ISSUE: Flagged patient progress notes cannot be viewed by non-programmer (Rpc/Context)
// *** 02/24/2014 0.1.27 Make sure session timeout is not larger than allowable
// ***                   Return to last page of tracked patients list from patient summary page
// ***                   Return to last page of flagged patients list from flagged patient progress note view 
// *** 02/24/2014 0.1.28 Process verify codes as all upper case when using change verify code
// *** 02/25/2014 0.1.29 Set return url properly on tracked patients button on patient summary page. 
// *** 03/20/2014 0.1.30 This build is dependent on DSIO KID build S7 B4
// ***                   Added Cda library project to generate Cda documents
// ***                   Added cda test project to test library 
// ***                   Added Ien to create a not rpc return
// ***                   Remove DSIO patient search command 
// ***                   Added Vpr command and objects to command project
// ***                   Added command DSIO IHE SAVE
// ***                   Added Cda document exchange view, model, controller, action
// ***                   Added Cda document options view, model, controller, action
// ***                   Added Cda document preview/generation view, model, controller, action
// ***                   Added Cda documents button to patient summary 
// ***                   Fixed missing close tag in _manage partial view
// ***                   Created Cda repository 
// ***                   Allow truncated fileman dates
// *** 03/21/2014 0.1.31 Fix path issues for generated cda documents and stylesheet
// *** 03/26/2014 0.1.32 This build is dependent on DSIO KID build S7 B5
// ***                   Allow a Cda document to be stored including header information
// ***                   Retrieve a list of Cda documents for a patient  
// ***                   Get the document content for a single historical item
// ***                   Added routes for Cda pages 
// ***                   Created Views/Actions for Cda (DataImport, DocumentView, PatientMatch, PreviewUpload)
// ***                   Enhanced repository to support Cda document storage, retrieval, and processing 
// ***                   Add progressive patient search to find matching patient for cda document 
// ***                   Centralize VistA date formats
// ***                   Create models to support CDA documents and processing 



// FUTURE...
// ***                   Add routing for non-va care list
// ***                   Add lab detail view (MOCK)
// ***                   Add Mccd detail view (MOCK)
// ***                   Show list of non-VA care items 
// ***                   Allow addition of non-VA care items 
// ***                   Allow edit of non-VA care items 
// ***                   Keep configuration button active when viewing list of non-VA care items
// ***                   Create a page to allow changing of the pregnancy status (MOCK)
// ***                   Show list of EDD entries (MOCK)
// ***                   Add navigation to patient's non-va care items (MOCK)
// ***                   Modify patient summary view based on feedback (MOCK)
// ***                   Change initial patient contact view based on received template (MOCK)
// ***                   Move action buttons on patient contact view to the right for consistency (MOCK)

[assembly: AssemblyFileVersion("0.1.32.0")]