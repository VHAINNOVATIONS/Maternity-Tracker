﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VA.Gov.Artemis.Vista.Broker;
using VA.Gov.Artemis.Vista.Utility;

namespace VA.Gov.Artemis.Commands.Dsio
{
    public class DsioIheGetDocCommand : DsioCommand
    {
        // *** Object gets populated by command result ***
        public DsioCdaDocument Document { get; set; }

        // *** Can retrieve header or comment ***
        private bool headerOnly { get; set; }

        public DsioIheGetDocCommand(IRpcBroker newBroker)
            : base(newBroker)
        {}

        public override string RpcName
        {
            get { return "DSIO IHE GET DOC"; }
        }

        public void AddCommandArguments(string ien, bool includeHeaderOnly)
        {
            // *** Add Ien and header only command arguments ***

            this.headerOnly = includeHeaderOnly;

            string xmlParam = (this.headerOnly) ? "" : "1";

            this.CommandArgs = new object[] { ien, xmlParam };
        }


        protected override void ProcessResponse()
        {
            // *** Process data that is returned from RPC ***

            if (string.IsNullOrWhiteSpace(this.Response.Data))
            {
                this.Response.Status = RpcResponseStatus.Fail;
                this.Response.InformationalMessage = "No return value";
            }
            else
            {
                // *** Get first piece ***
                string piece1 = Util.Piece(this.Response.Lines[0], Caret, 1);

                // *** If -1 then we have an error ***
                if (piece1 == "-1")
                {
                    this.Response.Status = RpcResponseStatus.Fail;
                    this.Response.InformationalMessage = Util.Piece(this.Response.Lines[0], Caret, 2); ;
                }
                else
                {
                    // *** Determine format of return data ***
                    if (this.headerOnly)
                    {
                        // *** Create the document ***
                        this.Document = new DsioCdaDocument();

                        // *** Get the return as lines ***
                        string[] lines = this.Response.Lines;

                        // *** Sample ***
                        //GUID^ef121657-fd4a-4089-957b-087e58d7ae55
                        //PATIENT^DRMPATIENT,TEN^715
                        //DT CREATION^MAR 23, 2014@07:04:08
                        //DT IMPORT/EXPORT^MAR 23, 2014@07:04:21
                        //DOCUMENT TYPE^APHP
                        //DIRECTION^OUT
                        //DOCUMENT TITLE^VA Salt Lake City Antepartum History & Physical
                        //SENDING FACILITY/PROVIDER^VA Salt Lake City
                        //INTENDED RECIPIENT^

                        // *** Loop through all the lines ***
                        foreach (string line in lines)
                        {
                            // *** Check first piece ***
                            switch (Util.Piece(line, Caret, 1))
                            {
                                case "GUID":
                                    this.Document.Id = Util.Piece(line, Caret, 2);
                                    break;
                                case "PATIENT":
                                    //this.Document.Id = Util.Piece(line, Caret, 2);
                                    break;
                                case "DT CREATION":
                                    this.Document.CreatedOn = Util.Piece(line, Caret, 2);
                                    break;
                                case "DT IMPORT/EXPORT":
                                    this.Document.ImportExportDate = Util.Piece(line, Caret, 2);
                                    break;
                                case "DOCUMENT TYPE":
                                    this.Document.DocumentType = Util.Piece(line, Caret, 2);
                                    break;
                                case "DIRECTION":
                                    this.Document.Direction = Util.Piece(line, Caret, 2);
                                    break;
                                case "DOCUMENT TITLE":
                                    this.Document.Title = Util.Piece(line, Caret, 2);
                                    break;
                                case "SENDING FACILITY/PROVIDER":
                                    this.Document.Sender = Util.Piece(line, Caret, 2);
                                    break;
                                case "INTENDED RECIPIENT":
                                    this.Document.IntendedRecipient = Util.Piece(line, Caret, 2);
                                    break;
                            }
                        }

                        // *** Indicate success ***
                        this.Response.Status = RpcResponseStatus.Success;
                    }
                    else
                    {
                        // *** Create new document ***
                        this.Document = new DsioCdaDocument();

                        // *** Populate content ***
                        this.Document.Content = this.Response.Data;

                        // *** Indicate success ***
                        this.Response.Status = RpcResponseStatus.Success;
                    }
                }
            }
        }
    }
}