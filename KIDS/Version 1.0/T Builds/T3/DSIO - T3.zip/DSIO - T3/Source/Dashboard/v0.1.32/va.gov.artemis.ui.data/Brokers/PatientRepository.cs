﻿using VA.Gov.Artemis.Vista.Broker;
using VA.Gov.Artemis.UI.Data.Models.Aggregated;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using VA.Gov.Artemis.UI.Data.Models.Aggregated.TrackedEvents;
using VA.Gov.Artemis.UI.Data.Models;
using VA.Gov.Artemis.Commands.Dsio;
using VA.Gov.Artemis.Commands.Orwpt;
using VA.Gov.Artemis.UI.Data.Brokers.Results;
using VA.Gov.Artemis.Vista.Utility;
using VA.Gov.Artemis.Core;
using System.Text.RegularExpressions;
using VA.Gov.Artemis.UI.Data.Models.Aggregated.Common;  

namespace VA.Gov.Artemis.UI.Data.Brokers
{
    public class PatientRepository: RepositoryBase, IPatientRepository
    {
        public PatientRepository(IRpcBroker newBroker): base(newBroker) {}

        //public TrackedPatient Get(string dfn)
        //{
        //    TrackedPatient returnPatient;

        //    returnPatient = new TrackedPatient()
        //    {
        //        Dfn = "1",
        //        FirstName = "Jane",
        //        LastName = "Doe",
        //        DateOfBirth = new DateTime(1990, 3, 12),
        //        Last4 = "2345",
        //        PhoneNumber = "(212) 949-9393",
        //        CurrentPregnancy = new Pregnancy() { EstimatedDeliveryDate = new DateTime(2013, 9, 1), GestationalAge = 12, LastMenstrualPeriod = new DateTime(2012, 12, 12) }
        //    };

        //    for (int i = 0; i < 5; i++)
        //    {
        //        AppointmentEvent appointmentEvent = new AppointmentEvent()
        //        {
        //            EventId = i,
        //            ItemId = "345",
        //        };
        //        switch (i)
        //        {
        //            case 0:
        //                appointmentEvent.EventDate = DateTime.Now.AddDays(-10);
        //                appointmentEvent.Status = TrackedEventCompletionStatus.Overdue;
        //                break;
        //            case 1:
        //                appointmentEvent.EventDate = DateTime.Now;
        //                appointmentEvent.Status = TrackedEventCompletionStatus.Due;
        //                break;
        //            case 2:
        //                appointmentEvent.EventDate = DateTime.Now.Add(new TimeSpan(3, 0, 0, 0));
        //                appointmentEvent.Status = TrackedEventCompletionStatus.Due;
        //                break;
        //            case 3:
        //                appointmentEvent.EventDate = DateTime.Now;
        //                appointmentEvent.Status = TrackedEventCompletionStatus.Completed;
        //                appointmentEvent.Provider = "Test, Provider";
        //                break;
        //            default:
        //                appointmentEvent.EventDate = DateTime.Now.Add(new TimeSpan(6, 0, 0, 0));
        //                appointmentEvent.Status = TrackedEventCompletionStatus.Pending;
        //                break;
        //        }
        //        returnPatient.TrackedEvents.Add(appointmentEvent);
        //    }
        //        for (int j = 0; j < 5; j++)
        //        {
        //            LabEvent labEvent = new LabEvent()
        //            {
        //                EventId = j,
        //                ItemId = "345",
        //                Specimen = "Test Specimin", 
        //                Accession = "Accession"
        //            };
        //            switch (j)
        //            {
        //                case 0:
        //                    labEvent.EventDate = DateTime.Now.AddDays(-10);
        //                    labEvent.Status = TrackedEventCompletionStatus.Overdue;
        //                    break;
        //                case 1:
        //                    labEvent.EventDate = DateTime.Now;
        //                    labEvent.Status = TrackedEventCompletionStatus.Due;
        //                    break;
        //                case 2:
        //                    labEvent.EventDate = DateTime.Now.Add(new TimeSpan(3, 0, 0, 0));
        //                    labEvent.Status = TrackedEventCompletionStatus.Due;
        //                    break;
        //                case 3:
        //                    labEvent.EventDate = DateTime.Now;
        //                    labEvent.Status = TrackedEventCompletionStatus.Completed;
        //                    labEvent.Provider = "Test, Provider";
        //                    break;
        //                default:
        //                    labEvent.EventDate = DateTime.Now.Add(new TimeSpan(6, 0, 0, 0));
        //                    labEvent.Status = TrackedEventCompletionStatus.Pending;
        //                    break;
        //            }
        //            returnPatient.TrackedEvents.Add(labEvent);
        //        }           

        //    return returnPatient;
        //}

        //public TrackedPatients GetTrackedPatientsData()
        //{
        //    TrackedPatients model = new TrackedPatients();

        //    model.List = new List<TrackedPatient>(){
        //                new TrackedPatient() {Dfn="1", FirstName = "Jane", LastName="Doe", DateOfBirth = new DateTime(1990, 3, 12) ,Last4 = "2345", PhoneNumber = "(212) 949-9393", 
        //                    CurrentPregnancy = new Pregnancy(){ EstimatedDeliveryDate= new DateTime(2013,9,1), GestationalAge=12, LastMenstrualPeriod=new DateTime(2012,12,12)}}, 
        //                new TrackedPatient() {Dfn="2", FirstName = "Susan", LastName="Smith", DateOfBirth = new DateTime(1989,4,3) ,Last4 = "5432", PhoneNumber = "(212) 234-5678",                     
        //                    CurrentPregnancy = new Pregnancy(){ EstimatedDeliveryDate= new DateTime(2013,7,24), GestationalAge=38, LastMenstrualPeriod=new DateTime(2012,9,24)}},
        //                new TrackedPatient() {Dfn="3", FirstName = "Liz", LastName="Jones", DateOfBirth = new DateTime(1990,10,3) ,Last4 = "9483", PhoneNumber = "(212) 342-3234", 
        //                    CurrentPregnancy = new Pregnancy() {EstimatedDeliveryDate= new DateTime(2013,11,12), GestationalAge=22, LastMenstrualPeriod=new DateTime(2013,1,12)}}, 
        //                new TrackedPatient() {Dfn="4", FirstName = "Alison", LastName="Jackson", DateOfBirth = new DateTime(1990, 5, 3) ,Last4 = "8383", PhoneNumber = "(212) 988-3438", 
        //                    CurrentPregnancy = new Pregnancy() {EstimatedDeliveryDate= new DateTime(2014,3,7), GestationalAge=2, LastMenstrualPeriod=new DateTime(2013,5,12)}}, 
        //                new TrackedPatient() {Dfn="5", FirstName = "Cathy", LastName="Johnson", DateOfBirth = new DateTime(1985, 9, 3),Last4 = "1209", PhoneNumber = "(212) 983-0398", 
        //                    CurrentPregnancy = new Pregnancy() {EstimatedDeliveryDate= new DateTime(2013,9,28), GestationalAge=30, LastMenstrualPeriod=new DateTime(2012,11,12)}},
        //                new TrackedPatient() {Dfn="6", FirstName = "Molre", LastName="millrd", DateOfBirth = new DateTime(1986, 12, 3),Last4 = "2322", PhoneNumber = "(343) 433-0453", 
        //                     PostPartum= true },
        //                new TrackedPatient() {Dfn="7", FirstName = "Debra", LastName="Doe", DateOfBirth = new DateTime(1990, 3, 12) ,Last4 = "2345", PhoneNumber = "(212) 949-9393", 
        //                    CurrentPregnancy = new Pregnancy(){ EstimatedDeliveryDate= new DateTime(2013,9,1), GestationalAge=12, LastMenstrualPeriod=new DateTime(2012,12,12)}}, 
        //                new TrackedPatient() {Dfn="8", FirstName = "Jessica", LastName="Smith", DateOfBirth = new DateTime(1989,4,3) ,Last4 = "5432", PhoneNumber = "(212) 234-5678",                     
        //                    CurrentPregnancy = new Pregnancy(){ EstimatedDeliveryDate= new DateTime(2013,7,24), GestationalAge=38, LastMenstrualPeriod=new DateTime(2012,9,24)}},
        //                new TrackedPatient() {Dfn="9", FirstName = "Shannon", LastName="Jones", DateOfBirth = new DateTime(1990,10,3) ,Last4 = "9483", PhoneNumber = "(212) 342-3234", 
        //                    CurrentPregnancy = new Pregnancy() {EstimatedDeliveryDate= new DateTime(2013,11,12), GestationalAge=22, LastMenstrualPeriod=new DateTime(2013,1,12)}}, 
        //                new TrackedPatient() {Dfn="10", FirstName = "Vicki", LastName="Jackson", DateOfBirth = new DateTime(1990, 5, 3) ,Last4 = "8383", PhoneNumber = "(212) 988-3438", 
        //                    CurrentPregnancy = new Pregnancy() {EstimatedDeliveryDate= new DateTime(2014,3,7), GestationalAge=2, LastMenstrualPeriod=new DateTime(2013,5,12)}}, 
        //                new TrackedPatient() {Dfn="11", FirstName = "Sharon", LastName="Johnson", DateOfBirth = new DateTime(1985, 9, 3),Last4 = "1209", PhoneNumber = "(212) 983-0398", 
        //                    CurrentPregnancy = new Pregnancy() {EstimatedDeliveryDate= new DateTime(2013,9,28), GestationalAge=30, LastMenstrualPeriod=new DateTime(2012,11,12)}},
        //                new TrackedPatient() {Dfn="12", FirstName = "Veronica", LastName="millrd", DateOfBirth = new DateTime(1986, 12, 3),Last4 = "2322", PhoneNumber = "(343) 433-0453", 
        //                     PostPartum= true }

        //            };

        //    return model;
        //}

        public PatientSearchResult Search(string searchParam, int page, int itemsPerPage)
        {
            // *** Gets female patients matching search criteria ***

            PatientSearchResult result = new PatientSearchResult();

            DsioFemalePatientSearchCommand patSearchCommand; 

            if (Regex.IsMatch(searchParam, @"^[a-zA-Z]\d{4}$"))
            {
                // *** Use Find command ***
                DsioFemalePatientFindCommand tempCommand = new DsioFemalePatientFindCommand(broker);

                tempCommand.AddCommandArguments(searchParam.ToUpper());

                patSearchCommand = tempCommand; 
            }
            else 
            {
                // *** Use Search command ***
                patSearchCommand = new DsioFemalePatientSearchCommand(broker);

                // *** Set arguments/parameters ***
                if (string.IsNullOrWhiteSpace(searchParam))
                    patSearchCommand.AddCommandArguments("", page, itemsPerPage);
                else
                    patSearchCommand.AddCommandArguments(searchParam.ToUpper(), page, itemsPerPage);
            }

            // *** Create the pat search command ***
            //DsioPatientSearchCommand patSearchCommand = new DsioPatientSearchCommand(broker);
            //DsioFemalePatientSearchCommand patSearchCommand = new DsioFemalePatientSearchCommand(broker);


            // *** Execute command ***
            RpcResponse response = patSearchCommand.Execute();

            // *** Set return values ***
            result.Success = (response.Status == RpcResponseStatus.Success);
            result.Message = response.InformationalMessage; 

            // *** If we have patients, then add them to return ***
            if (response.Status == RpcResponseStatus.Success)
            {
                if (patSearchCommand.MatchingPatients != null)
                    if (patSearchCommand.MatchingPatients.Count > 0)
                        foreach (DsioSearchPatient commandPatient in patSearchCommand.MatchingPatients)
                        {
                            SearchPatient uiPatient = GetSearchPatient(commandPatient);

                            if (uiPatient != null)
                                result.Patients.Add(uiPatient);
                        }
                result.TotalResults = patSearchCommand.TotalResults;
            }

            return result; 
        }

        public PatientSearchResult ProgressiveSearch(string lastName, string firstName, int page, int itemsPerPage)
        {
            // *** Tries several searches to get results ***

            PatientSearchResult result = new PatientSearchResult();

            List<string> searchValueList = new List<string>();

            string[] searchVals = new string[] {
                string.Format("{0},{1}", lastName, firstName),
                string.Format("{0},{1}", lastName, firstName.Substring(0, 1)),
                string.Format("{0}", lastName)
                };

            bool keepLooking = true; 
            int idx = 0;

            while ((keepLooking) && (idx < searchVals.Length))
            {
                result = Search(searchVals[idx], page, itemsPerPage);

                if (result.Success)
                    if (result.Patients != null)
                        if (result.Patients.Count > 0)
                            keepLooking = false;
                
                idx += 1; 
            }
             
            return result; 
        }

        private SearchPatient GetSearchPatient(DsioSearchPatient commandPatient)
        {
            // *** Gets a SearchPatient based on string only commandPatient ***

            // *** Get the tracking status ***
            CurrentTrackingStatus trackStat = GetTrackingStatus(commandPatient.TrackingStatus);
         
            // *** Create the new patient ***
            SearchPatient uiPatient = new SearchPatient()
            {
                Dfn = commandPatient.Dfn,
                LastName = commandPatient.LastName,
                FirstName = commandPatient.FirstName,
                Veteran = commandPatient.Veteran,
                Location = commandPatient.Location,
                RoomBed = commandPatient.RoomBed,
                CurrentlyTracking = trackStat
            };

            // *** Determine if sensitive ***
            if (commandPatient.Last4.Contains("SENSITIVE"))
                uiPatient.Sensitive = true; 
            else 
            {
                // *** Prepare SSN ***
                uiPatient.Last4 = commandPatient.Last4;
                uiPatient.FullSSN = string.Format("XXX-XX-{0}", uiPatient.Last4);

                // *** Handle DOB ***
                //DateTime dob = DateTime.MinValue ;
                //if (DateTime.TryParse(commandPatient.DateOfBirth, out dob))
                //    uiPatient.DateOfBirth = dob;
                //else
                //{
                //    uiPatient.DateOfBirth = DateTime.MinValue; 
                //    SimpleTrace.TraceError(string.Format("PatientRepository.GetSearchPatient: Could not parse date [{0}]", commandPatient.DateOfBirth ));
                //}

                // *** Process/Parse dob ***
                DateTime dob;
                if (DateTime.TryParse(commandPatient.DateOfBirth, out dob))
                    uiPatient.DateOfBirth = dob;
                else
                    uiPatient.DateOfBirthInexact = Util.GetInexactDate(commandPatient.DateOfBirth);

            }

            return uiPatient; 
        }

        private CurrentTrackingStatus GetTrackingStatus(string trackingStatus)
        {
            CurrentTrackingStatus returnVal = CurrentTrackingStatus.No;

            switch (trackingStatus)
            {
                case "1":
                    returnVal = CurrentTrackingStatus.Yes;
                    break;
                case "2":
                    returnVal = CurrentTrackingStatus.Flagged;
                    break;
                case "0":
                default:                
                    returnVal = CurrentTrackingStatus.No;
                    break;
            }

            return returnVal;
        }

        public FlaggedPatientsResult GetFlaggedPatients(int page, int itemsPerPage)
        {
            // *** Gets a list of flagged patients ***

            FlaggedPatientsResult result = new FlaggedPatientsResult(); 

            // *** Create the command ***
            DsioGetTrackingCommand command = new DsioGetTrackingCommand(this.broker);

            // *** Add the parameters ***
            command.AddGetFlaggedPatientsParameters(page, itemsPerPage);

            // *** Execute the command ***
            RpcResponse response = command.Execute();

            result.Success = (response.Status == RpcResponseStatus.Success);
            result.Message = response.InformationalMessage; 

            // *** Check for success and results ***
            if (result.Success)
                if (command.FlaggedPatientResult != null) 
                    if (command.FlaggedPatientResult.FlaggedPatients != null)
                        if (command.FlaggedPatientResult.FlaggedPatients.Count > 0)
                        {
                            result.Patients = ProcessDsioFlaggedPatients(command.FlaggedPatientResult.FlaggedPatients);

                            result.TotalResults = command.TotalResults; 
                        }

            return result; 
        }

        private List<FlaggedPatient> ProcessDsioFlaggedPatients(Dictionary<string, DsioFlaggedPatient> dsioFlaggedPatients)
        {
            // *** Get list of flagged patients from dictionary of dsio flagged patients ***

            List<FlaggedPatient> returnList = new List<FlaggedPatient>();

            // *** Loop ***
            foreach (DsioFlaggedPatient dsioPatient in dsioFlaggedPatients.Values)
            {
                // *** Get tracking history for this patient ***

                DsioGetTrackingCommand command = new DsioGetTrackingCommand(broker);

                command.AddPatientFlagsParameter(dsioPatient.Dfn); 

                RpcResponse response = command.Execute();

                if (response.Status == RpcResponseStatus.Success)
                    foreach (DsioTrackingItem item in command.TrackingItems)
                        dsioPatient.TrackingItems.Add(item.Id, item);

                // *** Create new flagged patient and add to list ***
                FlaggedPatient patient = this.GetFlaggedPatient(dsioPatient);

                returnList.Add(patient);
            }
            return returnList; 
        }

        private FlaggedPatient GetFlaggedPatient(DsioFlaggedPatient dsioPatient)
        {
            // *** Create new flagged patient ***

            FlaggedPatient patient = new FlaggedPatient();

            patient.Dfn = dsioPatient.Dfn;
            patient.FirstName = dsioPatient.FirstName;
            patient.LastName = dsioPatient.LastName;

            if (dsioPatient.Last4.Length > 4)
                if (dsioPatient.Last4.ToUpper().Contains("SENSITIVE"))
                {
                    patient.Last4 = "XXXX";
                    patient.FullSSN = dsioPatient.Last4;
                }
                else
                {
                    patient.Last4 = dsioPatient.Last4.Substring(5, 4);
                    patient.FullSSN = string.Format("XXX-XX-{0}", patient.Last4);
                }
            else
            {
                patient.Last4 = dsioPatient.Last4;
                patient.FullSSN = string.Format("XXX-XX-{0}", patient.Last4);
            }

            //patient.FullSSN = string.Format("XXX-XX-{0}", dsioPatient.Last4);
            //patient.Last4 = dsioPatient.Last4;

            // *** Process/Parse dob ***
            DateTime dob;
            if (DateTime.TryParse(dsioPatient.DateOfBirth, out dob))
                patient.DateOfBirth = dob;
            else
                patient.DateOfBirthInexact = Util.GetInexactDate(dsioPatient.DateOfBirth);

            patient.FlagSummary = dsioPatient.FlagSummary;
            patient.FlaggedOn = dsioPatient.FlaggedOn;

            return patient; 
        }

        public PatientDemographicsResult GetPatientDemographics(string dfn)
        {
            PatientDemographicsResult result = new PatientDemographicsResult();

            OrwptSelectCommand command = new OrwptSelectCommand(this.broker);

            command.AddDfnArgument(dfn);

            RpcResponse response = command.Execute();

            result.Success = (response.Status == RpcResponseStatus.Success);
            result.Message = response.InformationalMessage; 

            if (result.Success)
            {
                result.Patient = new BasePatient();
                result.Patient.Dfn = command.Patient.Dfn;
                result.Patient.LastName = Util.Piece(command.Patient.PatientName, ",", 1); 
                result.Patient.FirstName = Util.Piece(command.Patient.PatientName, ",",2);

                result.Patient.DateOfBirth = Util.GetDateTime(command.Patient.DOB);

                if (result.Patient.DateOfBirth == DateTime.MinValue)
                    result.Patient.DateOfBirthInexact = Util.GetInexactDateFromFM(command.Patient.DOB); 

                result.Patient.FullSSN = command.Patient.SSN;

                int length = result.Patient.FullSSN.Length;

                if (length == 9)
                    result.Patient.Last4 = result.Patient.FullSSN.Substring(5);
                else if (length == 10)
                    if (result.Patient.FullSSN.EndsWith("P"))
                        result.Patient.Last4 = result.Patient.FullSSN.Substring(5, 4);
                
            }

            return result;
        }

        public TrackedPatientsResult GetTrackedPatients(int page, int itemsPerPage)
        {
            // *** Gets a tracked patients result from the broker ***

            TrackedPatientsResult result = new TrackedPatientsResult();

            // *** Create the command needed to get tracked patients ***
            DsioGetTrackingCommand command = new DsioGetTrackingCommand(this.broker);

            // *** Add appropriate parameters ***
            command.AddGetTrackedPatientsParameters(page, itemsPerPage);

            // *** Execute command and get response ***
            RpcResponse response = command.Execute();

            // *** Add response to return result ***
            result.Success = (response.Status == RpcResponseStatus.Success); 

            // *** Check for success ***
            if (result.Success)
            {
                result.Patients = new List<TrackedPatient>(); 

                // *** Check if we have result ***
                if (command.TrackedPatients != null)
                {
                    // *** Loop through resulting patients ***
                    foreach (DsioTrackedPatient dsioPatient in command.TrackedPatients)
                    {
                        // *** Get strongly typed patient from dsio Patient ***
                        TrackedPatient trackedPatient = GetTrackedPatient(dsioPatient);

                        // *** Add patient to list ***
                        result.Patients.Add(trackedPatient); 
                    }
                }

                result.TotalResults = command.TotalResults; 
            }

            return result; 
        }

        public TrackedPatient GetTrackedPatient(DsioTrackedPatient dsioPatient)
        {
            // *** Converts dsio patient to strongly typed patient ***

            TrackedPatient returnPatient = new TrackedPatient();

            // *** Add values ***
            returnPatient.Dfn = dsioPatient.Dfn;
            returnPatient.LastName = dsioPatient.LastName;
            returnPatient.FirstName = dsioPatient.FirstName;

            if (dsioPatient.Last4.Length > 4)
                if (dsioPatient.Last4.ToUpper().Contains("SENSITIVE"))
                    returnPatient.Last4 = "XXXX";
                else 
                    returnPatient.Last4 = dsioPatient.Last4.Substring(5, 4);
            else  
                returnPatient.Last4 = dsioPatient.Last4; 

            // *** Process/Parse dob ***
            DateTime dob;
            if (DateTime.TryParse(dsioPatient.DateOfBirth, out dob))
                returnPatient.DateOfBirth = dob;
            else
                returnPatient.DateOfBirthInexact = Util.GetInexactDate(dsioPatient.DateOfBirth);

            returnPatient.PhoneNumber = dsioPatient.PhoneNumber;

            // *** Process/Parse EDD ***
            DateTime edd;
            if (DateTime.TryParse(dsioPatient.EDD, out edd))
            {
                returnPatient.CurrentPregnancy = new Pregnancy();
                returnPatient.CurrentPregnancy.EstimatedDeliveryDate = edd; 
            }

            return returnPatient; 

        }

        public PatientSummaryResult GetPatientSummary(string dfn)
        {
            PatientSummaryResult result = new PatientSummaryResult();

            // TODO:...

            return result; 
        }
    }

}