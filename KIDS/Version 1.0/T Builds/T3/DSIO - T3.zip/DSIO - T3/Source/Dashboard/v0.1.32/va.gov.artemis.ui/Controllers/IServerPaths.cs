﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VA.Gov.Artemis.UI.Controllers
{
    public interface IServerPaths
    {
        string MapPath(string path);
    }
}
