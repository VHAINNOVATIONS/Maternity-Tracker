﻿using VA.Gov.Artemis.Commands.Xus;
using VA.Gov.Artemis.UI.Data.Brokers;
using VA.Gov.Artemis.UI.Data.Brokers.Results;
using VA.Gov.Artemis.UI.Filters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using VA.Gov.Artemis.Vista.Broker;

namespace VA.Gov.Artemis.UI.Controllers
{
    [Authorize]
    [VerifySession]
    public class DivisionController : DashboardController
    {
        // *** Default constructor used by MVC ***
        public DivisionController() : base() { }

        // *** Broker constructor for testing with mock broker ***
        public DivisionController(IRpcBroker broker): base(broker) {}

        [HttpGet]
        public ActionResult Select()
        {
            // *** Show the division selection ***

            ActionResult returnResult;
            
            // *** Get the division data from the session ***
            List<XusDivision> divData = (List<XusDivision>)TempData[DivisionDataKey]; 

            // *** Check if we have anything to work with ***
            if (divData == null)
            {
                DivisionResult opResult = this.DashboardRepository.Divisions.GetList(); 

                if (opResult.Success) 
                    divData = opResult.Divisions; 

            }

            returnResult = View(divData); 

            return returnResult; 
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Select(FormCollection formCollection)
        {
            // *** Select the division ***
            ActionResult returnResult;

            if (formCollection.Get("division.IsDefault") != null)
            {
                // *** Get the division id ***
                string selectedDivId = formCollection["division.IsDefault"].ToString();

                // *** Attempt to select ***

                BrokerOperationResult opResult = this.DashboardRepository.Divisions.Select(selectedDivId);

                if (opResult.Success)
                {
                    // *** Indicate success to user ***
                    // TODO: Show actual division that was selected...
                    //this.Information("Division Selected");

                    // *** Check that user has the proper context ***
                    BrokerOperationResult result = this.DashboardRepository.Accounts.CreateContext();

                    if (!result.Success)
                    {
                        this.Error(result.Message);
                        this.CloseBroker();
                        returnResult = RedirectToAction("Login");
                    }
                    else
                    {

                        // *** Set the session timeout based on value in vista ***                            
                        int timeout = this.DashboardRepository.Accounts.GetUserTimeout();

                        // TODO: Used for testing...
                        //timeout = 1; 

                        // *** Set timeout ***
                        if (timeout > 525600)
                            timeout = 525600; 

                        if (timeout > 1)
                            Session.Timeout = timeout;

                        // *** Redirect ***
                        returnResult = RedirectToAction("Overview", "PatientList");
                    }
                }
                else
                {
                    this.Error("Division selection failed");
                    returnResult = RedirectToAction("Select");
                }
            }
            else
            {
                this.Error("Division selection failed");
                returnResult = RedirectToAction("Select");
            }
            
            return returnResult; 
        }

    }
}
