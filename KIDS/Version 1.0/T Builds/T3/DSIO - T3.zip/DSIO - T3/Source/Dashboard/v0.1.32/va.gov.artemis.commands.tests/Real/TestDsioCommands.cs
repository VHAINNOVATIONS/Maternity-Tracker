﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using VA.Gov.Artemis.Commands.tests.real;
using VA.Gov.Artemis.Vista.Broker;
using VA.Gov.Artemis.Commands.Xus;
using VA.Gov.Artemis.Commands.Dsio;

namespace VA.Gov.Artemis.Commands.tests.Real
{
    [TestClass]
    public class TestDsioCommands: TestCommandsBase
    {
        //[TestMethod]
        //public void TestPatientList_Good()
        //{
        //    TestPatientList("CPRSPATIENT");
        //}

        //[TestMethod]
        //public void TestPatientList_Empty()
        //{
        //    TestPatientList("");
        //}

        //[TestMethod]
        //public void TestPatientList_MixedCase()
        //{
        //    TestPatientList("CpRsPatient");
        //}
        
        //private void TestPatientList(string lastName) 
        //{
        //    using (RpcBroker broker = GetConnectedBroker())
        //    {
        //        XusSignonSetupCommand signonSetupCommand = new XusSignonSetupCommand(broker);

        //        RpcResponse response = signonSetupCommand.Execute();

        //        Assert.AreEqual(RpcResponseStatus.Success, response.Status); 

        //        //XusAvCodeCommand avCodeCommand = new XusAvCodeCommand(broker, ValidAccessCodes[0], ValidVerifyCodes[0]);
        //        XusAvCodeCommand avCodeCommand = new XusAvCodeCommand(broker, "NURSE123.", "NURSE234?");

        //        response = avCodeCommand.Execute();

        //        Assert.AreEqual(RpcResponseStatus.Success, response.Status); 

        //        VfdwvPatientListCommand patListCommand = new VfdwvPatientListCommand(broker, lastName);

        //        response = patListCommand.Execute();

        //        Assert.AreEqual(RpcResponseStatus.Success, response.Status); 

        //        Assert.IsNotNull(patListCommand.ReturnData);

        //        broker.Disconnect();
        //    }
        //}

        // *** Requirements for Patient Search ***
        // *** Search by Initial of Last Name + Last 4 of SSN ***
        // *** Search by Partial last name ***
        // *** Search by Full name 

        //1.	Patient DFN
        //2.	Last Name
        //3.	First Name
        //4.	Last 4 of SSN
        //5.	DOB
        //6.	Veteran Status
        //7.	Location
        //8.	Room/Bed
        //9.	Service Connected
        //10.	Tracking Status
        //a.	0 = Yes, patient is currently being tracked
        //b.	1 = No, patient is NOT currently being tracked
        //c.	2 = Pending, patient has been automatically flagged for tracking by a trigger or data element but has not been accepted or rejected for tracking.

        [TestMethod]
        public void TestPatientSearch_ILast4()
        {
            TestPatientSearch("C0008");
            TestPatientSearch("C1719");
        }

        [TestMethod]
        public void TestPatientSearch_PartialLast()
        {
            TestPatientSearch("R");
        }

        [TestMethod]
        public void TestPatientSearch_FullName()
        {
            //TestPatientSearch("CPRSPATIENT,FO");
            TestPatientSearch("CPRSPATIENT,TWO F");
            TestPatientSearch("CPRSPATIENT,TWO ");
            TestPatientSearch("CPRSPATIENT,EIGHT");
            TestPatientSearch("CPRSPATIENT,EIGHT ");
            TestPatientSearch("CPRSPATIENT,EIGHT F");
            TestPatientSearch(" CPRSPATIENT,EIGHT");
        }

        [TestMethod]
        public void TestPatientSearch_NoParams()
        {
            TestPatientSearch("");
        }

        private void TestPatientSearch(string searchParam)
        {
            using (RpcBroker broker = GetConnectedBroker())
            {
                this.SignonToBroker(broker, 0);

                //DsioPatientSearchCommand patSearchCommand = new DsioPatientSearchCommand(broker);
                DsioFemalePatientSearchCommand command = new DsioFemalePatientSearchCommand(broker); 
                                
                //patSearchCommand.AddCommandArguments(searchParam);
                command.AddCommandArguments(searchParam, 1, 10); 

                RpcResponse response = command.Execute();

                Assert.AreEqual(RpcResponseStatus.Success, response.Status);

                broker.Disconnect();
            }
        }

        [TestMethod]
        public void TestGetTracking()
        {
            using (RpcBroker broker = GetConnectedBroker())
            {
                this.SignonToBroker(broker, 0);

                DsioGetTrackingCommand command = new DsioGetTrackingCommand(broker);

                RpcResponse response = command.Execute();

                Assert.AreEqual(RpcResponseStatus.Success, response.Status);
                Assert.IsNotNull(command.TrackingItems);

                if (command.TrackingItems.Count > 0)
                {
                    foreach (DsioTrackingItem item in command.TrackingItems)
                    {
                        Assert.IsFalse(string.IsNullOrWhiteSpace(item.Id));
                        Assert.IsFalse(string.IsNullOrWhiteSpace(item.Dfn));
                        Assert.IsFalse(string.IsNullOrWhiteSpace(item.PatientName));
                        //Assert.IsFalse(string.IsNullOrWhiteSpace(item.Reason));
                        Assert.IsFalse(string.IsNullOrWhiteSpace(item.Source));
                        Assert.IsFalse(string.IsNullOrWhiteSpace(item.TrackingItemDateTime));
                        Assert.IsFalse(string.IsNullOrWhiteSpace(item.TrackingType));
                        Assert.IsFalse(string.IsNullOrWhiteSpace(item.User));
                    }
                }
                broker.Disconnect(); 

            }

        }

        [TestMethod]
        public void TestGetTracking_Paged()
        {
            using (RpcBroker broker = GetConnectedBroker())
            {
                this.SignonToBroker(broker, 0);

                DsioGetTrackingCommand command = new DsioGetTrackingCommand(broker);

                //command.AddGetAllPageParameters("3131210.143031", 3);
                command.AddGetAllPageParameters(2,5);

                RpcResponse response = command.Execute();

                Assert.AreEqual(RpcResponseStatus.Success, response.Status);
                Assert.IsNotNull(command.TrackingItems);

                if (command.TrackingItems.Count > 0)
                {
                    foreach (DsioTrackingItem item in command.TrackingItems)
                    {
                        Assert.IsFalse(string.IsNullOrWhiteSpace(item.Id));
                        Assert.IsFalse(string.IsNullOrWhiteSpace(item.Dfn));
                        Assert.IsFalse(string.IsNullOrWhiteSpace(item.PatientName));
                        //Assert.IsFalse(string.IsNullOrWhiteSpace(item.Reason));
                        Assert.IsFalse(string.IsNullOrWhiteSpace(item.Source));
                        Assert.IsFalse(string.IsNullOrWhiteSpace(item.TrackingItemDateTime));
                        Assert.IsFalse(string.IsNullOrWhiteSpace(item.TrackingType));
                        Assert.IsFalse(string.IsNullOrWhiteSpace(item.User));
                    }
                }
                broker.Disconnect();

            }

        }
        [TestMethod]
        public void TestGetTracking_FlaggedPatients()
        {
            using (RpcBroker broker = GetConnectedBroker())
            {
                this.SignonToBroker(broker, 0);

                DsioGetTrackingCommand command = new DsioGetTrackingCommand(broker);

                command.AddGetFlaggedPatientsParameters(1,1000); 

                RpcResponse response = command.Execute();

                Assert.AreEqual(RpcResponseStatus.Success, response.Status); 
                Assert.IsNotNull(command.FlaggedPatientResult);
                
                broker.Disconnect();
            }
        }

        [TestMethod]
        public void TestGetTracking_TrackedPatients()
        {
            using (RpcBroker broker = GetConnectedBroker())
            {
                this.SignonToBroker(broker, 0);

                DsioGetTrackingCommand command = new DsioGetTrackingCommand(broker);

                command.AddGetTrackedPatientsParameters(1,100);

                RpcResponse response = command.Execute();

                Assert.AreEqual(RpcResponseStatus.Success, response.Status);
                Assert.IsNotNull(command.TrackedPatients);

                broker.Disconnect();
            }
        }

        [TestMethod]
        public void TestGetTracking_PatientFlags()
        {
            using (RpcBroker broker = GetConnectedBroker())
            {
                this.SignonToBroker(broker, 0);

                DsioGetTrackingCommand command = new DsioGetTrackingCommand(broker);

                command.AddPatientFlagsParameter("8", 1, 3);

                RpcResponse response = command.Execute();

                Assert.AreEqual(RpcResponseStatus.Success, response.Status);
                Assert.IsNotNull(command.TrackingItems);
                
                broker.Disconnect(); 
            }
        }

        [TestMethod]
        public void TestTrackingRecord()
        {
            using (RpcBroker broker = GetConnectedBroker())
            {
                this.SignonToBroker(broker, 0);

                DsioCreateTrackingLogCommand command = new DsioCreateTrackingLogCommand(broker);

                string dfn = "26";
                string eventType = "2";
                string reason = "Pregnant";
                string[] comment = null;

                command.AddCommandArguments(dfn, eventType, reason, comment); 

                RpcResponse response = command.Execute();

                Assert.AreEqual(RpcResponseStatus.Success, response.Status);

                broker.Disconnect();
            }
        }

        [TestMethod]
        public void TestGetSelectList()
        {
            using (RpcBroker broker = GetConnectedBroker())
            {
                this.SignonToBroker(broker, 0);

                DsioSelectListCommand command = new DsioSelectListCommand(broker);

                command.AddCommandArguments("R");

                RpcResponse response = command.Execute();

                Assert.AreEqual(RpcResponseStatus.Success, response.Status);

                broker.Disconnect();
            }
        }

        [TestMethod]
        public void TestAddItemToSelectList()
        {
            using (RpcBroker broker = GetConnectedBroker())
            {
                this.SignonToBroker(broker, 0);

                DsioSelectListCommand command = new DsioSelectListCommand(broker);

                command.AddCommandArguments("R", "Lactation", DsioSelectListCommand.SelectListOperation.Add);

                RpcResponse response = command.Execute();

                Assert.AreEqual(RpcResponseStatus.Success, response.Status);

                broker.Disconnect();
            }

        }

        [TestMethod]
        public void TestDeleteItemFromSelectList()
        {
            using (RpcBroker broker = GetConnectedBroker())
            {
                this.SignonToBroker(broker, 0);

                DsioSelectListCommand command = new DsioSelectListCommand(broker);

                command.AddCommandArguments("R", "Bogus Reason", DsioSelectListCommand.SelectListOperation.Delete);

                RpcResponse response = command.Execute();

                Assert.AreEqual(RpcResponseStatus.Success, response.Status);

                broker.Disconnect();
            }

        }

        [TestMethod]
        public void TestPatientSearch2()
        {
            using (RpcBroker broker = GetConnectedBroker())
            {
                this.SignonToBroker(broker, 2);

                DsioFemalePatientSearchCommand command = new DsioFemalePatientSearchCommand(broker);

                command.AddCommandArguments("J", 1, 10);

                RpcResponse response = command.Execute();

                Assert.AreEqual(RpcResponseStatus.Success, response.Status);

                broker.Disconnect(); 
            }
        }

        [TestMethod]
        public void TestPatientFind()
        {
            using (RpcBroker broker = GetConnectedBroker())
            {
                this.SignonToBroker(broker, 2);

                //DsioFemalePatientSearchCommand command = new DsioFemalePatientSearchCommand(broker);
                DsioFemalePatientFindCommand command = new DsioFemalePatientFindCommand(broker); 

                command.AddCommandArguments("J1111");

                RpcResponse response = command.Execute();

                Assert.AreEqual(RpcResponseStatus.Success, response.Status);

                broker.Disconnect();
            }
        }

        [TestMethod]
        public void TestSaveNonVAItem()
        {
            using (RpcBroker broker = GetConnectedBroker())
            {
                this.SignonToBroker(broker, 2);

                DsioSaveNonVAEntityCommand command = new DsioSaveNonVAEntityCommand(broker);

                DsioNonVAItem nonVAEntity = new DsioNonVAItem();

                nonVAEntity.EntityName = "Test Facility AA";
                nonVAEntity.EntityType = "F";
                nonVAEntity.AddressLine1 = "789 Test Street";
                nonVAEntity.AddressLine2 = "Suite XFD";
                nonVAEntity.City = "Sacramento";
                nonVAEntity.State = "XA";
                nonVAEntity.Zip = "93939";
                nonVAEntity.PhoneNumber = "(899) 999-0000";
                nonVAEntity.FaxNumber = "(899) 999-0000";

                command.AddCommandArguments(nonVAEntity);

                RpcResponse response = command.Execute();

                Assert.AreEqual(RpcResponseStatus.Success, response.Status); 
            }
        }

        [TestMethod]
        public void TestGetNonVAItems()
        {
            using (RpcBroker broker = GetConnectedBroker())
            {
                this.SignonToBroker(broker, 2);

                DsioReturnEntityCommand command = new DsioReturnEntityCommand(broker);

                command.AddCommandArguments("F", 1, 5);

                RpcResponse response = command.Execute();

                Assert.AreEqual(RpcResponseStatus.Success, response.Status);
            }
        }

        [TestMethod]
        public void TestCreateANote()
        {
            using (RpcBroker broker = GetConnectedBroker())
            {
                this.SignonToBroker(broker, 2);

                DsioCreateANoteCommand command = new DsioCreateANoteCommand(broker);

                command.AddCommandArguments("740", "MCC DASHBOARD NOTE", "Note text for Friday", "lkfjsldkfjsldjwoeijfwoeij");

                RpcResponse response = command.Execute();

                Assert.AreEqual(RpcResponseStatus.Success, response.Status);
            }
        }

        [TestMethod]
        public void TestGetDashboardNotes()
        {
            using (RpcBroker broker = GetConnectedBroker())
            {
                this.SignonToBroker(broker, 2);

                DsioNotesByDfnAndTitleCommand command = new DsioNotesByDfnAndTitleCommand(broker);

                command.AddCommandArguments("740", "MCC DASHBOARD NOTE", 1, 5);

                RpcResponse response = command.Execute();

                Assert.AreEqual(RpcResponseStatus.Success, response.Status);
            }
        }

        [TestMethod]
        public void TestUpdateANote()
        {
            using (RpcBroker broker = GetConnectedBroker())
            {
                this.SignonToBroker(broker, 2);

                DsioCreateANoteCommand commandCreate = new DsioCreateANoteCommand(broker);

                commandCreate.AddCommandArguments("740", "MCC DASHBOARD NOTE", "Note text for Friday", "lkfjsldkfjsldjwoeijfwoeij");

                RpcResponse response = commandCreate.Execute();

                Assert.AreEqual(RpcResponseStatus.Success, response.Status);

                DsioUpdateANoteCommand command = new DsioUpdateANoteCommand(broker);

                command.AddCommandArguments(commandCreate.Ien, "This is UPDATED Saturday", "");

                response = command.Execute();

                Assert.AreEqual(RpcResponseStatus.Success, response.Status);
            }
        }

        [TestMethod]
        public void TestGetProgressNoteText()
        {
            using (RpcBroker broker = GetConnectedBroker())
            {
                this.SignonToBroker(broker, 2);

                DsioGetRecordTextCommand command = new DsioGetRecordTextCommand(broker);

                //command.AddParameter("461");
                command.AddCommandArgument("4853");

                RpcResponse response = command.Execute();

                Assert.AreEqual(RpcResponseStatus.Success, response.Status);

                broker.Disconnect();
            }
        }

        [TestMethod]
        public void TestSignNote()
        {
            using (RpcBroker broker = GetConnectedBroker())
            {
                this.SignonToBroker(broker, 2);

                DsioCreateANoteCommand commandCreate = new DsioCreateANoteCommand(broker);

                commandCreate.AddCommandArguments("740", "MCC DASHBOARD NOTE", "Note text for Friday", "lkfjsldkfjsldjwoeijfwoeij");

                RpcResponse response = commandCreate.Execute();

                Assert.AreEqual(RpcResponseStatus.Success, response.Status);

                DsioSignANoteCommand command = new DsioSignANoteCommand(broker);

                command.AddCommandArguments(commandCreate.Ien, "DSS1234");

                response = command.Execute();

                Assert.AreEqual(RpcResponseStatus.Success, response.Status);

                broker.Disconnect();
            }
        }

        [TestMethod]
        public void TestCreateAddendum()
        {
            using (RpcBroker broker = GetConnectedBroker())
            {
                this.SignonToBroker(broker, 2);

                DsioCreateANoteCommand commandCreate = new DsioCreateANoteCommand(broker);

                commandCreate.AddCommandArguments("740", "MCC DASHBOARD NOTE", "Note text for Friday", "lkfjsldkfjsldjwoeijfwoeij");

                RpcResponse response = commandCreate.Execute();

                Assert.AreEqual(RpcResponseStatus.Success, response.Status);

                DsioMakeAddendumCommand command = new DsioMakeAddendumCommand(broker);

                command.AddCommandArguments(commandCreate.Ien, "This is an addendum for Saturday", "");

                response = command.Execute();

                Assert.AreEqual(RpcResponseStatus.Success, response.Status);
            }
        }

        [TestMethod]
        public void TestDeleteNote()
        {
            using (RpcBroker broker = GetConnectedBroker())
            {
                this.SignonToBroker(broker, 2);

                DsioCreateANoteCommand commandCreate = new DsioCreateANoteCommand(broker);

                commandCreate.AddCommandArguments("740", "MCC DASHBOARD NOTE", "Note text for Friday", "lkfjsldkfjsldjwoeijfwoeij");

                RpcResponse response = commandCreate.Execute();

                Assert.AreEqual(RpcResponseStatus.Success, response.Status);

                DsioDeleteANoteCommand command = new DsioDeleteANoteCommand(broker);

                command.AddCommandArguments(commandCreate.Ien, "This note was added to the wrong patient");

                response = command.Execute();

                Assert.AreEqual(RpcResponseStatus.Success, response.Status);
            }
        }
    }
}
