﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VA.Gov.Artemis.UI.Data.Brokers.Results;
using VA.Gov.Artemis.UI.Data.Models;
using VA.Gov.Artemis.UI.Data.Models.Aggregated;

namespace VA.Gov.Artemis.UI.Data.Brokers
{
    public interface IPatientRepository
    {
        PatientSearchResult Search(string searchParam, int page, int itemsPerPage);

        FlaggedPatientsResult GetFlaggedPatients(int page, int itemsPerPage);

        PatientDemographicsResult GetPatientDemographics(string dfn);

        TrackedPatientsResult GetTrackedPatients(int page, int itemsPerPage);

        PatientSummaryResult GetPatientSummary(string dfn);

        PatientSearchResult ProgressiveSearch(string lastName, string firstName, int page, int itemsPerPage);
    }
}
