﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VA.Gov.Artemis.UI.Data.Models.Patient
{
    public class Problem
    {
        public string ProblemId { get; set; }
        public string Description { get; set; }
        public string DxCode { get; set; }
        public DateTime ProblemDateTime { get; set; }
    }
}
