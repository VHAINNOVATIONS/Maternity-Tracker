﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VA.Gov.Artemis.UI.Data.Models.Patient
{
    public class CurrentPregnancy
    {
        public bool Pregnant { get; set; }
        public DateTime EDD { get; set; }
        public int FetusCount { get; set; }

        public string GestationalAge
        {
            get
            {
                string returnVal = "";

                int ga = this.GestationalAgeInDays; 

                int wholeWeeks = (int)ga / 7; 
                int remainderDays = ga % 7;

                returnVal = string.Format("{0} weeks {1} days", wholeWeeks, remainderDays); 
 
                return returnVal;
            }
        }

        private int GestationalAgeInDays
        {
            get
            {
                int returnVal = -1;

                // *** Count number of days until EDD ***
                TimeSpan difference = this.EDD.Subtract(DateTime.Now);
                int daysUntilEdd = (int)difference.TotalDays;

                // *** 40 Weeks * 7 days/week = total pregnancy days - days left ***
                returnVal = 40 * 7 - daysUntilEdd; 

                return returnVal;
            }
        }

        public int Trimester
        {
            get
            {
                int returnVal = -1;

                int ga = this.GestationalAgeInDays; 

                if (ga <= 14 * 7)
                    returnVal = 1;
                else if (ga <= 28 * 7)
                    returnVal = 2;
                else
                    returnVal = 3; 

                return returnVal;
            }
        }

        public string Multiple
        {
            get
            {
                string returnVal = "No";

                if (this.FetusCount > 1)
                    returnVal = string.Format("Yes ({0})", this.FetusCount); 

                return returnVal;
            }
        }
    }
}
