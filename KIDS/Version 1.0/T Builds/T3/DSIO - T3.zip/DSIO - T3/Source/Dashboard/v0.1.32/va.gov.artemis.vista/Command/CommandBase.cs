﻿using VA.Gov.Artemis.Vista.Broker;
using VA.Gov.Artemis.Vista.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace VA.Gov.Artemis.Vista.Commands
{
    public abstract class CommandBase
    {
        protected const string Caret = "^"; 

        protected IRpcBroker broker { get; set; }
        protected object[] CommandArgs { get; set; }
        protected string Context { get; set; }

        public RpcResponse Response { get; set; }

        public abstract string RpcName { get; }
        public abstract string Version { get; }        

        public CommandBase(IRpcBroker newBroker)
        {
            this.broker = newBroker;

            this.Context = string.Empty; 
        }

        public virtual RpcResponse Execute()
        {
            this.Response = this.broker.CallRpc(this.Context, this.RpcName, this.Version, this.CommandArgs);

            if (this.Response.Status != RpcResponseStatus.Fail)
                this.ProcessResponse();

            return this.Response;
        }

        protected abstract void ProcessResponse();

        public string GetXmlDescription()
        {
            StringBuilder sb = new StringBuilder();
            
            XmlWriterSettings settings = new XmlWriterSettings() { Indent = true, OmitXmlDeclaration=true };

            using (XmlWriter writer = XmlTextWriter.Create(sb, settings))
            {
                writer.WriteStartElement("CommandBase");

                writer.WriteElementString("RpcName", this.RpcName);
                writer.WriteElementString("Version", this.Version);
                //if (this.request != null)
                //{
                    writer.WriteStartElement("Request");

                    writer.WriteElementString("Context", this.Context);

                    if (this.CommandArgs == null)
                        writer.WriteElementString("Args", "");
                    else if (this.CommandArgs.Length == 0)
                        writer.WriteElementString("Args", "");
                    else
                    {
                        writer.WriteStartElement("Args");
                        for (int i = 0; i < this.CommandArgs.Length; i++)
                        {
                            string elName = string.Format("Args{0}", i);

                            writer.WriteElementString(elName, this.CommandArgs[i].ToString());
                        }
                        writer.WriteEndElement();
                    }
                //}

                writer.WriteEndElement();

                writer.WriteEndElement();
            }
            return sb.ToString();
        }

    }
}
