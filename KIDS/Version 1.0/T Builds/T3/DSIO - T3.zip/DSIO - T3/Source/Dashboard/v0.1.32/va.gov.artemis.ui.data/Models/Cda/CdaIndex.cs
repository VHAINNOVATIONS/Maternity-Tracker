﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VA.Gov.Artemis.UI.Data.Models.Cda
{
    public class CdaIndex  
    {
        public BasePatient Patient { get; set; }
        
        public List<CdaDocumentData> DocumentList { get; set; }

        public Paging Paging { get; set; }

        public CdaIndex()
        {
            this.Paging = new Paging(); 
        }
    }
}
