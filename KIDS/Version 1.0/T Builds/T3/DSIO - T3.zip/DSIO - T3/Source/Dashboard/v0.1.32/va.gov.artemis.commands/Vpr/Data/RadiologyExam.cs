﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VA.Gov.Artemis.Commands.Vpr.Data
{
    [Serializable]
    public class RadiologyExam: ClinicalItem
    {
        // TODO: From docs...

        // case
        // category
        // dateTime
        // document
        // encounter
        // hasImages
        // imagingType
        // interpretation
        // modifier
        // order
        // provider
        // status
        // type
    }
}
