﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VA.Gov.Artemis.Vista.Broker;
using VA.Gov.Artemis.Vista.Commands;
using VA.Gov.Artemis.Vista.Utility;

namespace VA.Gov.Artemis.Commands.Orwpt
{
    public class OrwptListAllCommand: CommandBase
    {
        public OrwptListAllCommand(IRpcBroker broker ): base(broker)
        {
            this.CommandArgs = new object[] 
            {
                "",
                "1"
            };
        }

        public List<OrwptListPatient> PatientList { get; set; }

        public override string RpcName { get { return "ORWPT LIST ALL"; } }

        public override string Version { get { return "0"; } }
    
        protected override void ProcessResponse()
        {
            this.Response.Status = RpcResponseStatus.Success;
            this.PatientList = new List<OrwptListPatient>();

            if (!string.IsNullOrWhiteSpace(this.Response.Data))
            {
                foreach (string line in this.Response.Lines)
                {
                    string duz = Util.Piece(line, "^", 1);
                    string name = Util.Piece(line, "^", 2);

                    OrwptListPatient pat = new OrwptListPatient()
                    {
                        Dfn = duz,
                        LastFirst = name
                    };

                    this.PatientList.Add(pat);
                }
            }
        
        }
    }
}