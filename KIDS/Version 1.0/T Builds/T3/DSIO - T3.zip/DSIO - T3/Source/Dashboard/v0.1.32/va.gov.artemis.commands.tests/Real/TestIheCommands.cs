﻿using System;
using System.Text;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using VA.Gov.Artemis.Commands.tests.real;
using VA.Gov.Artemis.Vista.Broker;
using VA.Gov.Artemis.Commands.Dsio;
using System.IO;

namespace va.gov.artemis.Commands.tests.Real
{
    /// <summary>
    /// Summary description for TestIheCommands
    /// </summary>
    [TestClass]
    public class TestIheCommands: TestCommandsBase
    {
        public TestIheCommands()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class
        // [ClassInitialize()]
        // public static void MyClassInitialize(TestContext testContext) { }
        //
        // Use ClassCleanup to run code after all tests in a class have run
        // [ClassCleanup()]
        // public static void MyClassCleanup() { }
        //
        // Use TestInitialize to run code before running each test 
        // [TestInitialize()]
        // public void MyTestInitialize() { }
        //
        // Use TestCleanup to run code after each test has run
        // [TestCleanup()]
        // public void MyTestCleanup() { }
        //
        #endregion

        [TestMethod]
        public void TestSaveIHE()
        {
            using (RpcBroker broker = this.GetConnectedBroker())
            {
                this.SignonToBroker(broker, 2);

                DsioIheSaveCommand command = new DsioIheSaveCommand(broker);

                // TODO: Get content somewhere else...
                string content = File.ReadAllText(@"Z:\VMShared\Source\TestCCD\test_aphp_header.xml");

                command.AddCommandArguments(Guid.NewGuid().ToString(), "715", "OUT", DateTime.Now.ToString(), DateTime.Now.ToString(), "APS", "This is a Test Title", "VA", "Outside Clinic", content);

                RpcResponse response = command.Execute();

                Assert.IsNotNull(response);
                Assert.AreEqual(RpcResponseStatus.Success, response.Status); 

            }
        }

        [TestMethod]
        public void TestPatientList()
        {
            using (RpcBroker broker = this.GetConnectedBroker())
            {
                this.SignonToBroker(broker, 2);

                DsioIhePatientListCommand command = new DsioIhePatientListCommand(broker);

                command.AddCommandArguments("715", 1, 100);

                RpcResponse response = command.Execute();

                Assert.IsNotNull(response);
                Assert.AreEqual(RpcResponseStatus.Success, response.Status); 
            }
        }
    }
}
