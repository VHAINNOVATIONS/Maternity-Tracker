﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VA.Gov.Artemis.Commands.Orqqpl
{
    public class OrqqplProblem
    {
        public string Problem{ get; set; }
        public string DxCode { get; set; }
        public string ProblemDateTime { get; set; }
    }
}
