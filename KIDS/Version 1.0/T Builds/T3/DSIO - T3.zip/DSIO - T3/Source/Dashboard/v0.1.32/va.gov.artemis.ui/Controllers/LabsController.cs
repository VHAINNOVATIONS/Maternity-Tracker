﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using VA.Gov.Artemis.UI.Data.Brokers.Results;
using VA.Gov.Artemis.UI.Data.Models;
using VA.Gov.Artemis.UI.Data.Models.Patient;
using VA.Gov.Artemis.UI.Filters;

namespace VA.Gov.Artemis.UI.Controllers
{
    [VerifySession]
    [DisableLocalCache]
    [Authorize]
    public class LabsController : DashboardController
    {

        [HttpGet]
        public ActionResult Index(string dfn)
        {
            LabsIndex model = new LabsIndex();

            // *** Get patient demographics ***
            model.Patient = this.CurrentPatient;

            // *** Check for success ***
            if (!model.Patient.NotFound)
            {                
                model.Labs.Add(new LabTest("Blood Type", LabTestTiming.Initial, DateTime.Now, "RDD", "AB"));
                model.Labs.Add(new LabTest("Rh Type", LabTestTiming.Initial, DateTime.Now, "RDD", "Negative"));
                model.Labs.Add(new LabTest("Ab Screen", LabTestTiming.Initial, DateTime.Now, "RDD", "Positive"));
                model.Labs.Add(new LabTest("HIV", LabTestTiming.Initial, DateTime.Now, "RDD", "Negative"));
                model.Labs.Add(new LabTest("HepBsAg", LabTestTiming.Initial, DateTime.Now, "RDD", "Negative"));
                model.Labs.Add(new LabTest("RPR", LabTestTiming.Initial, DateTime.Now, "RDD", "Non-Reactive"));
                model.Labs.Add(new LabTest("Rubella", LabTestTiming.Initial, DateTime.Now, "RDD", "Non-Imm"));
                model.Labs.Add(new LabTest("Varicella", LabTestTiming.Initial, DateTime.Now, "RDD", "Non-Imm"));
                model.Labs.Add(new LabTest("Pap*", LabTestTiming.Initial, DateTime.Now, "RDD", "Wnl"));
                model.Labs.Add(new LabTest("Urine Cx", LabTestTiming.Initial, DateTime.Now, "RDD", "Negative"));
                model.Labs.Add(new LabTest("GC", LabTestTiming.Initial, DateTime.Now, "RDD", "Negative"));
                model.Labs.Add(new LabTest("CT", LabTestTiming.Initial, DateTime.Now, "RDD", "Positive"));
                model.Labs.Add(new LabTest("HCT", LabTestTiming.Initial, DateTime.MinValue, "", ""));
                model.Labs.Add(new LabTest("PLT", LabTestTiming.Initial, DateTime.MinValue, "", ""));
                model.Labs.Add(new LabTest("GTT(early)*", LabTestTiming.Initial, DateTime.MinValue, "", ""));

                model.Labs.Add(new LabTest("GTT", LabTestTiming.Week28, DateTime.Now, "", ""));
                model.Labs.Add(new LabTest("3 hr GTT*", LabTestTiming.Week28, DateTime.Now, "", ""));
                model.Labs.Add(new LabTest("HCT", LabTestTiming.Week28, DateTime.Now, "", ""));
                model.Labs.Add(new LabTest("PLT", LabTestTiming.Week28, DateTime.Now, "", ""));

                model.Labs.Add(new LabTest("GBX", LabTestTiming.Week36, DateTime.Now, "", ""));

            }

            return View(model);
        }

    }
}
