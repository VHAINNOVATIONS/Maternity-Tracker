﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VA.Gov.Artemis.UI.Data.Models.Aggregated.Common;

namespace VA.Gov.Artemis.UI.Data.Models.Aggregated.TrackedEvents
{
    // *** Includes recording info for Text4Baby Enrollment ***

    public class ProgramEnrollmentEvent: TrackedEvent
    {
        public override string EventName
        {
            get { return "Program Enrollment"; }
        }

        public override string Details
        {
            get { throw new NotImplementedException(); }
        }

        public override TrackedEventType EventType
        {
            get { throw new NotImplementedException(); }
        }
    }
}
