﻿//using VA.Gov.Artemis.UI.Data.Models.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using VA.Gov.Artemis.UI.Data.Models.Aggregated.Common;

namespace VA.Gov.Artemis.UI.Data.Models.Aggregated.TrackedEvents
{
public class ClinicalReminderEvent : TrackedEvent
    {
        public string ReminderId { get; set; }
        //public string Status { get; set; }
        public DateTime LastDone { get; set; }
        public string ReminderText { get; set; }

        public override string EventName
        {
            get { return "Clinical Reminder"; }
        }

        public override string Details
        {
            get { return this.ReminderText; }
        }

        public override TrackedEventType EventType
        {
            get { return TrackedEventType.ClinicalReminder; }
        }
    }
}