﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using va.gov.artemis.vista.Broker;
//using va.gov.artemis.vista.commands;
//using va.gov.artemis.vista.Utility;

//namespace va.gov.artemis.commands.vfdwv
//{
//    // NOTES ON POSSIBLE COMMAND CHANGES

//    // 1. Separate last and first name
//    // 2. Use last 4 instead of full SSN
//    // 3. Determine case sensitivity rules for search
//    // 4. Allow partial name searches
//    // 5. Include other data... (ServiceConnected, Veteran Status, Location, RoomBd
//    // 6. Merge to single list, use just for retrieving from patient file
//    // 7. Pass in max records to receive?
//    // 8. Don't need count if using max records.

//    public class VfdwvPatientListCommand: CommandBase 
//    {
//        public VfdwvPatientListCommand(IRpcBroker newBroker, string lastName): base(newBroker) 
//        {
//            this.CommandArgs = new object[] { lastName };

//            this.Context = "VFDWV GUI CONTEXT"; 
//        }
        
//        public override string RpcName { get{return "VFDWV PATIENT LIST";}}

//        public override string Version { get {return "0";}}

//        public VfdwvPatListData ReturnData { get; set; }

//        protected override void ProcessResponse() 
//        {
//            this.ReturnData = new VfdwvPatListData();

//            if (string.IsNullOrWhiteSpace(this.Response.Data))
//                this.Response.Status = RpcResponseStatus.Fail;
//            else
//            {
//                bool patFilePatient = false; 

//                foreach (string line in this.Response.Lines)
//                {
//                    string piece1 = Util.Piece(line, Caret, 1);
//                    string piece2 = Util.Piece(line, Caret, 2);
//                    int count = 0; 

//                    if (piece1 == "DASHBOARD")
//                    {
//                        int.TryParse(piece2, out count);

//                        this.ReturnData.DashboardCount = count; 
//                    }
//                    else if (piece1 == "PATIENT FILE")
//                    {
//                        int.TryParse(piece2, out count);

//                        this.ReturnData.PatFileCount = count;

//                        patFilePatient = true; 
//                    }
//                    else
//                    {
//                        VfdwvPatient pat = new VfdwvPatient()
//                        {
//                            Dfn = piece1,
//                            PatientName = piece2,
//                            Ssn = Util.Piece(line, Caret, 3),
//                            DateOfBirth = Util.Piece(line, Caret, 4),
//                            CurrentlyTracking = Util.Piece(line, Caret, 5)
//                        };

//                        if (patFilePatient)
//                            this.ReturnData.PatientFilePatients.Add(pat);
//                        else
//                            this.ReturnData.DashboardPatients.Add(pat);
//                        }
//                }
//            }

//        }
//    }

//    public class VfdwvPatListData
//    {
//        public int DashboardCount { get; set; }
//        public int PatFileCount { get; set; }

//        public List<VfdwvPatient> DashboardPatients { get; set; }
//        public List<VfdwvPatient> PatientFilePatients { get; set; }

//        public VfdwvPatListData()
//        {
//            this.DashboardPatients = new List<VfdwvPatient>();
//            this.PatientFilePatients = new List<VfdwvPatient>(); 
//        }
//    }

//    public class VfdwvPatient
//    {
//        // TODO: Convert to proper data types here?

//        public string Dfn { get; set; }
//        public string PatientName { get; set; }
//        public string Ssn { get; set; }
//        public string DateOfBirth { get; set; }
//        public string CurrentlyTracking { get; set; }
//    }
//}
