﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Serialization;

namespace VA.Gov.Artemis.Cda
{

    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlRootAttribute("ClinicalDocument", Namespace = "urn:hl7-org:v3", IsNullable = false)]
    public partial class IheDocument : CdaDocument
    {
        [XmlAttributeAttribute("schemaLocation", AttributeName = "schemaLocation", Namespace = "http://www.w3.org/2001/XMLSchema-instance")]
        public string SchemaLocation = "urn:hl7-org:v3 infrstructure/cda/CDA.xsd";

        public IheDocument()
            : base()
        {
        }
    }
}