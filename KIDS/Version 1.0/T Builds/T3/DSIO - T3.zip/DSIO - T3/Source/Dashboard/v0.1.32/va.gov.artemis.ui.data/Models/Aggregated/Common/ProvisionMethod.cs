﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace VA.Gov.Artemis.UI.Data.Models.Aggregated.Common
{
    public enum ProvisionMethod { Printed, Email, Link, MyHealtheVet, Other }
}