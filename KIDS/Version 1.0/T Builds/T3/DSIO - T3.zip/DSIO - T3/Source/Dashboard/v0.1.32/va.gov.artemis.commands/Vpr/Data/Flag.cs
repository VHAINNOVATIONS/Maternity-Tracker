﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VA.Gov.Artemis.Commands.Vpr.Data
{
    [Serializable]
    public class Flag: ClinicalItem
    {
        // TODO: Implement...
        // approvedBy
        // assigned
        // category
        // content
        // document
        // origSite
        // ownSite
        // reviewDue
        // type
    }
}
