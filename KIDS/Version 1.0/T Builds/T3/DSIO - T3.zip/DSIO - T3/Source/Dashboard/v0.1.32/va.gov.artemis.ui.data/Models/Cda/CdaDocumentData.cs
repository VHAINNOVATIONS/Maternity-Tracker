﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VA.Gov.Artemis.UI.Data.Models.Cda
{
    public class CdaDocumentData
    {
        public string Ien { get; set; } // Internal to VistA
        public string Id { get; set; } // GUID for exchange
        public string PatientDfn { get; set; }
        public ExchangeDirection ExchangeDirection { get; set; }
        public DateTime CreationDateTime { get; set; }
        public DateTime ImportDateTime { get; set; }
        public IheDocumentType DocumentType { get; set; }
        public string Title { get; set; }
        public string IntendedRecipient { get; set; }
        public string Sender { get; set; }
        public string DocumentContent { get; set; }

    }
}
