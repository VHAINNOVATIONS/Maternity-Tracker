﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VA.Gov.Artemis.Cda
{
    class Header
    {
        static string Generate()
        {
            string returnVal = "";

            POCD_MT000040ClinicalDocument newCcd = new POCD_MT000040ClinicalDocument();

            POCD_MT000040RecordTarget recordTarget = new POCD_MT000040RecordTarget();

            POCD_MT000040PatientRole patientRole = new POCD_MT000040PatientRole();

            POCD_MT000040Patient patient = new POCD_MT000040Patient();

            return returnVal;
        }
    }
}