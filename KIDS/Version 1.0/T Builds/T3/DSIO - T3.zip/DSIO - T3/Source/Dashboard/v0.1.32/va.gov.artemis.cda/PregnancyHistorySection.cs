﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;


// Possible methods of generating documents

// 1. String builder for each line + string.Format
// 2. XmlBuilder to build nodes one at a time
// 3. XmlSerialization of document objects
// 4. Use intermediate xml then transform into final using xslt

namespace VA.Gov.Artemis.Cda
{
            //    <!-- Pregnancy History -->
            //<component>
            //    <section>
            //        <templateId root="1.3.6.1.4.1.19376.1.5.3.1.1.5.3.4"/>
            //        <code code="10162-6" displayName="HISTORY OF PREGNANCIES"
            //            codeSystem="2.16.840.1.113883.6.1" codeSystemName="LOINC"/>
            //        <text>History of pregnancy</text>

            //        <entry>

            //            <!-- Required Pregnancy Observation  element -->
            //            <observation classCode="OBS" moodCode="EVN">
            //                <templateId root="1.3.6.1.4.1.19376.1.5.3.1.4.13"/>
            //                <templateId root="1.3.6.1.4.1.19376.1.5.3.1.4.13.5"/>
            //                <id root="pregid" extension=" "/>
            //                <code code="11449-6" displayName=" " codeSystem="2.16.840.1.113883.6.1"
            //                    codeSystemName="LOINC"/>
            //                <text>
            //                    <reference value="#xxx"/>
            //                </text>
            //                <statusCode code="completed"/>
            //                <effectiveTime value="20071010"/>
            //                <value xsi:type="CE"/>
            //            </observation>

            //        </entry>

            //    </section>
            //</component>

    public class PregnancyHistorySection
    {
        public List<PregnancyObservation> PregnancyObservations { get; set; }

        public PregnancyHistorySection()
        {
            this.PregnancyObservations = new List<PregnancyObservation>();

            PregnancyObservation obs = new PregnancyObservation()
            {
                Code = "11636-8",
                EffectiveTime = "12/12/14",
                StatusCode = "Completed",
                Value = "4"
            };

            this.PregnancyObservations.Add(obs);
        }
    }

    public class PregnancyObservation
    {
        public string Id { get; set; }
        public string Code { get; set; } // LOINC
        public string StatusCode { get; set; }
        public string EffectiveTime { get; set; }
        public string Value { get; set; }

        public string ToXml()
        {
            string returnVal = "";

            StringBuilder sb = new StringBuilder();

            sb.AppendLine("<observation classCode='OBS' moodCode='EVN'>");
            sb.AppendLine("<templateId root='1.3.6.1.4.1.19736.1.5.3.1.4.13'/>");
            sb.AppendLine("<templateId root='1.3.6.1.4.1.19736.1.5.3.1.4.13.5'/>");

            string temp = string.Format("<id root='{0}' extension='' />", this.Id);
            sb.AppendLine(temp);

            temp = string.Format("<code code='{0}' displayName='' codeSystem='2.16.84.1.113883.6.1' codeSystemName='LOINC'/>", this.Code); 
            sb.AppendLine(temp);

            sb.AppendLine("<text>");
            sb.AppendLine("<reference value='#xxx'/>");
            sb.AppendLine("</text>");
            
            temp = string.Format("<statusCode code='{0}'/>", this.StatusCode);
            sb.AppendLine(temp);
            
            temp = string.Format("<effectiveTime value='{0}'/>", this.EffectiveTime);
            sb.AppendLine(temp); 

            temp = string.Format("<value xsi:type='CE' value='{0}'/>", this.Value);
            sb.AppendLine(temp);

            sb.AppendLine("</observation>"); 

            return returnVal; 
        }
    }

    public class component
    {
        public section section { get; set; }
    }

    public class section
    {
        [XmlElement]
        public templateId templateId { get; set; }

        [XmlElement]
        public code code { get; set; }

        [XmlElement]
        public string text { get; set; }
    }

    public class templateId
    {
        [XmlAttribute]
        public string root { get; set; }
    }

    public class code
    {
        [XmlAttribute( AttributeName="code")]
        public string CodeValue { get; set; }

        [XmlAttribute]
        public string displayName { get; set; }

        [XmlAttribute]
        public string codeSystem { get; set; }

        [XmlAttribute]
        public string codeSystemName { get; set; }
    }

    public class entry
    {
       
    }

    public class observation 
    {
        [XmlAttribute]
        public string classCode {get; set; }

        [XmlAttribute]
        public string moodCode {get; set; }

        [XmlElement]
        public List<templateId> templateIds {get; set; }

        
    }


}
