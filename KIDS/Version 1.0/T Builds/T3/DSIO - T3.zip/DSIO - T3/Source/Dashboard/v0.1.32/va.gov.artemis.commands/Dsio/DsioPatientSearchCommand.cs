﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VA.Gov.Artemis.Commands.Dsio;
using VA.Gov.Artemis.Vista.Broker;
using VA.Gov.Artemis.Vista.Commands;
using VA.Gov.Artemis.Vista.Utility;

namespace VA.Gov.Artemis.Commands.Dsio
{
    // The following was replaced by female patient search command ...

    //public class DsioPatientSearchCommand: DsioCommand 
    //{
    //    public DsioPatientSearchCommand(IRpcBroker newBroker):base(newBroker) {}

    //    public override string RpcName { get { return "DSIO PATIENT SEARCH";}}

    //    public void AddCommandArguments(string searchParam) 
    //    {
    //        this.CommandArgs = new object[] { searchParam };
    //    }

    //    public void AddCommandArguments(string patientName, int direction, int count)
    //    {
    //        string parameterFormat = "#$^{0}^{1}^{2}";

    //        this.CommandArgs = new object[] { string.Format(parameterFormat, patientName, direction, count) };
    //    }

    //    public List<DsioSearchPatient> MatchingPatients { get; set; }

    //    protected override void ProcessResponse()
    //    {
    //        if (!string.IsNullOrWhiteSpace(this.Response.Data))
    //        {
    //            string piece1 = Util.Piece(this.Response.Lines[0], "^", 1);

    //            if (piece1 == "-1")
    //                this.Response.InformationalMessage = "No matching patients found";
    //            else
    //            {
    //                this.MatchingPatients = new List<DsioSearchPatient>(); 

    //                foreach (string line in this.Response.Lines)
    //                {
    //                    string fullName = Util.Piece(line, CommandBase.Caret, 2); 
    //                    string lastName = Util.Piece(fullName, ",",1);
    //                    string firstName = Util.Piece(fullName, ",",2);
                       
    //                    DsioSearchPatient tempPatient = new DsioSearchPatient()
    //                    {
    //                        Dfn = Util.Piece(line, CommandBase.Caret, 1), 
    //                        LastName = lastName, 
    //                        FirstName = firstName,                             
    //                        Last4 = Util.Piece(line, CommandBase.Caret, 3),
    //                        DateOfBirth = Util.Piece(line, CommandBase.Caret, 4),
    //                        Veteran = Util.Piece(line, CommandBase.Caret, 5),
    //                        Location = Util.Piece(line, CommandBase.Caret, 6),
    //                        RoomBed = Util.Piece(line, CommandBase.Caret, 7),
    //                        ServiceConnected = Util.Piece(line, CommandBase.Caret, 8),
    //                        TrackingStatus = Util.Piece(line, CommandBase.Caret, 9)
    //                    };

    //                    this.MatchingPatients.Add(tempPatient);
    //                }
    //            }

    //            this.Response.Status = RpcResponseStatus.Success;
    //        }
    //    }
    //}
}
