﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Mvc;
using System.Xml;
using System.Xml.Serialization;
using System.Xml.XPath;
using System.Xml.Xsl;
using VA.Gov.Artemis.UI.Data.Brokers.Results;
using VA.Gov.Artemis.UI.Data.Models;
using VA.Gov.Artemis.UI.Data.Models.Cda;
using VA.Gov.Artemis.UI.Filters;
using VA.Gov.Artemis.Vista.Broker;

namespace VA.Gov.Artemis.UI.Controllers
{
    [DisableLocalCache]
    [VerifySession]
    [Authorize]
    public class CdaController : DashboardController
    {
        private const string styleSheetFileName = "CDA.xsl";

        // TODO: Deploy security for this folder...?
        private const string outgoingVirtualPath = "~/Content/Cda/";
        private const string outgoingPhysicalPath = "Content\\cda\\"; 
        
        private const string outgoingCdaDocsSessionKey = "OutgoingCdaDocs";

        private const string uploadFileKey = "UploadFile";

        private const int patientMatchesPerPage = 5; 

        // *** Default constructor used by MVC ***
        public CdaController() : base() {}

        [HttpGet]
        public ActionResult Index(string dfn, string page)
        {
            // *** Get patient demographics ***
            CdaIndex model = new CdaIndex();
            model.Patient = this.CurrentPatient;

            // *** Get page requested ***
            int pageNum = this.GetPage(page); 

            // *** Get exchange history data ***
            CdaDocumentListResult result = this.DashboardRepository.CdaDocuments.GetExchangeHistory(dfn, pageNum, DefaultResultsPerPage);

            // *** Check result ***
            if (!result.Success)
            {
                model.DocumentList = new List<CdaDocumentData>();
                if (!string.IsNullOrWhiteSpace(result.Message))
                    this.Error(result.Message);
            }
            else
            {
                // *** Add document list to model ***
                model.DocumentList = result.DocumentList;

                // *** Set paging data ***
                model.Paging.SetPagingData(DefaultResultsPerPage,pageNum, result.TotalResults);
                model.Paging.BaseUrl = Url.Action("Index", new { page = "" });
            }

            return View(model);
        }

        [HttpGet]
        public ActionResult Options(string dfn)
        {
            // *** Get patient demographics ***
            CdaOptions model = new CdaOptions();
            model.Patient = this.CurrentPatient; 

            // *** TODO: Add options data here ***
            
            return View(model);
        }

        [HttpPost]
        public ActionResult Generate(CdaOptions options)
        {
            // *** Generate document based on options selected ***

            this.CurrentPatientDfn = options.Patient.Dfn; 

            // *** Get the patient ***
            CdaDocumentModel model = new CdaDocumentModel();
            model.Patient = this.CurrentPatient;

            // TODO: Add options to CdaOptions...

            CdaDocumentResult result = this.DashboardRepository.CdaDocuments.Generate(options);

            // *** Check result ***
            if (result.Success)
            {
                model.Data = result.DocumentData;

                string firstPart = this.DashboardRepository.CdaDocuments.GetDocumentAbbreviation(result.DocumentData.DocumentType); 

                string fileName = PrepareFile(firstPart, model.Patient.Name, result.DocumentData.DocumentContent);

                if (!string.IsNullOrWhiteSpace(fileName))
                    model.FileName = Url.Content(fileName);
                else
                    this.Error("The document could not be generated");
            }
            else
                this.Error("The document could not be generated");

            return View("PreviewDocument", model);
        }

        [HttpPost]
        public ActionResult Download(CdaDocumentModel model)
        {
            // *** Download the passed in (relative) file name ***

            ActionResult returnResult;

            model.Data.ImportDateTime = DateTime.Now;

            // *** Get full local name ***
            string fullName = this.Request.MapPath(model.FileName);

            model.Data.DocumentContent = System.IO.File.ReadAllText(fullName);

            BrokerOperationResult result = this.DashboardRepository.CdaDocuments.SaveDocument(model.Data); 

            // *** Get the name only ***
            string nameOnly = Path.GetFileName(model.FileName); 

            // *** Return a FileResult ***
            returnResult = File(fullName, "text/xml", nameOnly); 

            return returnResult; 
        }

        [HttpPost]
        public ActionResult Export(CdaDocumentModel model)
        {
            // *** Download the passed in (relative) file name ***

            ActionResult returnResult;

            // *** Get full local name ***
            string fullName = this.Request.MapPath(model.FileName);

            // *** Get the name only ***
            string nameOnly = Path.GetFileName(model.FileName);

            // *** Return a FileResult ***
            returnResult = File(fullName, "text/xml", nameOnly);

            return returnResult; 
        }

        [HttpGet]
        public ActionResult DownloadStyleSheet()
        {
            // *** Download the style sheet ***

            ActionResult returnResult;

            // *** Get full local name ***
            string fullName = this.Request.MapPath(outgoingVirtualPath + styleSheetFileName);

            // *** Return FileResult ***
            returnResult = File(fullName, "text/xml", styleSheetFileName);

            return returnResult;
        }

        [HttpGet]
        public ActionResult DocumentView(string dfn, string ien)
        {
            // *** Show a single document ***

            // *** Get patient demographics ***
            CdaDocumentModel model = new CdaDocumentModel();
            model.Patient = this.CurrentPatient;

            // *** Get the data ***
            CdaDocumentResult result = this.DashboardRepository.CdaDocuments.GetDocumentData(ien);

            // *** Check for success ***
            if (!result.Success)
            {
                model.Data = new CdaDocumentData();
                if (!string.IsNullOrWhiteSpace(result.Message))
                    this.Error(result.Message);
            }
            else
            {
                // *** Add resulting data to model ***
                model.Data = result.DocumentData;

                // *** Create a guid for the file name ***                
                string tempFileName = string.Format("{0}.xml", Guid.NewGuid());

                // *** Combine with path for full name ***
                string fullFileName = Path.Combine(FullOutgoingPath, tempFileName);
                
                // *** Write the content ***
                string fileName = WriteFile(fullFileName, result.DocumentData.DocumentContent);

                // *** Check result ***
                if (!string.IsNullOrWhiteSpace(fileName))
                    model.FileName = Url.Content(fileName);
                else
                    this.Error("The document could not be generated");
            }

            return View(model); 
        }

        [HttpPost]
        public ActionResult Upload(CdaIndex model)
        {
            ActionResult returnResult = null; 

            if (this.Request.Files != null)
                if (this.Request.Files.Count > 0)
                {
                    HttpPostedFileBase file = this.Request.Files[0];
                    if (file != null && file.ContentLength > 0)
                    {
                        string fileName = string.Format("{0}.xml", Guid.NewGuid());

                        string path = Path.Combine(Server.MapPath("~/Content/Cda"), fileName);

                        file.SaveAs(path);

                        this.TempData[uploadFileKey] = path; 

                        returnResult = RedirectToAction("PreviewUpload", new { dfn = model.Patient.Dfn });
                    }
                }

            if (returnResult == null) 
                returnResult = RedirectToAction("Index", new { @dfn = model.Patient.Dfn });

            return returnResult;
        }

        [HttpGet]
        public ActionResult PreviewUpload(string dfn)
        {
            // *** Preview the upload file if it is supported ***

            ActionResult returnResult = null;

            CdaDocumentModel model = new CdaDocumentModel();

            model.Patient = this.CurrentPatient;

            // *** First verify that this is a file we can work with ***

            // *** Get the file name from temp data ***
            string file = (string)this.TempData.Peek(uploadFileKey);

            // *** Get the string content ***
            string documentContent = System.IO.File.ReadAllText(file); 

            // *** Check if document is supported using repository method ***
            BrokerOperationResult result = this.DashboardRepository.CdaDocuments.DocumentIsSupported(documentContent);

            // *** Check result ***
            if (!result.Success)
            {
                if (!string.IsNullOrWhiteSpace(result.Message))
                    this.Error(result.Message);

                returnResult = RedirectToAction("Index", new { @dfn = dfn });
            }
            else
            {
                // *** Display it ***

                string fileNameOnly = Path.GetFileName(file); 

                string virtualPath = Url.Content("~/Content/Cda/" + fileNameOnly); 

                model.FileName = virtualPath;
                
                returnResult = View(model); 
            }

            return returnResult;
        }

        [HttpGet]
        public ActionResult PatientMatch(string dfn, string page)
        {
            CdaPatientMatch matchModel = new CdaPatientMatch();

            // *** Set current patient ***
            this.CurrentPatientDfn = dfn;
            BasePatient currentPatient = this.CurrentPatient; 

            // *** Add dfn to model ***
            matchModel.CurrentPatientDfn = dfn;

            // *** Get integer for page ***
            int pageVal = this.GetPage(page); 

            // *** Get the file name from temp data ***
            string file = (string)this.TempData.Peek(uploadFileKey);

            // *** Get the string content ***
            string documentContent = System.IO.File.ReadAllText(file); 

            // *** Find the patient in the document ***
            PatientDemographicsResult result = this.DashboardRepository.CdaDocuments.GetDocumentPatient(documentContent);

            if (!result.Success)
            {
                if (!string.IsNullOrWhiteSpace(result.Message))
                    this.Error(result.Message);
            }
            else 
            {
                // *** Add document patient to model ***
                matchModel.DocumentPatient = result.Patient;

                // *** See if we have a match with current ***
                MatchType tempMatchType = CdaMatchingUtility.GetMatchType(matchModel.DocumentPatient, currentPatient);
                switch (tempMatchType)
                {
                    case MatchType.Exact:

                        // *** Create a matched patient for view ***
                        CdaMatchedPatient matchPat = new CdaMatchedPatient();

                        // *** Set match type and pat values ***
                        matchPat.MatchType = tempMatchType;
                        matchPat.Patient = currentPatient;
                        
                        // *** Make sure list exists and add ***
                        if (matchModel.MatchingPatients == null)
                            matchModel.MatchingPatients = new List<CdaMatchedPatient>();
                        matchModel.MatchingPatients.Add(matchPat);

                        // *** Set proper paging values...hide ***
                        matchModel.Paging.SetPagingData(patientMatchesPerPage, pageVal, 1);

                        break;

                    case MatchType.Partial:
                    case MatchType.None:

                        // *** Do a "progressive" search to find matches ***
                        PatientSearchResult searchResult =  
                            this.DashboardRepository.Patients.ProgressiveSearch(
                                matchModel.DocumentPatient.LastName, 
                                matchModel.DocumentPatient.FirstName, 
                                pageVal,
                                patientMatchesPerPage);

                        // *** Check result ***
                        if (!searchResult.Success)
                        {
                            if (!string.IsNullOrWhiteSpace(searchResult.Message))
                                this.Error(searchResult.Message);
                        }
                        else
                        {
                            // *** Do we have any patients to work with ***
                            if (searchResult.Patients != null)
                                foreach (SearchPatient pat in searchResult.Patients)
                                {
                                    // *** Create a matched patient for each ***
                                    CdaMatchedPatient tempMatch = new CdaMatchedPatient();
                                    tempMatch.Patient = (BasePatient)pat;
                                    tempMatch.MatchType = CdaMatchingUtility.GetMatchType(matchModel.DocumentPatient, tempMatch.Patient);
                                    matchModel.MatchingPatients.Add(tempMatch);
                                }

                            // *** Set paging values ***
                            matchModel.Paging.SetPagingData(DefaultResultsPerPage, pageVal, searchResult.TotalResults);
                            matchModel.Paging.BaseUrl = Url.Action("PatientMatch", new { dfn = dfn, page = "" });
                        }
                        break;
                }

            }
            
            return View(matchModel);
        }

        [HttpGet]
        public ActionResult DataImport(string dfn)
        {
            CdaDocumentModel model = new CdaDocumentModel(); 

            // *** Set current patient ***
            this.CurrentPatientDfn = dfn;
            model.Patient = this.CurrentPatient;

            // *** TODO: Get discreet data elements from document
            // *** TODO: Create model which supports display of data and selection...

            return View(model);
        }

        [HttpPost]
        public ActionResult FinishImport(CdaDocumentModel model)
        {
            ActionResult returnResult; 

            // *** Get the file name from temp data ***
            string file = (string)this.TempData.Peek(uploadFileKey);

            // *** Get the string content ***
            string documentContent = System.IO.File.ReadAllText(file);

            // *** Get data from document ***
            CdaDocumentResult extractResult = this.DashboardRepository.CdaDocuments.ExtractDocumentData(documentContent);

            bool fail = false; 

            // *** Check result ***
            if (!extractResult.Success)
            {
                if (!string.IsNullOrWhiteSpace(extractResult.Message))
                    this.Error(extractResult.Message);

                fail = true; 
            }
            else
            {
                // *** Create new document ***
                CdaDocumentData newDocument = extractResult.DocumentData;

                // *** Set other values ***
                newDocument.DocumentContent = documentContent;
                newDocument.ExchangeDirection = ExchangeDirection.Inbound;
                newDocument.ImportDateTime = DateTime.Now;
                newDocument.IntendedRecipient = "Unknown";
                newDocument.PatientDfn = model.Patient.Dfn;

                if (string.IsNullOrWhiteSpace(newDocument.Sender))
                    newDocument.Sender = "Unknown"; 

                // *** Save the document ***
                BrokerOperationResult result = this.DashboardRepository.CdaDocuments.SaveDocument(newDocument);

                // *** Check result ***
                if (!result.Success)
                {
                    if (!string.IsNullOrWhiteSpace(result.Message))
                        this.Error(result.Message);
                    fail = true;
                }
                else
                {
                    // *** Convert content to text ***
                    string textContent = ConvertDocToText(documentContent); 

                    // *** Save as progress note ***
                    BrokerOperationResult brokerResult = this.DashboardRepository.Notes.CreateDashboardNote(model.Patient.Dfn, textContent);

                    // *** Check result ***
                    if (!brokerResult.Success)
                    {
                        if (!string.IsNullOrWhiteSpace(brokerResult.Message))
                            this.Error(brokerResult.Message);
                        fail = true;
                    }
                    else
                    {
                        // *** Report success ***
                        this.Information("The document has been successfully imported into the dashboard");
                    }                    
                }
            }

            // *** Determine where to go from here ***
            if (fail)
                returnResult = RedirectToAction("DataImport", new { dfn = model.Patient.Dfn });
            else
            {
                // *** Clean up ***
                System.IO.File.Delete(file);
                TempData.Remove(uploadFileKey);

                returnResult = RedirectToAction("Index", new { dfn = model.Patient.Dfn });
            }

            return returnResult; 
        }

        private string ConvertDocToText(string documentContent)
        {
            // *** Converts the incoming xml document to plain text ***

            string returnVal = "";

            // *** Create xpath doc **
            XPathDocument doc = new XPathDocument(new StringReader(documentContent)); 
            
            // *** Create a string build to contain result ***
            StringBuilder sb = new StringBuilder();

            // *** Create the writer to receive the content ***
            using (XmlWriter writer = XmlWriter.Create(sb))
            {
                // *** Create tranform and settings ***
                XslCompiledTransform transform = new XslCompiledTransform();
                XsltSettings settings = new XsltSettings();
                settings.EnableScript = true;

                // *** Load the style sheet ***
                transform.Load(Server.MapPath("~/Content/Cda/CDA.xsl"), settings, null);

                // *** Do transform ***
                transform.Transform(doc, writer);
            }
            
            // *** Get the string result ***
            returnVal = sb.ToString();
            
            // TODO: Format better for plain text 

            // *** Use regular expressions to remove tags ***
            Regex reg = new Regex("<[^>]+>", RegexOptions.IgnoreCase);
            returnVal = reg.Replace(returnVal, ""); 

            return returnVal; 
        }

        private string FullOutgoingPath
        {
            get
            {
                return Path.Combine(this.Request.PhysicalApplicationPath, outgoingPhysicalPath);
            }
        }

        private string GetUniqueFileName(string docName, string patientName)
        {
            // *** Gets a unique name based on document, patient, date, and a counter ***

            // *** Returns "" if not able to find unique name ***

            string returnVal = ""; 

            // *** Create the base name from document, patient, and date ***
            string baseName = string.Format("{0}-{1}-{2}", docName, patientName, DateTime.Now.ToString("MM-dd-yy"));

            // *** Add extension ***
            string fileName = string.Format("{0}.xml", baseName);

            // *** Combine the path and file name ***
            string fullFileName = Path.Combine(FullOutgoingPath, fileName);

            // *** Check if it already exists ***
            if (System.IO.File.Exists(fullFileName))
            {
                // *** If exists, use counter to find unique ***
                int counter = 1;
                fullFileName = Path.Combine(FullOutgoingPath, string.Format("{0}-{1}.xml", baseName, counter));

                // *** Check if name with counter exists ***
                while ((System.IO.File.Exists(fullFileName) && counter < 100))
                {
                    // *** Bump the counter and create a new name ***
                    counter += 1;
                    fullFileName = Path.Combine(FullOutgoingPath, string.Format("{0}-{1}.xml", baseName, counter));
                }

                // *** If we tried less than 100, then success ***
                if (counter < 100)
                    returnVal = fullFileName;
            }
            else
                returnVal = fullFileName;

            return returnVal; 
        }

        private string PrepareFile(string docName, string patientName, string documentContent) 
        {
            string returnVal = ""; 

            // *** Create a new file ***
            string fullFileName = GetUniqueFileName(docName, patientName);

            // *** If empty, then no unique file name could be acquired ***
            if (string.IsNullOrWhiteSpace(fullFileName))
                this.Error("The system could not generate the file");
            else
            {
                returnVal = WriteFile(fullFileName, documentContent); 
            }

            return returnVal; 
        }

        private string WriteFile(string fullFileName, string documentContent)
        {
            string returnVal = ""; 

            // *** Make a copy ***
            System.IO.File.WriteAllText(fullFileName, documentContent);

            // *** Create the session file list for outgoing files ***
            List<string> docList;
            if (Session[outgoingCdaDocsSessionKey] == null)
            {
                docList = new List<string>();
                Session[outgoingCdaDocsSessionKey] = docList;
            }
            else
                docList = (List<string>)Session[outgoingCdaDocsSessionKey];

            // *** Add the document to the session list for cleanup later ***
            docList.Add(fullFileName);

            // *** Set content to relative path for access in View ***
            returnVal = outgoingVirtualPath + Path.GetFileName(fullFileName);

            return returnVal; 
        }

    }
}
