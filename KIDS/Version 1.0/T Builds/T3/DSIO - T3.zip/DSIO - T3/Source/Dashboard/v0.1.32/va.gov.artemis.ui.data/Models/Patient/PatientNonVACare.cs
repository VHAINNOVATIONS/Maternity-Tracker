﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VA.Gov.Artemis.UI.Data.Models.Administration;

namespace VA.Gov.Artemis.UI.Data.Models.Patient
{
    public class PatientNonVACare
    {
        public BasePatient Patient { get; set; }

        public List<PatientNonVACareItem> AllNonVACareItems {get; set; }

        public PatientNonVACareItem CurrentPrentalCareProvider
        {
            get
            {         
                return GetMostRecent(NonVACareItemType.Provider);
            }
        }


        public PatientNonVACareItem CurrentPlannedDeliveryLocation
        {
            get
            {
                return GetMostRecent(NonVACareItemType.Facility);
            }
        }

        private PatientNonVACareItem GetMostRecent(NonVACareItemType itemType)
        {
            PatientNonVACareItem returnVal = null;

            if (this.AllNonVACareItems != null)
                foreach (PatientNonVACareItem item in this.AllNonVACareItems)
                    if (item.ItemDetail != null)
                        if (item.ItemDetail.ItemType == NonVACareItemType.Provider)
                            if (returnVal == null)
                                returnVal = item;
                            else if (item.EntryDate > returnVal.EntryDate)
                                returnVal = item;
            return returnVal; 
        }

        public List<PatientNonVACareItem> PreviousNonVACareItems
        {
            get
            {
                List<PatientNonVACareItem> returnList = new List<PatientNonVACareItem>();

                PatientNonVACareItem tempCurProv = this.GetMostRecent(NonVACareItemType.Provider);
                PatientNonVACareItem tempCurFac = this.GetMostRecent(NonVACareItemType.Facility);

                if (this.AllNonVACareItems != null)
                    foreach (PatientNonVACareItem item in this.AllNonVACareItems)
                        if ((item != tempCurFac) && (item != tempCurProv))
                            returnList.Add(item); 

                return returnList;
            }
        }

    }
}
