﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VA.Gov.Artemis.UI.Data.Models.Administration
{
    public class NonVACareItemList
    {
        public Paging Paging { get; set; }

        public List<NonVACareItem> Items { get; set; }

        public NonVACareItemList()
        {
            this.Paging = new Paging();
            this.Items = new List<NonVACareItem>(); 
        }
    }
}
