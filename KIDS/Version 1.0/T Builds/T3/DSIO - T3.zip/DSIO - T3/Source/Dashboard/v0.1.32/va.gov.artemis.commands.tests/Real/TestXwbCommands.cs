﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;
using VA.Gov.Artemis.Vista.Commands;
using VA.Gov.Artemis.Vista.Broker;
using VA.Gov.Artemis.Commands.Xwb;

namespace VA.Gov.Artemis.Commands.tests.real
{
    [TestClass]
    public class TestXwbCommands: TestCommandsBase
    {
        [TestMethod]
        public void TestGetBrokerInfoCommand()
        {
            Queue<CommandBase> commandQueue = new Queue<CommandBase>();

            using (RpcBroker broker = GetConnectedBroker())
            {
                XwbGetBrokerInfoCommand testCommand = new XwbGetBrokerInfoCommand(broker); 

                commandQueue.Enqueue(testCommand);

                RpcResponse response = ExecuteCommandQueue(commandQueue);

                // *** Check results ***
                Assert.AreEqual(RpcResponseStatus.Success, response.Status);
                Assert.IsTrue(testCommand.TimeoutMilliseconds > 0);

                broker.Disconnect();
            }
        }
    }
}
