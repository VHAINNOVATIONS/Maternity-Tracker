﻿using System;
using VA.Gov.Artemis.Vista.Broker;
using VA.Gov.Artemis.Vista.Commands;

namespace VA.Gov.Artemis.Commands.Xwb
{
    public class XwbGetBrokerInfoCommand: CommandBase 
    {
        public XwbGetBrokerInfoCommand(IRpcBroker newBroker) :
            base(newBroker) { }

        public override string RpcName { get { return "XWB GET BROKER INFO";}}

        public override string Version { get { return "0";}}

        public int TimeoutMilliseconds { get; set; }

        protected override void ProcessResponse()
        {
            int timeOutSeconds = 0;

            if (string.IsNullOrWhiteSpace(this.Response.Data))
            {
                this.Response.Status = RpcResponseStatus.Fail;
                this.Response.FailType = RpcResponseFailType.UnexpectedResultEmpty;
            }
            else if (Int32.TryParse(this.Response.Data, out timeOutSeconds))
            {
                this.TimeoutMilliseconds = timeOutSeconds * 1000;
                this.Response.Status = RpcResponseStatus.Success;
            }
            else
            {
                this.Response.Status = RpcResponseStatus.Fail;
                this.Response.FailType = RpcResponseFailType.UnexpectedResultFormat;
            }
        }

    }
}
