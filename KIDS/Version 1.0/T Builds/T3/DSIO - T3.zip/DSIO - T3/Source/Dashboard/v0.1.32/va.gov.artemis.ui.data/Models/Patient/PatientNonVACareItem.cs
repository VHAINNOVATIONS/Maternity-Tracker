﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VA.Gov.Artemis.UI.Data.Models.Administration;

namespace VA.Gov.Artemis.UI.Data.Models.Patient
{
    public class PatientNonVACareItem
    {
        public string Dfn { get; set; }
        public string UserName { get; set; }
        public DateTime EntryDate { get; set; }
        public string PrimaryContactName { get; set; }
        public NonVACareItem ItemDetail { get; set; }        
    }
}
