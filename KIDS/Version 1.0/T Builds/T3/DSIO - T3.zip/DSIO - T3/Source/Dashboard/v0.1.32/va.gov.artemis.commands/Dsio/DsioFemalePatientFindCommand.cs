﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VA.Gov.Artemis.Vista.Broker;

namespace VA.Gov.Artemis.Commands.Dsio
{
    public class DsioFemalePatientFindCommand: DsioFemalePatientSearchCommand
    {
         public DsioFemalePatientFindCommand(IRpcBroker newBroker):base(newBroker)
        {
            this.firstLineIsCount = false; 
        }

        public override string RpcName
        {
            get { return "DSIO FEMALE PATIENT FIND"; }
        }

        public void AddCommandArguments(string searchCriteria)
        {
            this.CommandArgs = new object[] 
            {
                searchCriteria
            };
        }

    }
}
