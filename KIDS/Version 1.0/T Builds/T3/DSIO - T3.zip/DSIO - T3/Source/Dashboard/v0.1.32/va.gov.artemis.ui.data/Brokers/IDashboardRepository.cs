﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VA.Gov.Artemis.Vista.Broker;

namespace VA.Gov.Artemis.UI.Data.Brokers
{
    public interface IDashboardRepository
    {
        IAccountRepository Accounts { get; set; }
        IDivisionRepository Divisions { get; set; }
        ISettingsRepository Settings { get; set; }
        IPatientRepository Patients { get; set; }
        ISelectListRepository SelectLists { get; set; }
        ITrackingHistoryRepository TrackingHistory { get; set; }
        INoteRepository Notes { get; set; }
        INonVACareRepository NonVACare { get; set; }
        ICdaRepository CdaDocuments { get; set; }

        void SetRpcBroker(IRpcBroker broker);
    }
}
