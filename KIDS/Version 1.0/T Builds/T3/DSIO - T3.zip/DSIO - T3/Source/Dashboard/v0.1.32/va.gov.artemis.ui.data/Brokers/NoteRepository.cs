﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VA.Gov.Artemis.Commands.Dsio;
using VA.Gov.Artemis.Commands.Tiu;
using VA.Gov.Artemis.UI.Data.Brokers.Results;
using VA.Gov.Artemis.UI.Data.Models.Aggregated;
using VA.Gov.Artemis.UI.Data.Models.Notes;
using VA.Gov.Artemis.Vista.Broker;
using VA.Gov.Artemis.Vista.Utility;

namespace VA.Gov.Artemis.UI.Data.Brokers
{
    public class NoteRepository: RepositoryBase, INoteRepository
    {
        // TODO: Use DSIO for prog notes instead of TIU...

        // TODO: Hard-Coded or configurable ? 
        private const string DashboardNoteTitle = "MCC DASHBOARD NOTE"; 

        public NoteRepository(IRpcBroker newBroker): base(newBroker)
        {

        }

        public TiuNoteResult GetLatestProgressNote(string dfn)
        {
            // *** Get latest progress note ***

            TiuNoteResult result = new TiuNoteResult(); 

            // *** Check broker ***
            if (this.broker != null)
            {
                // *** Create command to get documents ***
                TiuDocumentsByContextCommand command = new TiuDocumentsByContextCommand(this.broker);

                // *** Add parameter ***
                command.AddCommandArgument(dfn);

                // *** Execute command ***
                RpcResponse response = command.Execute();

                // *** Set return vals ***
                result.Success = (response.Status == RpcResponseStatus.Success);
                result.Message = response.InformationalMessage;

                // *** Check for success ***
                if (result.Success)
                {                    
                    TiuNote latestNote = null;

                    // *** Check if we have any and loop ***
                    if (command.Documents != null)
                        foreach (TiuDocument doc in command.Documents)
                        {
                            // *** Set latest if needed ***
                            if (latestNote == null)
                                latestNote = GetTiuNote(doc);
                            else
                            {
                                TiuNote tempNote = GetTiuNote(doc);

                                // *** Check if newer ***
                                if (tempNote.DocumentDateTime > latestNote.DocumentDateTime)
                                    latestNote = tempNote; 
                            }
                        }

                    // *** Check if we have one after loop ***
                    if (latestNote != null)
                    {                     
                        // *** Set return ***
                        result.Note = latestNote;

                        // *** Create command to get note text ***
                        TiuGetRecordTextCommand textCommand = new TiuGetRecordTextCommand(this.broker);

                        // *** Add parameter ***
                        textCommand.AddCommandArgument(latestNote.Ien);

                        // *** Execute command ***
                        response = textCommand.Execute();

                        // *** Set return value ***
                        result.Success = (response.Status == RpcResponseStatus.Success);
                        result.Message = response.InformationalMessage;

                        if (result.Success)
                            result.Note.NoteText = textCommand.RecordText; 
                    }                    
                }        
            }

            return result; 
        }

        //private TiuNote GetTiuNote(TiuDocument document)
        //{
        //    // *** Create tiu note from tiu document ***

        //    TiuNote returnVal = new TiuNote();

        //    returnVal.Ien = document.Ien;
        //    returnVal.DocumentDateTime = Util.GetDateTime(document.DocumentDateTime);
        //    returnVal.Title = document.Title; 
            
        //    return returnVal; 
        //}

        public HasProgressNoteResult HasProgressNote(string dfn)
        {
            // *** Determine if patient has a progress note ***

            HasProgressNoteResult result = new HasProgressNoteResult();

            // *** Make sure we have broker ***
            if (this.broker != null)
            {
                // *** Create documents command ***
                TiuDocumentsByContextCommand command = new TiuDocumentsByContextCommand(this.broker);

                // *** Add parameter ***
                command.AddCommandArgument(dfn);

                // *** Execute command ***
                RpcResponse response = command.Execute();

                // *** Set return values ***
                result.Success = (response.Status == RpcResponseStatus.Success);
                result.Message = response.InformationalMessage;

                // *** Check result/command for prog notes ***
                if (result.Success)
                    if (command.Documents != null)
                        if (command.Documents.Count > 0)
                            result.HasProgressNote = true;
            }
            
            return result; 
        }

        public TiuNoteResult GetProgressNote(string ien)
        {
            TiuNoteResult result = new TiuNoteResult();

            // *** Set return ***
            //result.Note = latestNote;

            // *** Create command to get note text ***
            TiuGetRecordTextCommand textCommand = new TiuGetRecordTextCommand(this.broker);

            // *** Add parameter ***
            textCommand.AddCommandArgument(ien);

            // *** Execute command ***
            RpcResponse response = textCommand.Execute();

            // *** Set return value ***
            result.Success = (response.Status == RpcResponseStatus.Success);
            result.Message = response.InformationalMessage;

            result.Note = new TiuNote();

            if (result.Success)
                result.Note.NoteText = textCommand.RecordText;

            return result;
        }

        public NoteListResult GetList(string dfn)
        {
            // *** Get list of progress notes ***

            NoteListResult result = new NoteListResult();

            // *** Check broker ***
            if (this.broker != null)
            {
                // *** Create command to get documents ***
                TiuDocumentsByContextCommand command = new TiuDocumentsByContextCommand(this.broker);

                // *** Add parameter ***
                command.AddCommandArgument(dfn);

                // *** Execute command ***
                RpcResponse response = command.Execute();

                // *** Set return vals ***
                result.Success = (response.Status == RpcResponseStatus.Success);
                result.Message = response.InformationalMessage;

                // *** Check for success ***
                if (result.Success)
                {
                    // *** Check if we have any and loop ***
                    if (command.Documents != null)
                        foreach (TiuDocument doc in command.Documents)
                        {
                            TiuNote note = GetTiuNote(doc);

                            note.PatientDfn = dfn;

                            result.Notes.Add(note);
                        }
                }
            }

            return result;
        }

        public BrokerOperationResult CreateDashboardNote(string dfn, string noteText)
        {
            // TODO: Figure out note titles 
            // TODO: How to handle discreet data 

            BrokerOperationResult returnResult = new BrokerOperationResult();

            if (this.broker != null)
            {
                DsioCreateANoteCommand command = new DsioCreateANoteCommand(broker);

                command.AddCommandArguments(dfn, DashboardNoteTitle, noteText, "");

                RpcResponse response = command.Execute();

                returnResult.Success = (response.Status == RpcResponseStatus.Success);
                returnResult.Message = response.InformationalMessage;

            }

            return returnResult; 
        }

        public NoteListResult GetDashboardNotes(string dfn, int page, int itemsPerPage)
        {
            NoteListResult returnResult = new NoteListResult();

            if (this.broker != null)
            {
                DsioNotesByDfnAndTitleCommand command = new DsioNotesByDfnAndTitleCommand(broker);

                command.AddCommandArguments(dfn, DashboardNoteTitle, page, itemsPerPage);

                RpcResponse response = command.Execute();

                returnResult.Success = (response.Status == RpcResponseStatus.Success);

                returnResult.Message = response.InformationalMessage;

                if (returnResult.Success)
                {
                    returnResult.TotalResults = command.TotalResults; 

                    foreach (TiuDocument doc in command.Notes)
                    {
                        TiuNote note = GetDashboardNote(doc);

                        note.PatientDfn = dfn;

                        returnResult.Notes.Add(note); 
                    }
                }

            }

            return returnResult; 
        }

        public BrokerOperationResult UpdateDashboardNote(string ien, string noteText)
        {
            BrokerOperationResult result = new BrokerOperationResult();

            if (this.broker != null)
            {
                DsioUpdateANoteCommand command = new DsioUpdateANoteCommand(broker);

                command.AddCommandArguments(ien, noteText, "");

                RpcResponse response = command.Execute();

                result.Success = (response.Status == RpcResponseStatus.Success);
                result.Message = response.InformationalMessage; 

            }

            return result; 
        }

        public BrokerOperationResult CreateDashboardAddendum(string ien, string noteText)
        {
            BrokerOperationResult returnResult = new BrokerOperationResult();

            if (this.broker != null)
            {
                DsioMakeAddendumCommand command = new DsioMakeAddendumCommand(broker);

                command.AddCommandArguments(ien, noteText, "");

                RpcResponse response = command.Execute();

                returnResult.Success = (response.Status == RpcResponseStatus.Success);
                returnResult.Message = response.InformationalMessage;

            }

            return returnResult;             
        }

        public BrokerOperationResult DeleteDashboardNote(string ien, string justification)
        {
            BrokerOperationResult result = new BrokerOperationResult(); 

            if (this.broker  != null) 
            {
                DsioDeleteANoteCommand command = new DsioDeleteANoteCommand(this.broker); 

                command.AddCommandArguments(ien, justification); 

                RpcResponse response = command.Execute(); 

                result.Success = (response.Status == RpcResponseStatus.Success); 
                result.Message = response.InformationalMessage; 
            }

            return result;
        }

        public BrokerOperationResult SignDashboardNote(string ien, string sig)
        {
            BrokerOperationResult result = new BrokerOperationResult();

            if (this.broker != null)
            {
                DsioSignANoteCommand command = new DsioSignANoteCommand(this.broker); 

                command.AddCommandArguments(ien, sig);

                RpcResponse response = command.Execute();

                result.Success = (response.Status == RpcResponseStatus.Success);
                result.Message = response.InformationalMessage;
            }

            return result;
            
        }

        public TiuNoteResult GetDashboardNote(string ien)
        {
            // TODO: Get header information also...

            TiuNoteResult result = new TiuNoteResult();

            if (this.broker != null)
            {
                DsioGetRecordTextCommand command = new DsioGetRecordTextCommand(this.broker);

                command.AddCommandArgument(ien);

                RpcResponse response = command.Execute();

                result.Success = (response.Status == RpcResponseStatus.Success);
                result.Message = response.InformationalMessage;

                if (result.Success)
                    result.Note = new TiuNote() { NoteText = command.RecordText }; 
            }

            return result;
        }

        private TiuNote GetTiuNote(TiuDocument doc)
        {
            TiuNote returnVal = new TiuNote();

            returnVal.Ien = doc.Ien;
            returnVal.Author = Util.Piece(doc.Author, ";", 3);
            returnVal.DocumentDateTime = Util.GetDateTime(doc.DocumentDateTime);
            returnVal.Location = doc.Location;
            returnVal.Title = doc.Title;

            return returnVal;
        }

        private TiuNote GetDashboardNote(TiuDocument doc)
        {
            TiuNote returnVal = new TiuNote();

            returnVal.Ien = doc.Ien;

            switch (doc.SignatureStatus)
            {
                case "UNSIGNED":
                    returnVal.SignatureStatus = TiuNoteSignatureStatus.Unsigned;
                    break;
                case "COMPLETED":
                    returnVal.SignatureStatus = TiuNoteSignatureStatus.Completed;
                    break;
                default:
                    returnVal.SignatureStatus = TiuNoteSignatureStatus.Unknown;
                    break;
            }

            returnVal.Author = doc.Author;

            CultureInfo enUS = new CultureInfo("en-US");
            DateTime tempDateTime = DateTime.MinValue;
            if (DateTime.TryParseExact(doc.DocumentDateTime, RepositoryDates.VistADateFormatOne, enUS, DateTimeStyles.None, out tempDateTime))
                returnVal.DocumentDateTime = tempDateTime;

            returnVal.Location = doc.Location;

            returnVal.ParentIen = doc.ParentIen;

            return returnVal;
        }
    }
}
