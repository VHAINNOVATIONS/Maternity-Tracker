﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VA.Gov.Artemis.Cda
{
    public class ApsDocument : IheDocument
    {
        public ApsDocument()
            : base()
        {
            //<code code='2.16.1.2' codeSystem='2.4' displayName='loinc'/>
            this.code = new CE() { code = "2.16.1.2", codeSystem = "2.4", displayName = "LOINC" };

        }
    }
}