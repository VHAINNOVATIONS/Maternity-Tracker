﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VA.Gov.Artemis.UI.Data.Models.Patient
{
    public class CurrentPregnancyDetails
    {
        public BasePatient Patient { get; set; }

        public CurrentPregnancy CurrentPregnancy { get; set; }
    }
}
