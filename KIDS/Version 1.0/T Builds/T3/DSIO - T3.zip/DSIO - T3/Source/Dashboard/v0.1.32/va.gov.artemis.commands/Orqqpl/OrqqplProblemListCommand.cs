﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VA.Gov.Artemis.Vista.Broker;
using VA.Gov.Artemis.Vista.Commands;
using VA.Gov.Artemis.Vista.Utility;

namespace VA.Gov.Artemis.Commands.Orqqpl
{
    public class OrqqplProblemListCommand: CommandBase 
    {
        public OrqqplProblemListCommand(IRpcBroker newBroker): base(newBroker)
        {
            this.Context = "DSIO GUI CONTEXT"; 

            this.Problems = new List<OrqqplProblem>(); 
        }

        public List<OrqqplProblem> Problems { get; private set; }

        public override string RpcName
        {
            get { return "ORQQPL PROBLEM LIST"; }
        }

        public override string Version
        {
            get { return "0"; }
        }

        public void AddCommandParameters(string patientDfn)
        {
            this.CommandArgs = new object[] { patientDfn, "A" };
        }

        protected override void ProcessResponse()
        {
            if (!string.IsNullOrWhiteSpace(this.Response.Data))
            {
                string[] lines = this.Response.Lines; 

                bool first = true; 

                foreach (string line in lines)
                {
                    if (first) 
                        first = false; 
                    else 
                    {
                        OrqqplProblem problem = new OrqqplProblem(); 

                        problem.Problem = Util.Piece(line, Caret, 3);
                        problem.DxCode = Util.Piece(line, Caret, 4);
                        problem.ProblemDateTime = Util.Piece(line, Caret, 5);

                        this.Problems.Add(problem); 
                    }
                }
            }

            this.Response.Status = RpcResponseStatus.Success; 
        }
    }
}
