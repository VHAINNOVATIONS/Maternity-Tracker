﻿//using VA.Gov.Artemis.UI.Data.Models.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using VA.Gov.Artemis.UI.Data.Models.Aggregated.Common;

namespace VA.Gov.Artemis.UI.Data.Models.Aggregated.TrackedEvents
{
    public class EducationalMaterialsProvisionEvent : TrackedEvent
    {
        public string MaterialName { get; set; }
        public ProvisionMethod ProvisionMethod { get; set; }

        public override TrackedEventType EventType { get { return TrackedEventType.EducationalMaterials; } }

        public override string EventName
        {
            get
            {
                return "Edcuational Materials: " + this.MaterialName;
            }
        }

        public override string Details
        {
            get
            {
                string returnVal = "";

                //if (this.Completed == DateTime.MinValue)
                //    returnVal += "Due on " + this.Due.ToShortDateString();
                //else
                //    returnVal += "Completed on " + this.Completed.ToShortDateString();

                return returnVal;
            }
        }
    }
}