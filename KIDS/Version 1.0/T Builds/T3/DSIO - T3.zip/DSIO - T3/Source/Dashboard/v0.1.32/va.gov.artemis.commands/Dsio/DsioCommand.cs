﻿using VA.Gov.Artemis.Vista.Broker;
using VA.Gov.Artemis.Vista.Commands;

namespace VA.Gov.Artemis.Commands.Dsio
{
    public abstract class DsioCommand: CommandBase
    {
        public DsioCommand(IRpcBroker newBroker): base(newBroker)
        {
            this.Context = "DSIO GUI CONTEXT";
        }

        public override string Version
        {
            get { return "0"; }
        }

    }
}
