﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;
using VA.Gov.Artemis.Vista.Commands;
using VA.Gov.Artemis.Vista.Broker;
using VA.Gov.Artemis.Commands.Xus;
using VA.Gov.Artemis.Commands.Vpr;
using System.Xml.Serialization;
using System.IO;
using VA.Gov.Artemis.Commands.Vpr.Data;
using VA.Gov.Artemis.Commands.Orwpt;
using System.Diagnostics;

namespace VA.Gov.Artemis.Commands.tests.real
{
    [TestClass]
    public class TestVprCommands: TestCommandsBase
    {
        [TestMethod]
        public void TestGetPatientDataCommand()
        {
            using (RpcBroker broker = GetConnectedBroker())
            {
                this.SignonToBroker(broker, 0); 

                VprGetPatientDataCommand testCommand = new VprGetPatientDataCommand(broker);

                testCommand.AddCommandArguments("229");

                RpcResponse response = testCommand.Execute();

                // *** Check results ***
                Assert.AreEqual(RpcResponseStatus.Success, response.Status);

                Assert.IsFalse(string.IsNullOrWhiteSpace(response.Data));

                broker.Disconnect();
            }
        }

        //[TestMethod]
        //public void TestXmlSerialization()
        //{
        //    using (RpcBroker broker = GetConnectedBroker())
        //    {
        //        XusSignonSetupCommand ssCommand = new XusSignonSetupCommand(broker);

        //        RpcResponse response = ssCommand.Execute();

        //        if (response.Status == RpcResponseStatus.Success)
        //        {
        //            XusAvCodeCommand avCommand = new XusAvCodeCommand(broker, ValidAccessCodes[0], ValidVerifyCodes[0]);

        //            response = avCommand.Execute();

        //            if (response.Status == RpcResponseStatus.Success)
        //            {
        //                //TestOne(broker, "229");
        //                //TestOne(broker, "740");
        //                //TestOne(broker, "51");
        //                //TestOne(broker, "8");
        //                //TestOne(broker, "421");
        //                TestAll(broker);
        //            }
        //            else
        //                Assert.Fail("Invalid AV Code"); 
        //        }                

        //        broker.Disconnect();
        //    }

        //}

        private void TestOne(IRpcBroker broker, string dfn)
        {
            foreach (VprDataType vprDataType in Enum.GetValues(typeof(VprDataType)))
            {
                VprGetPatientDataCommand testCommand = new VprGetPatientDataCommand(broker);

                testCommand.AddCommandArguments(dfn, vprDataType); 

                RpcResponse response = testCommand.Execute();

                // *** Check results ***
                Assert.AreEqual(RpcResponseStatus.Success, response.Status);

                Assert.IsFalse(string.IsNullOrWhiteSpace(response.Data));

                processXml(response.Data, vprDataType);
            }
        }

        private void processXml(string origXml, VprDataType vprDataType)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(PatientResult));
            
            string fileName = string.Format(@"C:\Projects\VA\Artemis\bin\{0}_before.xml", vprDataType.ToString());

            File.WriteAllText(fileName, origXml); 

            using (StringReader reader = new StringReader(origXml))
            {
                PatientResult patDemo = (PatientResult)serializer.Deserialize(reader);

                fileName = string.Format(@"C:\Projects\VA\Artemis\bin\{0}_after.xml", vprDataType.ToString());

                FileStream fs = new FileStream(fileName, FileMode.Create );

                XmlSerializerNamespaces ns = new XmlSerializerNamespaces();
                ns.Add("", "");

                serializer.Serialize(fs, patDemo, ns); 

            }
        }

        //private void TestAll(IRpcBroker broker)
        //{
        //    OrwptListAllCommand command = new OrwptListAllCommand(broker);

        //    RpcResponse response = command.Execute();

        //    if (response.Status == RpcResponseStatus.Success)
        //    {
        //        XmlSerializer serializer = new XmlSerializer(typeof(PatientResult));

        //        if (command.PatientList != null)
        //            foreach (OrwptListPatient patient in command.PatientList)
        //            {
        //                VprGetPatientDataCommand vprCommand = new VprGetPatientDataCommand(broker, patient.Dfn);

        //                RpcResponse vprResponse = vprCommand.Execute();

        //                using (StringReader reader = new StringReader(vprResponse.Data))
        //                {
        //                    PatientResult patDemo = (PatientResult)serializer.Deserialize(reader);

        //                    //int accessionCount = (patDemo.Accessions == null) ? 0 : patDemo.Accessions.Total;
        //                    //int consultsCount = (patDemo.Consults == null) ? 0 : patDemo.Consults.Total;
        //                    //int demoCount = (patDemo.Demographics == null) ? 0 : patDemo.Demographics.Total;
        //                    //int docsCount = (patDemo.Documents == null) ? 0 : patDemo.Documents.Total;
        //                    //int immunizationsCount = (patDemo.Immunizations == null) ? 0 : patDemo.Immunizations.Total;
        //                    //int labCount = (patDemo.Labs == null) ? 0 : patDemo.Labs.Total;
        //                    //int medsCount = (patDemo.Medications == null) ? 0 : patDemo.Medications.Total;
        //                    //int orderCount = (patDemo.Orders == null) ? 0 : patDemo.Orders.Total;
        //                    //int panelCount = (patDemo.Panels == null) ? 0 : patDemo.Panels.Total;
        //                    //int problemsCount = (patDemo.Problems == null) ? 0 : patDemo.Problems.Total;
        //                    //int proceduresCount = (patDemo.Procedures == null) ? 0 : patDemo.Procedures.Total;
        //                    //int radiologyCount = (patDemo.RadiologyExams == null) ? 0 : patDemo.RadiologyExams.Total;
        //                    //int reactionsCount = (patDemo.Reactions == null) ? 0 : patDemo.Reactions.Total;
        //                    //int visitsCount = (patDemo.Visits == null) ? 0 : patDemo.Visits.Total;
        //                    //int vitalsCount = (patDemo.Vitals == null) ? 0 : patDemo.Vitals.Total;

        //                    //if (patDemo.Appointments != null)
        //                    //    if (patDemo.Appointments.List.Count > 0)
        //                    //    {
        //                    //        string fileName = string.Format(@"C:\Projects\VA\Artemis\bin\appts_{0}_before.xml", patient.Dfn.ToString());

        //                    //        File.WriteAllText(fileName, vprResponse.Data);

        //                    //        fileName = string.Format(@"C:\Projects\VA\Artemis\bin\appts_{0}_after.xml", patient.Dfn.ToString());

        //                    //        FileStream fs = new FileStream(fileName, FileMode.Create);

        //                    //        XmlSerializerNamespaces ns = new XmlSerializerNamespaces();
        //                    //        ns.Add("", "");

        //                    //        serializer.Serialize(fs, patDemo, ns); 

        //                    //    }

        //                    //if (patDemo.Appointments != null)
        //                    //    if (patDemo.Appointments.List.Count > 0)
        //                    //    {
        //                    //        string fileName = string.Format(@"C:\Projects\VA\Artemis\bin\appts_{0}_before.xml", patient.Dfn.ToString());

        //                    //        File.WriteAllText(fileName, vprResponse.Data);

        //                    //        fileName = string.Format(@"C:\Projects\VA\Artemis\bin\appts_{0}_after.xml", patient.Dfn.ToString());

        //                    //        FileStream fs = new FileStream(fileName, FileMode.Create);

        //                    //        XmlSerializerNamespaces ns = new XmlSerializerNamespaces();
        //                    //        ns.Add("", "");

        //                    //        serializer.Serialize(fs, patDemo, ns);

        //                    //    }

        //                    //if (vprResponse.Data.Contains("education"))
        //                    //    Debug.WriteLine("hi");

        //                    //if (vprResponse.Data.Contains("topic"))
        //                    //    Debug.WriteLine("hi");

        //                    //if (vprResponse.Data.Contains("exam"))
        //                    //    Debug.WriteLine("hi"); 

        //                    //Debug.WriteLine(patient.LastFirst);
        //                    //Debug.WriteLine("   accessions: {0}", accessionCount);
        //                    //Debug.WriteLine("   consults: {0}", consultsCount);
        //                    //Debug.WriteLine("   demo: {0}", demoCount);
        //                    //Debug.WriteLine("   documents: {0}", docsCount);
        //                    //Debug.WriteLine("   immunizations: {0}", immunizationsCount);
        //                    //Debug.WriteLine("   accessions: {0}", labCount);
        //                    //Debug.WriteLine("   meds: {0}", medsCount);
        //                    //Debug.WriteLine("   order: {0}", orderCount);
        //                    //Debug.WriteLine("   panel: {0}", panelCount);
        //                    //Debug.WriteLine("   problems: {0}", problemsCount);
        //                    //Debug.WriteLine("   procedures: {0}", proceduresCount);
        //                    //Debug.WriteLine("   radiology: {0}", radiologyCount);
        //                    //Debug.WriteLine("   reactions: {0}", reactionsCount);
        //                    //Debug.WriteLine("   visits: {0}", visitsCount);
        //                    //Debug.WriteLine("   vitals: {0}", vitalsCount);
        //                    //Debug.WriteLine("============"); 

        //                    if (patDemo.EducationTopics != null)
        //                        if (patDemo.EducationTopics.List.Count > 0)
        //                            Debug.WriteLine("hi");

        //                    if (patDemo.Exams != null)
        //                        if (patDemo.Exams.List.Count > 0)
        //                            Debug.WriteLine("hi");

        //                    if (patDemo.Flags != null) 
        //                        if (patDemo.Flags.List.Count > 0)
        //                            Debug.WriteLine("hi");

        //                    if (patDemo.HealthFactors != null) 
        //                        if (patDemo.HealthFactors.List.Count > 0)
        //                            Debug.WriteLine("HealthFactor Recorded " + patDemo.HealthFactors.List[0].Recorded.ToDateTime().ToString());

        //                    if (patDemo.InsurancePolicies != null)
        //                        if (patDemo.InsurancePolicies.List.Count > 0)
        //                            Debug.WriteLine("hi");

        //                    if (patDemo.Observations != null)
        //                        if (patDemo.Observations.List.Count > 0)
        //                            Debug.WriteLine("hi");

        //                    if (patDemo.SkinTests != null)
        //                        if (patDemo.SkinTests.List.Count > 0)
        //                            Debug.WriteLine("skin tests");

        //                    if (patDemo.Surgeries != null)
        //                        if (patDemo.Surgeries.List.Count > 0)
        //                            Debug.WriteLine("surgeries");
        //                }
        //            }
        //    }
        //}
    }
}
