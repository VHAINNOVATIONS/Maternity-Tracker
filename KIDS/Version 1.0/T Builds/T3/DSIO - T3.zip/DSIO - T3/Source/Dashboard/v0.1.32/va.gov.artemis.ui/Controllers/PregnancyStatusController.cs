﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using VA.Gov.Artemis.UI.Filters;

namespace VA.Gov.Artemis.UI.Controllers
{
    [DisableLocalCache]
    [VerifySession]
    [Authorize]
    public class PregnancyStatusController : DashboardController
    {
        [HttpGet]
        public ActionResult Index()
        {
            // *** Show current pregnancy status and list of historical entries ***

            // TODO...

            return View();
        }

        [HttpGet]
        public ActionResult Update(string dfn)
        {
            // *** Show form to update preganancy status ***

            // TODO ...

            return View();
        }

        [HttpPost]
        public ActionResult Update()
        {
            // *** Post data ***

            // TODO ...

            return View();
        }

    }
}
