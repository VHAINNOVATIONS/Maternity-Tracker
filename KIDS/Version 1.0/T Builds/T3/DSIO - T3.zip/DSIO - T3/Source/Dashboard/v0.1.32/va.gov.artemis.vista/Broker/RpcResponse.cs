﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using VA.Gov.Artemis.Vista.Utility;

namespace VA.Gov.Artemis.Vista.Broker
{
    public sealed class RpcResponse
    {
        public RpcResponseStatus Status { get; set; }
        public RpcResponseFailType FailType { get; set; }

        public string Data { get; set; }

        public string[] Lines { get { return Util.Split(this.Data); } }

        public string InformationalMessage { get; set; }

        public RpcResponse()
        {
            this.Data = "";
            this.InformationalMessage = ""; 
            this.Status = RpcResponseStatus.Unknown;
            this.FailType = RpcResponseFailType.None; 
        }

        public RpcResponse(RpcResponseFailType failType, string failMessage)
        {
            this.Data = "";
            this.Status = RpcResponseStatus.Fail;
            this.FailType = failType;
            this.InformationalMessage = failMessage; 
        }

        public string GetXmlDescription()
        {
            StringBuilder sb = new StringBuilder();

            XmlWriterSettings settings = new XmlWriterSettings() { Indent = true, OmitXmlDeclaration = true };

            using (XmlWriter writer = XmlTextWriter.Create(sb, settings))
            {
                writer.WriteStartElement("Response");

                writer.WriteElementString("Status", this.Status.ToString());
                writer.WriteElementString("FailType", this.FailType.ToString());
                writer.WriteElementString("InformationalMessage", this.InformationalMessage.ToString()); 

                if (this.Data == null)
                    writer.WriteElementString("Data", "");
                else 
                {
                    writer.WriteStartElement("Data");

                    string[] lines = this.Lines; 

                    for (int i = 0; i < lines.Length; i++)
                    {
                        string elName = string.Format("Line{0}", i);

                        writer.WriteElementString(elName, lines[i].ToString());
                    }

                    writer.WriteEndElement();
                }

                writer.WriteEndElement();
            }
            return sb.ToString();
        }

    }
}
