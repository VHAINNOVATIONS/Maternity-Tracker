﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VA.Gov.Artemis.UI.Data.Brokers.Results;
using VA.Gov.Artemis.UI.Data.Models.Administration;

namespace VA.Gov.Artemis.UI.Data.Brokers
{
    public interface INonVACareRepository
    {
        PatientNonVACareItemsResult GetPatientItems(string dfn);

        NonVACareItemsResult GetAll(int page, int itemsPerPage);

        NonVACareItemsResult GetList(NonVACareItemType itemType, int page, int itemsPerPage);

        BrokerOperationResult SaveItem(NonVACareItem item);

        NonVACareItemsResult GetItem(string ien);
    }
}
