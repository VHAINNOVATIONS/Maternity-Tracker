﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;
using VA.Gov.Artemis.Vista.Commands;
using VA.Gov.Artemis.Vista.Broker;
using VA.Gov.Artemis.Commands.Xus;
using VA.Gov.Artemis.Commands.Vpr;
using VA.Gov.Artemis.UI.Mock;

namespace VA.Gov.Artemis.Commands.tests.mock
{
    [TestClass]
    public class TestMockVprCommands
    {
        [TestMethod]
        public void TestMockGetPatientDataCommand_GoodData()
        {
            IRpcBroker mockBroker = MockRpcBrokerFactory.GetVprGetPatientDataBroker(true);

            VprGetPatientDataCommand testCommand = new VprGetPatientDataCommand(mockBroker, "229");

            //testCommand.SetArgs("229");

            RpcResponse response = testCommand.Execute();
    
            Assert.IsNotNull(response); 
            Assert.AreEqual(RpcResponseStatus.Success, response.Status);
            Assert.IsFalse(string.IsNullOrWhiteSpace(response.Data));
        }

        [TestMethod]
        public void TestMockGetPatientDataCommand_BadData()
        {
            IRpcBroker mockBroker = MockRpcBrokerFactory.GetVprGetPatientDataBroker(false);

            VprGetPatientDataCommand testCommand = new VprGetPatientDataCommand(mockBroker, "229");

            RpcResponse response = testCommand.Execute();

            Assert.IsNotNull(response);
            Assert.AreEqual(RpcResponseStatus.Fail, response.Status);
            Assert.IsTrue(string.IsNullOrWhiteSpace(response.Data));
        }

    }
}
