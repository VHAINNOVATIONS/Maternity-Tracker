﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VA.Gov.Artemis.Vista.Broker;
using VA.Gov.Artemis.Vista.Utility;

namespace VA.Gov.Artemis.Commands.Dsio
{
    public class DsioGetRecordTextCommand: DsioCommand
    {
        public DsioGetRecordTextCommand(IRpcBroker newBroker): base(newBroker)
        {

        }

        public string RecordText { get; set; }

        public override string RpcName
        {
            get { return "DSIO GET RECORD TEXT"; }
        }

        public void AddCommandArgument(string ien)
        {
            this.CommandArgs = new object[] { ien };
        }

        protected override void ProcessResponse()
        {
            // *** Make sure we have something to work with ***
            if (string.IsNullOrWhiteSpace(this.Response.Data))
            {
                // *** Set response info ***
                this.Response.Status = RpcResponseStatus.Fail;
                this.Response.InformationalMessage = "No data returned";
            }
            else
            {
                // *** Check first piece for success/failure ***
                string first = Util.Piece(this.Response.Lines[0], Caret, 1);

                if (first == "0")
                {
                    // *** 0 is fail ***
                    this.Response.Status = RpcResponseStatus.Fail;
                    this.Response.InformationalMessage = Util.Piece(this.Response.Lines[0], Caret, 2);
                }
                else
                {
                    this.RecordText = this.Response.Data;
                    this.Response.Status = RpcResponseStatus.Success;
                }
            }            
        }
    }
}
