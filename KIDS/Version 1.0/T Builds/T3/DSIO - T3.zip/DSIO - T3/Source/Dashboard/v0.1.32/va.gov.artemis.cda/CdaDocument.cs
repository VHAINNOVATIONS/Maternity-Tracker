﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace VA.Gov.Artemis.Cda
{

    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlRootAttribute("ClinicalDocument", Namespace = "urn:hl7-org:v3", IsNullable = false)]
    public class CdaDocument : POCD_MT000040ClinicalDocument
    {
        public static string CdaDateFormat = "yyyyMMddHHmmsszz";

        public CdaDocument()
            : base()
        {
            this.xmlns = new XmlSerializerNamespaces();
            this.xmlns.Add("voc", "urn:hl7-org:v3/voc");

            this.realmCode = new List<CS>();
            this.realmCode.Add(new CS() { code = "US" });

            this.typeId = new POCD_MT000040InfrastructureRoottypeId() { root = "2.16.840.1.113883.1.3", extension = "POCD_HD000040" };

            //<effectiveTime value='20000407130000+0500'/>
            this.effectiveTime = new TS() { value = DateTime.Now.ToString(CdaDocument.CdaDateFormat) };

            //<confidentialityCode code='N' codeSystem='2.16.840.1.113883.5.25'/>
            this.confidentialityCode = new CE() { code = "N", codeSystem = "2.16.840.1.113883.5.25" };

            //<languageCode code='en-US'/>
            this.languageCode = new CS() { code = "en-US" };
        }

        [XmlNamespaceDeclarations]
        public XmlSerializerNamespaces xmlns;

    }
}