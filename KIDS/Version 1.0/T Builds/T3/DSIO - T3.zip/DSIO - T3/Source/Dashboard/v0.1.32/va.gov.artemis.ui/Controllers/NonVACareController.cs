﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using VA.Gov.Artemis.UI.Data.Brokers.Results;
using VA.Gov.Artemis.UI.Data.Models.Administration;
using VA.Gov.Artemis.UI.Data.Models.Patient;
using VA.Gov.Artemis.UI.Filters;

namespace VA.Gov.Artemis.UI.Controllers
{
    [DisableLocalCache]
    [VerifySession]
    [Authorize]
    public class NonVACareController : DashboardController
    {
        [HttpGet]
        public ActionResult Details(string dfn)
        {
            // *** Show current provider and facility ***

            // *** Show historical providers and facilities ***

            PatientNonVACare model = new PatientNonVACare();

            // *** Get patient demographics ***
            model.Patient = this.CurrentPatient;

            // *** Check for success ***
            if (!model.Patient.NotFound)
            {                
                PatientNonVACareItemsResult itemsResult = this.DashboardRepository.NonVACare.GetPatientItems(dfn);

                if (itemsResult.Success)
                    model.AllNonVACareItems = itemsResult.Items; 
            }

            return View(model); 
        }

        [HttpGet]
        public ActionResult Edit(string itemType, string dfn)
        {
            // *** Allow edit/selection of current provider and facility ***

            EditPatientNonVACareItem model = new EditPatientNonVACareItem();

            NonVACareItemType careItemType; 
            int tempType = -1;
            if (int.TryParse(itemType, out tempType))
            {
                careItemType = (NonVACareItemType)tempType;

                if (careItemType == NonVACareItemType.Provider)
                {
                    model.ListLabel = "Prenatal Care Provider";
                    model.ContactLabel = "Prenatal Care Contact";
                }
                else
                {
                    model.ListLabel = "Planned Delivery Location";
                    model.ContactLabel = "Planned Delivery Location Contact";
                }

                // *** Get patient demographics ***
                model.Patient = this.CurrentPatient;

                // *** Check for success ***
                if (!model.Patient.NotFound)
                {                
                    // TODO:...

                    // *** Get current prov/fac for patient ***
                    PatientNonVACareItemsResult patientItemsResult = this.DashboardRepository.NonVACare.GetPatientItems(dfn);

                    if (patientItemsResult.Success)
                    {
                        PatientNonVACare nonVACare = new PatientNonVACare();
                        nonVACare.AllNonVACareItems = patientItemsResult.Items; 

                        if (careItemType == NonVACareItemType.Provider)
                        {
                            if (nonVACare.CurrentPrentalCareProvider != null)
                                model.Item = nonVACare.CurrentPrentalCareProvider;
                        }
                        else 
                        {
                            if (nonVACare.CurrentPlannedDeliveryLocation != null) 
                            model.Item = nonVACare.CurrentPlannedDeliveryLocation; 
                        }

                        // *** Get select list ***
                        NonVACareItemsResult itemsResult = this.DashboardRepository.NonVACare.GetList(careItemType, 1, 99);

                        if (itemsResult.Success)
                            model.ItemList = itemsResult.Items;                       
                
                    }
                }

            }
            return View(model); 
        }

        [HttpPost]
        public ActionResult Edit(EditPatientNonVACareItem model)
        {
            // *** Post edits ***

            // TODO: ...

            return RedirectToAction("Details", new { dfn = model.Patient.Dfn }); 
        }
        
    }
}
