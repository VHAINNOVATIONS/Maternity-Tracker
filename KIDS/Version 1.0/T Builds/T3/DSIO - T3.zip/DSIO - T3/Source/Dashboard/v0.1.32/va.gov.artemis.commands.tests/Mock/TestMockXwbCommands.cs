﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;
using VA.Gov.Artemis.Vista.Commands;
using VA.Gov.Artemis.Vista.Broker;
using VA.Gov.Artemis.Commands.Xwb;
using VA.Gov.Artemis.UI.Mock;

namespace VA.Gov.Artemis.Commands.tests.mock
{
    [TestClass]
    public class TestMockXwbCommands 
    {
        [TestMethod]
        public void TestMockGetBrokerInfoCommand_GoodData()
        {
            IRpcBroker broker = MockRpcBrokerFactory.GetXwbGetBrokerInfoBroker(true);

            XwbGetBrokerInfoCommand testCommand = new XwbGetBrokerInfoCommand(broker);

            RpcResponse response = testCommand.Execute(); 

                // *** Check results ***
            Assert.IsNotNull(response);
            Assert.AreEqual(RpcResponseStatus.Success, response.Status);
            Assert.IsTrue(testCommand.TimeoutMilliseconds > 0);

        }

        [TestMethod]
        public void TestMockGetBrokerInfoCommand_BadData()
        {
            IRpcBroker broker = MockRpcBrokerFactory.GetXwbGetBrokerInfoBroker(false);

            XwbGetBrokerInfoCommand testCommand = new XwbGetBrokerInfoCommand(broker);

            RpcResponse response = testCommand.Execute();

            // *** Check results ***
            Assert.IsNotNull(response);
            Assert.AreEqual(RpcResponseStatus.Fail, response.Status);
            
        }

    }
}
