﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace VA.Gov.Artemis.Commands.Vpr.Data
{
    [Serializable]
    public class Facility
    {
        [XmlAttribute("code")]
        public string Code { get; set; }

        [XmlAttribute("name")]
        public string Name { get; set; }

        [XmlAttribute("domain")]
        public string Domain { get; set; }

        // TODO: Figure out how to deserialize VprDateTime as attribute...
        //public VprDateTime LatestDate { get; set; }
        [XmlAttribute("latestDate")]
        public string LatestDate { get; set; }
    }
}
