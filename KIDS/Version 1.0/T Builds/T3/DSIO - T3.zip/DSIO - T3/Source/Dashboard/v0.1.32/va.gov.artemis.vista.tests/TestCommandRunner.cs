﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using VA.Gov.Artemis.Vista.Commands;
using System.Collections.Generic;
using VA.Gov.Artemis.Vista.Broker;

namespace VA.Gov.Artemis.Vista.Tests
{
    [TestClass]
    public class TestCommandRunner
    {
        [TestMethod]
        public void TestExecuteNow()
        {
            CommandRunner runner = new CommandRunner();

            using (RpcBroker broker = new RpcBroker("", 9000))
            {
                MockCommand command = new MockCommand(broker);

                RpcResponse fromCommand = command.Execute();
                RpcResponse fromRunner = runner.ExecuteNow(command);

                Assert.AreEqual(fromCommand.GetXmlDescription(), fromRunner.GetXmlDescription());

                broker.Disconnect(); 
            }
        }
    }
}
