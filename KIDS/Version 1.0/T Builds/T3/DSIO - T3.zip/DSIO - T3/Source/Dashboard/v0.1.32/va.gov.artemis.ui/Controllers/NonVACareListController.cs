﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using VA.Gov.Artemis.UI.Data.Brokers.Results;
using VA.Gov.Artemis.UI.Data.Models.Administration;
using VA.Gov.Artemis.UI.Filters;

namespace VA.Gov.Artemis.UI.Controllers
{
    [DisableLocalCache]
    [VerifySession]
    [Authorize]
    public class NonVACareListController : DashboardController
    {
        private const int ItemsPerPage = 10; 

        [HttpGet]
        public ActionResult Index(string page)
        {
            // *** Show lists of current providers and facilities ***

            NonVACareItemList model = new NonVACareItemList();

            int pageVal = this.GetPage(page); 

            // *** Get the list of items ***
            NonVACareItemsResult result =  this.DashboardRepository.NonVACare.GetAll(pageVal, ItemsPerPage);

            // *** Check for success ***
            if (!result.Success)
                this.Error(result.Message);
            else
            {
                model.Items = result.Items;
                model.Paging.SetPagingData(ItemsPerPage, pageVal, result.TotalResults); 
                model.Paging.BaseUrl = Url.Action("Index", new {page = ""});

                TempData[ReturnUrl] = Url.Action("Index", new {page = page });
            }

            return View(model);
        }

        [HttpGet]
        public ActionResult Create()
        {
            // *** Create new provider or facility ***

            NonVACareItem model = new NonVACareItem();

            // TODO: Can this be part of filter...?

            // *** Set return url ***
            if (TempData.ContainsKey(ReturnUrl))
            {
                model.ReturnUrl = TempData[ReturnUrl].ToString();
                TempData[ReturnUrl] = TempData[ReturnUrl];
            }

            return View("Edit", model);
        }

        [HttpPost]
        public ActionResult Save(NonVACareItem model)
        {
            ActionResult returnResult; 

            // *** Post data ***

            BrokerOperationResult result;

            // *** Check model state ***
            if (ModelState.IsValid)
            {
                result = this.DashboardRepository.NonVACare.SaveItem(model);

                // *** Check result ***
                if (!result.Success)
                {
                    this.Error(result.Message);
                    returnResult = View("Edit", model);
                }
                else
                    returnResult = RedirectToAction("Index");
            }
            else 
                returnResult = View("Edit", model);

            // *** Set return url ***
            if (TempData.ContainsKey(ReturnUrl))
            {
                model.ReturnUrl = TempData[ReturnUrl].ToString();
                TempData[ReturnUrl] = TempData[ReturnUrl];
            }

            return returnResult;
        }

        [HttpGet]
        public ActionResult Edit(string ien)
        {
            // *** Edit existing provider or facility ***

            NonVACareItem model = new NonVACareItem(); 

            // *** Get the list of items ***
            NonVACareItemsResult result = this.DashboardRepository.NonVACare.GetItem(ien);

            // *** Check for success ***
            if (result.Success)
                if (result.Items != null)
                    if (result.Items.Count > 0)
                        model = result.Items[0];

            // *** Set return url ***
            if (TempData.ContainsKey(ReturnUrl))
            {
                model.ReturnUrl = TempData[ReturnUrl].ToString();
                TempData[ReturnUrl] = TempData[ReturnUrl];
            }

            return View(model);
        }
    }
}
