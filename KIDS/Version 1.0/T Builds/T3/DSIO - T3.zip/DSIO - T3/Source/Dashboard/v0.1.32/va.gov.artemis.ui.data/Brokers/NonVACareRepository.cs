﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VA.Gov.Artemis.Commands.Dsio;
using VA.Gov.Artemis.UI.Data.Brokers.Results;
using VA.Gov.Artemis.UI.Data.Models.Administration;
using VA.Gov.Artemis.UI.Data.Models.Patient;
using VA.Gov.Artemis.Vista.Broker;

namespace VA.Gov.Artemis.UI.Data.Brokers
{
    public class NonVACareRepository: RepositoryBase, INonVACareRepository
    {
        public NonVACareRepository(IRpcBroker newBroker): base(newBroker)
        {
            
        }

        public PatientNonVACareItemsResult GetPatientItems(string dfn)
        {
            PatientNonVACareItemsResult result = new PatientNonVACareItemsResult();

            // TODO:...
            result.Items.Add(
                    new PatientNonVACareItem()
                    {
                        EntryDate = new DateTime(2013, 12, 10),
                        UserName = "Roistaff, Chief",
                        PrimaryContactName = "Office Staff",
                        ItemDetail = new NonVACareItem()
                        {
                            Ien = "3",
                            Name = "Test Doctor OB/GYN",
                            AddressLine1 = "123 Middle Street",
                            AddressLine2 = "",
                            City = "Salt Lake City",
                            State = "UT",
                            ZipCode = "23456",
                            PhoneNumber = "(909) 234-5678",
                            FaxNumber = "(909) 343-3434",
                            ItemType = NonVACareItemType.Provider
                        }
                    });

            result.Items.Add(
                      new PatientNonVACareItem()
                    {
                        EntryDate = new DateTime(2013, 12, 10),
                        UserName = "Roistaff, Chief",
                        PrimaryContactName = "Nurse One",
                        ItemDetail = new NonVACareItem()
                        {
                            Name = "University Hospital",
                            AddressLine1 = "123 Middle Street",
                            AddressLine2 = "",
                            City = "Salt Lake City",
                            State = "UT",
                            ZipCode = "23456",
                            PhoneNumber = "(909) 234-5678",
                            FaxNumber = "(909) 343-3434",
                            ItemType = NonVACareItemType.Facility
                        }
                    });

            result.Items.Add(
            new PatientNonVACareItem()
            {
                EntryDate = new DateTime(2013, 9, 10),
                UserName = "Roistaff, Chief",
                PrimaryContactName = "Office Staff",
                ItemDetail = new NonVACareItem()
                {
                    ItemType = NonVACareItemType.Provider,
                    Name = "Dr. Obee Gyn OBGYN"
                }
            });

            result.Items.Add(
                      new PatientNonVACareItem()
                    {
                        EntryDate = new DateTime(2013, 8, 10),
                        UserName = "Roistaff, Chief",
                        PrimaryContactName = "Nurse One",
                        ItemDetail = new NonVACareItem()
                        {
                            ItemType = NonVACareItemType.Facility,
                            Name = "Community Hospital"
                        }
                    }
                );

            result.Success = true;

            return result;
        }

        public BrokerOperationResult UpdatePatientItem(string dfn, string itemId, string primaryContact)
        {
            BrokerOperationResult result = new BrokerOperationResult();

            // TODO: Use command to save contact 

            result.Success = true; 

            return result;
        }

        public NonVACareItemsResult GetAll(int page, int itemsPerPage)
        {
            return GetList("", page, itemsPerPage);
        }

        public NonVACareItemsResult GetList(NonVACareItemType itemType, int page, int itemsPerPage)
        {
            NonVACareItemsResult returnResult;

            switch (itemType)
            {
                case NonVACareItemType.Facility:
                    returnResult = GetList("F", page, itemsPerPage);
                    break; 
                case NonVACareItemType.Provider:
                    returnResult = GetList("P", page, itemsPerPage);
                    break; 
                default:
                    returnResult = GetList("", page, itemsPerPage);
                    break; 
            }

            return returnResult; 
        }

        private NonVACareItemsResult GetList(string commandArgument, int page, int itemsPerPage)
        {
            // *** Get a list of all non va items ***

            NonVACareItemsResult result = new NonVACareItemsResult(); 

            // *** Create the command ***
            DsioReturnEntityCommand command = new DsioReturnEntityCommand(broker);

            // *** Add the arguments ***            
            command.AddCommandArguments(commandArgument, page, itemsPerPage);

            // *** Execute the command ***
            RpcResponse response = command.Execute();

            // *** Gather the results ***
            result.Success = (response.Status == RpcResponseStatus.Success);
            result.Message = response.InformationalMessage;

            // *** Check for success ***
            if (result.Success)
            {
                result.TotalResults = command.TotalResults; 

                // *** Go through each returned item ***
                foreach (DsioNonVAItem dsioItem in command.NonVAEntities)
                {
                    NonVACareItem item = GetNonVACareItem(dsioItem); 

                    // *** Add to return list ***
                    result.Items.Add(item);
                }

                // TODO: Remove this...
                //if (command.NonVAEntities.Count == 0)
                //{
                //    NonVACareItem newItem = new NonVACareItem()
                //    {
                //        AddressLine1 = "1234 Street",
                //        AddressLine2 = "#3",
                //        City = "Hometown",
                //        State = "TN",
                //        Name = "Community Hospital",
                //        ItemType = NonVACareItemType.Facility,
                //        Inactive = false,
                //        Id = "345",
                //        ZipCode = "00990",
                //        PhoneNumber = "(800) 900-0999",
                //        FaxNumber = "(987) 654-0987",
                //        PrimaryContact = "Office Staff"
                //    };
                //    result.Items.Add(newItem); 

                //    newItem = new NonVACareItem()
                //    {
                //        AddressLine1 = "1234 Street",
                //        AddressLine2 = "#3",
                //        City = "Hometown",
                //        State = "TN",
                //        Name = "University Hospital",
                //        ItemType = NonVACareItemType.Facility,
                //        Inactive = false,
                //        Id = "345",
                //        ZipCode = "00990",
                //        PhoneNumber = "(800) 900-0999",
                //        FaxNumber = "(987) 654-0987",
                //        PrimaryContact = "Office Staff"
                //    };
                //    result.Items.Add(newItem);

                //    newItem = new NonVACareItem()
                //    {
                //        AddressLine1 = "1234 Street",
                //        AddressLine2 = "#3",
                //        City = "Hometown",
                //        State = "TN",
                //        Name = "Dr. Test Doctor",
                //        ItemType = NonVACareItemType.Provider,
                //        Inactive = false,
                //        Id = "345",
                //        ZipCode = "00990",
                //        PhoneNumber = "(800) 900-0999",
                //        FaxNumber = "(987) 654-0987",
                //        PrimaryContact = "Office Staff"
                //    };
                //    result.Items.Add(newItem);
                //}
            }

            return result; 
        }

        private NonVACareItem GetNonVACareItem(DsioNonVAItem dsioItem)
        {
            // *** Create a strongly typed item ***
            NonVACareItem item = new NonVACareItem()
            {
                Ien = dsioItem.Ien,
                Name = dsioItem.EntityName,
                OriginalName = dsioItem.EntityName,
                AddressLine1 = dsioItem.AddressLine1,
                AddressLine2 = dsioItem.AddressLine2,
                City = dsioItem.City,
                State = dsioItem.State,
                ZipCode = dsioItem.Zip,
                PhoneNumber = dsioItem.PhoneNumber,
                FaxNumber = dsioItem.FaxNumber,
                Inactive = (dsioItem.Inactive == "YES") ? true : false
            };

            switch (dsioItem.EntityType)
            {
                case "PROVIDER":
                    item.ItemType = NonVACareItemType.Provider;
                    break;
                case "FACILITY":
                    item.ItemType = NonVACareItemType.Facility;
                    break;
                default:
                    item.ItemType = NonVACareItemType.Provider;
                    break;
            }

            return item; 
        }
        
        public BrokerOperationResult SaveItem(NonVACareItem item)
        {
            // *** Creates a new Non VA Care Item ***

            BrokerOperationResult result = new BrokerOperationResult(); 

            // *** Create the command ***
            DsioSaveNonVAEntityCommand command = new DsioSaveNonVAEntityCommand(broker); 

            // *** Create the entity to save ***
            DsioNonVAItem dsioItem = new DsioNonVAItem();

            dsioItem.OriginalEntityName = item.OriginalName; 
            dsioItem.EntityName = item.Name; 
            dsioItem.AddressLine1 = item.AddressLine1; 
            dsioItem.AddressLine2 = item.AddressLine2; 
            dsioItem.City = item.City; 
            dsioItem.State = item.State; 
            dsioItem.Zip = item.ZipCode; 
            dsioItem.PhoneNumber = item.PhoneNumber; 
            dsioItem.FaxNumber = item.FaxNumber;
            dsioItem.PrimaryContact = item.PrimaryContact; 

            dsioItem.Inactive = (item.Inactive) ? "YES" : "NO"; 
            dsioItem.EntityType = (item.ItemType== NonVACareItemType.Provider) ? "PROVIDER" : "FACILITY";

            // *** Add the arguments ***
            command.AddCommandArguments(dsioItem);

            // *** Execute the command ***
            RpcResponse response = command.Execute();

            // *** Gather results ***
            result.Success = (response.Status == RpcResponseStatus.Success);
            result.Message = response.InformationalMessage;

            return result;             
        }

        public NonVACareItemsResult GetItem(string ien)
        {
            return GetList(ien, 1, 1);
        }
    }
}
