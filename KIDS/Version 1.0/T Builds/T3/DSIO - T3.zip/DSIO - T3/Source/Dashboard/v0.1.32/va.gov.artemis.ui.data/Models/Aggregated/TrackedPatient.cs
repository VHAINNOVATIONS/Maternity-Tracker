﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using VA.Gov.Artemis.UI.Data.Models.Aggregated.TrackedEvents;

namespace VA.Gov.Artemis.UI.Data.Models.Aggregated
{
    public class TrackedPatient: BasePatient
    {
        [Display(Name="Phone")]
        public string PhoneNumber { get; set; }

        public string SSN
        {
            get
            {
                return string.Format("XXX-XX-{0}", this.Last4);
            }
        }
        
        // *** Outside services ***
        public string OBProviderName { get; set; }
        public string OBFacilityName { get; set; }

        // *** Why tracking ***
        public TrackingEntry TrackingEntry { get; set; }

        // *** Current (or most recent) Pregnancy Information ***
        public Pregnancy CurrentPregnancy { get; set; } // Or most recent ? //

        // *** EdMtls, MccContacts, Labs, Consults, Orders ***
        public List<TrackedEvent> TrackedEvents { get; set; }

        // *** If patient has delivered a baby no more than 6 weeks ago ***
        public bool PostPartum { get; set; }

        public TrackedPatient()
        {
            this.TrackedEvents = new List<TrackedEvent>(); 
        }

        public static TrackedPatient FromBase(BasePatient basePatient)
        {
            TrackedPatient returnPatient = new TrackedPatient()
            {
                Dfn = basePatient.Dfn, 
                LastName = basePatient.LastName , 
                FirstName = basePatient.FirstName, 
                Last4 = basePatient.Last4, 
                DateOfBirth = basePatient.DateOfBirth,
                DateOfBirthInexact =basePatient.DateOfBirthInexact
            };

            return returnPatient; 
        }
    }
}