﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VA.Gov.Artemis.Vista.Broker;
using VA.Gov.Artemis.Vista.Commands;
using VA.Gov.Artemis.Vista.Utility;

namespace VA.Gov.Artemis.Commands.Dsio
{
    public class DsioCreateTrackingLogCommand: DsioCommand 
    {
        public DsioCreateTrackingLogCommand(IRpcBroker newBroker): base(newBroker) {}

        public override string RpcName
        {
            get { return "DSIO CREATE TRACKING LOG"; }
        }

        protected override void ProcessResponse()
        {
            if (string.IsNullOrWhiteSpace(this.Response.Data))
            {
                this.Response.Status = RpcResponseStatus.Fail;
                this.Response.InformationalMessage = "No return value";
            }
            else
            {
                string piece1 = Util.Piece(this.Response.Lines[0], Caret, 1);
                string piece2 = Util.Piece(this.Response.Lines[0], Caret, 2);

                switch (piece1)
                {
                    case "1":
                        this.Response.Status = RpcResponseStatus.Success;
                        break;
                    case "-1":
                    default:
                        this.Response.Status = RpcResponseStatus.Fail;
                        this.Response.InformationalMessage = piece2;
                        break;
                }                        
            }

        }

        public void AddCommandArguments(string dfn, string eventType, string reason, string[] comment)
        {
            this.CommandArgs = new object[] {dfn, eventType, reason, comment};

        }
    }
}
