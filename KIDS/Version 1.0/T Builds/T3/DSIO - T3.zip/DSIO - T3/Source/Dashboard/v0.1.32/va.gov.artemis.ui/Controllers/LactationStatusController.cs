﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using VA.Gov.Artemis.UI.Filters;

namespace VA.Gov.Artemis.UI.Controllers
{
    [DisableLocalCache]
    [VerifySession]
    [Authorize]
    public class LactationStatusController : DashboardController
    {
        [HttpGet]
        public ActionResult Details(string dfn)
        {
            // *** Show current Lactation Status and list of historical entries ***

            // TODO...

            return View();
        }

        [HttpGet]
        public ActionResult Update(string dfn)
        {
            // *** Show form to update lactation status ***

            // TODO...

            return View();
        }

        [HttpPost]
        public ActionResult Update(int useNewModel)
        {
            // *** Post data ***

            // TODO...

            return View();
        }            

    }
}
