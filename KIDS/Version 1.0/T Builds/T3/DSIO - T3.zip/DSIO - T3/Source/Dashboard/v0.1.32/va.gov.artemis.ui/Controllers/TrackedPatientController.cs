﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using VA.Gov.Artemis.UI.Data.Models;
using VA.Gov.Artemis.UI.Data.Models.Aggregated;
using VA.Gov.Artemis.UI.Filters;

namespace VA.Gov.Artemis.UI.Controllers
{
    [Authorize]
    [VerifySession]
    [DisableLocalCache]
    public class TrackedPatientController : DashboardController
    {
        //
        // GET: /TrackedPatient/
        public ActionResult Index()
        {
            ViewBag.Title = "Tracked Patients";

            TrackedPatients model = this.DashboardRepository.Patients.GetTrackedPatientsData(); 

            return View(model);
        }

        public ActionResult Buckets()
        {
            ViewBag.Title = "Tracked Patients";

            TrackedPatients model = this.DashboardRepository.Patients.GetTrackedPatientsData();

            return View(model);

        }

        public ActionResult Text()
        {
            ViewBag.Title = "Tracked Patients";

            TrackedPatients model = this.DashboardRepository.Patients.GetTrackedPatientsData();

            return View(model);

        }

        //
        // GET: /TrackedPatient/Details/5

        public ActionResult Details(string id = null)
        {
            TrackedPatient trackedpatient = this.DashboardRepository.Patients.Get(id); 

            if (trackedpatient == null)
            {
                return HttpNotFound();
            }
            return View(trackedpatient);
        }

        public ActionResult TestChart()
        {
            return View(); 
        }

        [HttpGet]
        public ActionResult Trimester()
        {
            ActionResult returnValue;

            TrackedPatients model = this.DashboardRepository.Patients.GetTrackedPatientsData();

            returnValue = View(model); 

            return returnValue; 
        }
    }
}