﻿//using VA.Gov.Artemis.UI.Data.Models.Common;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using VA.Gov.Artemis.UI.Data.Models.Aggregated.Common;

namespace VA.Gov.Artemis.UI.Data.Models.Aggregated.TrackedEvents
{
    public abstract class TrackedEvent
    {
        public int EventId { get; set; }
        public string ItemId { get; set; }

        [Display(Name="Date")]
        [DisplayFormat(DataFormatString = "{0:MM/dd/yyyy}")]
        public DateTime EventDate { get; set; } // Due or Completed

        //public DateTime Due { get; set; }
        //public DateTime Completed { get; set; }

        public string Provider { get; set; } // DUZ //

        [Display(Name = "Type")]
        public abstract string EventName { get; }

        public abstract string Details { get; }

        public abstract TrackedEventType EventType { get; }

        public TrackedEventCompletionStatus Status { get; set; }

        //public virtual TrackedEventStatus EventStatus
        //{
        //    get
        //    {
        //        // *** Default status is based on completion status ***
        //        // *** Override to change logic ***

        //        TrackedEventStatus returnVal;

        //        switch (this.CompletionStatus)
        //        {
        //            case TrackedEventCompletionStatus.Completed:
        //                returnVal = TrackedEventStatus.Info;
        //                break;
        //            case TrackedEventCompletionStatus.Due:
        //                returnVal = TrackedEventStatus.Warning;
        //                break;
        //            case TrackedEventCompletionStatus.Overdue:
        //                returnVal = TrackedEventStatus.Critical;
        //                break;
        //            default:
        //                returnVal = TrackedEventStatus.Other;
        //                break;
        //        }

        //        return returnVal;
        //    }
        //}

        //public virtual TrackedEventCompletionStatus CompletionStatus
        //{
        //    get
        //    {
        //        // *** If we have any completed date, then it's completed *** 
        //        // *** If we are within 5 days of due date, then it's due ***
        //        // *** If we are past 5 days after, then it's overdue 
        //        // *** Otherwise, it's pending ***

        //        TrackedEventCompletionStatus returnVal;

        //        if (this.Completed != DateTime.MinValue)
        //            returnVal = TrackedEventCompletionStatus.Completed;
        //        else if ((DateTime.Now.Date >= this.Due.Date.AddDays(-5)) &&
        //            (DateTime.Now.Date <= this.Due.Date.AddDays(5)))
        //            returnVal = TrackedEventCompletionStatus.Due;
        //        else if (DateTime.Now.Date >= this.Due.Date)
        //            returnVal = TrackedEventCompletionStatus.Overdue;
        //        else
        //            returnVal = TrackedEventCompletionStatus.Pending;

        //        return returnVal;
        //    }
        //}

        //[Display(Name="Status")]
        //public string StatusDescription
        //{
        //    get
        //    {
        //        string returnVal = "";

        //        returnVal = this.CompletionStatus.ToString();

        //        returnVal += ": ";

        //        if (this.CompletionStatus == TrackedEventCompletionStatus.Completed)
        //            returnVal += this.Completed.ToShortDateString();
        //        else
        //            returnVal += this.Due.ToShortDateString(); 
        //        return returnVal;
        //    }
        //}

    }
}