﻿//using VA.Gov.Artemis.UI.Data.Models.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using VA.Gov.Artemis.UI.Data.Models.Aggregated.Common;

namespace VA.Gov.Artemis.UI.Data.Models.Aggregated.TrackedEvents
{
    // *** Does this include ultrasound results? ***

    public class LabEvent : TrackedEvent
    {
        public string LabId { get; set; }
        public string Specimen { get; set; }
        public string Accession { get; set; }

        public List<LabTest> LabTests { get; set; }

        public override string EventName
        {
            get { return "Lab Results"; }
        }

        public override string Details
        {
            get { return string.Format("{0} : {1}", this.Specimen, this.Accession); }
        }

        public override TrackedEventType EventType
        {
            get { return TrackedEventType.Lab; }
        }

        //public override TrackedEventStatus EventStatus
        //{
        //    get
        //    {
        //        // TODO: Look for flag values in lab tests and set event status accordingly...

        //        return base.EventStatus;
        //    }
        //}

 
    }
}