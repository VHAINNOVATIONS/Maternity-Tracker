﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VA.Gov.Artemis.Commands.Vpr.Data
{
    [Serializable]
    public class Observation: ClinicalItem 
    {
        // TODO: From docs...

        // bodySite
        // comment
        // entered
        // method
        // observed
        // position
        // product
        // quality
        // range
        // status
        // units
        // value 
        // vuid
        
    }
}
